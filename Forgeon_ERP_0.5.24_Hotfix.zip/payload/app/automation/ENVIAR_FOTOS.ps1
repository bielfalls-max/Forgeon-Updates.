﻿param([Parameter(Mandatory=$true)][string]$Job)
$ErrorActionPreference = 'Stop'
$Root = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
try {
    $Python = Join-Path $Root '.venv-browser\Scripts\python.exe'
    if (-not (Test-Path $Python)) {
        & (Join-Path $Root '.venv\Scripts\python.exe') -m venv (Join-Path $Root '.venv-browser')
        if ($LASTEXITCODE -ne 0) { throw 'Falha ao criar ambiente de envio.' }
    }
    & $Python -c 'import playwright, PIL'
    if ($LASTEXITCODE -ne 0) {
        & $Python -m pip install 'playwright==1.64.1' 'Pillow>=12.1,<13'
        if ($LASTEXITCODE -ne 0) { throw 'Falha ao instalar componentes de envio.' }
    }
    & $Python (Join-Path $PSScriptRoot 'send_chatgpt.py') --root $Root --job $Job
    exit $LASTEXITCODE
} catch {
    Write-Host $_ -ForegroundColor Red
    exit 1
}
