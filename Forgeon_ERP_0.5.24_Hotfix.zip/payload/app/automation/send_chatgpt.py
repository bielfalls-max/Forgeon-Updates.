"""Single-conversation browser sender. No login automation or automatic retries."""
import argparse, hashlib, json, os, re, subprocess, sys, time
from pathlib import Path
from urllib.request import urlopen
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from services.chatgpt_browser import load, find_opera_gx
from services.photo_jobs import PhotoJobs

def status(folder,state,message):
    target=folder/'browser-send.json';tmp=target.with_suffix('.tmp')
    tmp.write_text(json.dumps({'state':state,'message':message},ensure_ascii=False),encoding='utf-8');os.replace(tmp,target)

class Exclusive:
    def __init__(self,path):self.path=path
    def __enter__(self):
        self.file=self.path.open('a+b');self.file.seek(0);self.file.write(b'0');self.file.flush();self.file.seek(0)
        try:
            if os.name=='nt':
                import msvcrt
                msvcrt.locking(self.file.fileno(),msvcrt.LK_NBLCK,1)
            else:
                import fcntl
                fcntl.flock(self.file,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except OSError:
            self.file.close();raise RuntimeError('Outro envio esta em andamento. Aguarde terminar.')
        return self
    def __exit__(self,*args):self.file.close()

def browser_endpoint(profile):
    try:
        port,websocket=(profile/'DevToolsActivePort').read_text().splitlines()[:2]
        if not port.isdigit() or not 1024<=int(port)<=65535:return None
        endpoint='http://127.0.0.1:'+port
        # Match this profile's unpredictable websocket identifier; do not attach
        # to an unrelated process which happens to reuse a stale port.
        with urlopen(endpoint+'/json/version',timeout=2) as response:data=json.load(response)
        if data['webSocketDebuggerUrl'].endswith(websocket):return endpoint
    except (OSError,ValueError,KeyError):pass
    return None

def connect_browser(p,root,folder):
    profile=root/'arquivos/chatgpt-browser/opera-gx-profile';profile.mkdir(parents=True,exist_ok=True)
    endpoint=browser_endpoint(profile)
    if not endpoint:
        executable=find_opera_gx(root)
        if executable is None:raise RuntimeError('Opera GX nao encontrado. Use Localizar Opera GX no ERP para indicar launcher.exe ou opera.exe.')
        subprocess.Popen([str(executable),'--remote-debugging-port=0','--remote-debugging-address=127.0.0.1','--user-data-dir='+str(profile),'--no-first-run','--no-default-browser-check','about:blank'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        deadline=time.monotonic()+30
        while not endpoint and time.monotonic()<deadline:
            time.sleep(.25);endpoint=browser_endpoint(profile)
        if not endpoint:raise RuntimeError('Nao foi possivel controlar o Opera GX. Feche apenas a janela Opera GX Fotos do ERP e tente novamente.')
    return p.chromium.connect_over_cdp(endpoint)

def fixed_page(browser,url):
    contexts=browser.contexts
    if not contexts:raise RuntimeError('Opera GX sem contexto disponivel.')
    pages=[page for context in contexts for page in context.pages if not page.is_closed()]
    matches=[page for page in pages if page.url.rstrip('/')==url]
    # The dedicated profile belongs to this feature. Never create another tab.
    page=matches[0] if matches else next((x for x in pages if 'chatgpt.com' in x.url),pages[0] if pages else None)
    if page is None:raise RuntimeError('Abra uma aba na janela Opera GX Fotos do ERP e tente novamente.')
    if page.url.rstrip('/')!=url:page.goto(url,wait_until='domcontentloaded',timeout=60000)
    page.bring_to_front()
    return page

def send(page,url,paths,prompt,folder):
    from playwright.sync_api import expect
    marker='ERP-FOTOS-'+folder.name
    message=prompt+'\n\nReferencia da tarefa: '+marker
    user_messages=page.locator('[data-message-author-role="user"]')
    receipt=user_messages.filter(has_text=marker)
    # Supports recovery after an interrupted acknowledgement, without a second send.
    if receipt.count():
        confirmed=(receipt.count()==1 and ' '.join(receipt.inner_text().split()).startswith(' '.join(message.split()))
                   and receipt.locator('img, [data-testid="file-thumbnail"]').count()==len(paths))
        status(folder,'ENVIADO' if confirmed else 'ENVIO_INCERTO',
               'Mensagem desta tarefa encontrada; prompt e todas as fotos confirmados. Nao foi reenviada.' if confirmed
               else 'Mensagem desta tarefa encontrada, mas os anexos nao foram confirmados. Confira o chat; nao sera reenviada.');return
    old=folder/'browser-send.json'
    if old.exists() and json.loads(old.read_text()).get('state') in ('CLICANDO_ENVIAR','ENVIO_INCERTO','ENVIADO'):
        raise RuntimeError('Esta tarefa ja teve tentativa de envio. Confira a conversa Fotos antes de preparar outra tarefa; nao sera reenviada automaticamente.')
    status(folder,'AGUARDANDO_LOGIN','Abra a janela Opera GX Fotos do ERP. Entre na sua conta e mantenha a conversa Fotos aberta. Aguardando ate 5 minutos.')
    composer=page.locator('#prompt-textarea')
    expect(composer).to_be_visible(timeout=300000)
    if page.url.rstrip('/')!=url:raise RuntimeError('O endereco mudou. Abra a conversa Fotos configurada; nenhuma mensagem foi enviada.')
    # A /local/ link can depend on browser storage. Do not send into an empty
    # page merely because its URL matches a conversation from another profile.
    try:
        expect(page).to_have_title(re.compile(r'\bfotos\b',re.I),timeout=10000)
    except Exception:
        heading=page.get_by_role('heading',name=re.compile(r'^fotos$',re.I))
        if not heading.count() or not heading.first.is_visible():
            raise RuntimeError('Nao foi possivel confirmar a conversa Fotos nesta janela. O link /local/ pode depender do perfil original. Abra a conversa Fotos no Opera GX do ERP; nada foi enviado.')
    if composer.inner_text().strip():raise RuntimeError('Ha um rascunho no chat Fotos. Envie ou limpe esse rascunho antes de tentar novamente.')
    attachments=page.locator('[data-testid="attachment-preview"], button[aria-label*="Remove"], button[aria-label*="Remover"]')
    if attachments.count():raise RuntimeError('Ha anexos anteriores no campo de mensagem. Remova-os antes de enviar pelo ERP.')
    stop=page.locator('[data-testid="stop-button"]')
    if stop.is_visible():raise RuntimeError('O ChatGPT ainda esta respondendo. Aguarde e tente novamente.')
    files=page.locator('input[type="file"]')
    candidates=[files.nth(i) for i in range(files.count()) if any(x in (files.nth(i).get_attribute('accept') or '').lower() for x in ('image','.png','.jpg','.jpeg','.webp'))]
    if not candidates:candidates=[files.nth(i) for i in range(files.count()) if not files.nth(i).get_attribute('accept')]
    if len(candidates)!=1:raise RuntimeError('Campo de anexar imagens nao identificado com seguranca. Nenhuma mensagem foi enviada; a interface do ChatGPT pode ter mudado.')
    status(folder,'ANEXANDO','Anexando as fotos na conversa Fotos. Aguarde a confirmacao do envio no ERP.')
    candidates[0].set_input_files([str(x) for x in paths])
    # Each selected file must have an attachment representation. Fail closed
    # instead of sending a bare prompt if the remote UI changes.
    page.wait_for_function('n => document.querySelectorAll(\'[data-testid="attachment-preview"], button[aria-label*="Remove"], button[aria-label*="Remover"]\').length >= n',arg=len(paths),timeout=120000)
    composer.fill(message)
    send_button=page.locator('[data-testid="send-button"], button[aria-label="Send prompt"], button[aria-label="Enviar prompt"]')
    expect(send_button).to_have_count(1,timeout=30000)
    expect(send_button).to_be_enabled(timeout=120000)
    expect(page.locator('[role="progressbar"]')).to_have_count(0,timeout=120000)
    if page.url.rstrip('/')!=url or composer.inner_text().split()!=message.split():raise RuntimeError('Conversa ou prompt alterado durante o preparo. Confira o rascunho; envio cancelado.')
    if attachments.count()<len(paths):raise RuntimeError('Uma foto desapareceu antes do envio. Confira os anexos no chat.')
    status(folder,'CLICANDO_ENVIAR','Anexos e prompt preparados. Confirmando envio; nao repita a operacao.')
    send_button.click(timeout=15000)
    try:
        expect(receipt).to_have_count(1,timeout=60000)
        if not ' '.join(receipt.inner_text().split()).startswith(' '.join(message.split())):raise RuntimeError('Prompt recebido diferente do preparado')
        expect(composer).to_be_empty(timeout=15000)
        # Acknowledged user turn must contain every uploaded image/file. This
        # catches remote upload failures even when a text turn was accepted.
        expect(receipt.locator('img, [data-testid="file-thumbnail"]')).to_have_count(len(paths),timeout=30000)
    except Exception:
        status(folder,'ENVIO_INCERTO','Nao foi possivel confirmar o prompt e todas as fotos na mensagem enviada. Confira a conversa Fotos. Nao ha reenvio automatico.');return
    status(folder,'ENVIADO',f'Envio confirmado na conversa Fotos: prompt e {len(paths)} foto(s). Aguarde a edicao no ChatGPT. O download dos resultados continua manual nesta versao.')

def main(root,job_id):
    store=PhotoJobs(root/'arquivos/chatgpt');folder=store.folder(job_id)
    try:
        with Exclusive(root/'arquivos/chatgpt-browser/send.lock'):
            url=load(root);job=store.get(job_id);paths=[]
            for entry in job['images']:
                path=store.inside(folder,entry['file'])
                if hashlib.sha256(path.read_bytes()).hexdigest()!=entry['sha256']:raise RuntimeError('Original alterado. Prepare uma nova tarefa.')
                paths.append(path)
            from playwright.sync_api import sync_playwright
            with sync_playwright() as p:
                browser=connect_browser(p,root,folder)
                # Disconnect on exit; do not close the persistent Opera GX window.
                page=fixed_page(browser,url);send(page,url,paths,job['prompt'],folder)
    except Exception as exc:
        current=json.loads((folder/'browser-send.json').read_text()) if (folder/'browser-send.json').exists() else {}
        state='ENVIO_INCERTO' if current.get('state') in ('CLICANDO_ENVIAR','ENVIO_INCERTO','ENVIADO') else 'ERRO'
        status(folder,state,'Envio nao confirmado. '+str(exc)[:800])
        return 1
    return 0

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--root',type=Path,required=True);parser.add_argument('--job',required=True);args=parser.parse_args()
    sys.exit(main(args.root.resolve(),args.job))
