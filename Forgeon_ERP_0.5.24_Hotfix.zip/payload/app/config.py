from pathlib import Path
import os, sys

APP_NAME = "Forgeon Studio ERP"
APP_VERSION = "0.5.24"

if getattr(sys, "frozen", False):
    APP_ROOT = Path(sys.executable).resolve().parent
    RESOURCE_ROOT = Path(getattr(sys, "_MEIPASS", APP_ROOT))
else:
    APP_ROOT = Path(os.environ.get("FORGEON_ERP_HOME", Path(__file__).resolve().parents[1]))
    RESOURCE_ROOT = APP_ROOT

DATA_DIR = APP_ROOT / "data"
DB_PATH = DATA_DIR / "forgeon.db"
FILES_DIR = APP_ROOT / "arquivos"
IMPORT_DIR = FILES_DIR / "importacoes"
EXPORT_DIR = FILES_DIR / "exportacoes"
BACKUP_DIR = APP_ROOT / "backups"
LOG_DIR = APP_ROOT / "logs"
ASSETS_DIR = RESOURCE_ROOT / "assets"
TEMPLATES_DIR = RESOURCE_ROOT / "templates"
ADS_DIR = FILES_DIR / "anuncios"
PHOTO_DIR = ADS_DIR / "fotos"

for d in (DATA_DIR, IMPORT_DIR, EXPORT_DIR, BACKUP_DIR, LOG_DIR):
    d.mkdir(parents=True, exist_ok=True)


SHOPEE_MAX_IMAGE_BYTES = int(os.environ.get("FORGEON_SHOPEE_MAX_IMAGE_BYTES", "1900000"))

AI_PROVIDER_CONFIG_PATH = APP_ROOT / "ai_provider_settings.json"
AI_PROVIDER_JOBS_DIR = ADS_DIR / "ai_jobs"

