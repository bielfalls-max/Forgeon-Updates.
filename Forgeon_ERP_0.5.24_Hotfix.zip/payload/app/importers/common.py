from __future__ import annotations
from pathlib import Path
from datetime import datetime
import hashlib, re, unicodedata

def num(v):
    if v is None or v=="" or v=="-": return 0.0
    if isinstance(v,(int,float)): return float(v)
    s=str(v).strip().replace("R$","").replace("%","").replace(" ","")
    if "," in s:
        s=s.replace(".","").replace(",",".")
    try:return float(s)
    except:return 0.0

def norm(s):
    s="" if s is None else str(s)
    s=unicodedata.normalize("NFKD",s).encode("ascii","ignore").decode("ascii")
    return " ".join(s.lower().strip().split())

def dt_iso(v):
    if v is None or v=="" or v=="-": return None
    if isinstance(v,datetime): return v.isoformat(timespec="minutes")
    s=str(v).strip()
    for fmt in ("%Y-%m-%d %H:%M","%Y-%m-%d %H:%M:%S","%d/%m/%Y %H:%M","%d/%m/%Y"):
        try:return datetime.strptime(s,fmt).isoformat(timespec="minutes")
        except:pass
    return None

def file_hash(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for ch in iter(lambda:f.read(1024*1024),b""): h.update(ch)
    return h.hexdigest()

def filename_period(path):
    m=re.search(r"(20\d{6})[_-](20\d{6})",Path(path).name)
    if not m:return (None,None)
    return (
      datetime.strptime(m.group(1),"%Y%m%d").date().isoformat(),
      datetime.strptime(m.group(2),"%Y%m%d").date().isoformat()
    )

def variant_key(sku, main_sku, variation, listing):
    sku=(sku or "").strip()
    main=(main_sku or "").strip()
    variation=(variation or "").strip()
    if sku:return f"SKU:{sku}"
    return f"MAIN:{main}|VAR:{norm(variation)}|LIST:{norm(listing)}"


def detect_shopee_file_type(path):
    """
    Retorna 'orders', 'stats' ou 'unknown' conforme a estrutura do arquivo.
    """
    from openpyxl import load_workbook
    wb = load_workbook(path, read_only=True, data_only=True)
    try:
        names = [str(n).strip().lower() for n in wb.sheetnames]
        if "orders" in names:return "orders"
        if any(n.startswith("produto pago") for n in names) and any(n.startswith("product contribution (paid") for n in names):return "stats"
        return "unknown"
    finally:wb.close()
