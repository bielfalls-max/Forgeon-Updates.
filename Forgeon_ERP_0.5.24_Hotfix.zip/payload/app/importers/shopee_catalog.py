"""Expose stats-only listings as explicitly incomplete product registrations."""
from datetime import datetime
from importers.common import norm

def ensure_stats_catalog(con):
    now=datetime.now().isoformat(timespec='seconds')
    setting=con.execute("SELECT value FROM settings WHERE key='default_packaging_cost'").fetchone();pack=float(setting[0] if setting else .30)
    listings=con.execute('''SELECT l.* FROM listings l WHERE l.shopee_item_id IS NOT NULL AND EXISTS(
        SELECT 1 FROM monthly_stats_products p WHERE p.shopee_item_id=l.shopee_item_id AND (p.units>0 OR p.sales>0))''').fetchall()
    by_name={}
    for row in listings:by_name.setdefault(norm(row['name']),[]).append(row['id'])
    for row in con.execute('SELECT id,listing_name FROM variants WHERE listing_id IS NULL').fetchall():
        candidates=by_name.get(norm(row['listing_name']),[])
        if len(candidates)==1:con.execute('UPDATE variants SET listing_id=? WHERE id=?',(candidates[0],row['id']))
    for listing in listings:
        key='STATS_ITEM:'+listing['shopee_item_id']
        real=con.execute("SELECT id FROM variants WHERE listing_id=? AND variant_key NOT LIKE 'STATS_ITEM:%' AND active=1",(listing['id'],)).fetchall()
        placeholder=con.execute('SELECT * FROM variants WHERE variant_key=?',(key,)).fetchone()
        if real:
            if placeholder:
                colors=con.execute('SELECT 1 FROM variant_colors WHERE variant_id=?',(placeholder['id'],)).fetchone()
                configured=colors or any(float(placeholder[field] or 0)>0 for field in ('weight_g','print_hours','manual_cost','other_cost'))
                if not configured:con.execute('UPDATE variants SET active=0 WHERE id=?',(placeholder['id'],))
            continue
        if placeholder:con.execute('UPDATE variants SET active=1,listing_id=? WHERE id=?',(listing['id'],placeholder['id']))
        else:
            con.execute('''INSERT INTO variants(variant_key,listing_id,listing_name,variation_name,boneco_name,packaging_cost,notes,created_at,updated_at)
                VALUES(?,?,?,?,?,?,?,?,?)''',(key,listing['id'],listing['name'],'Resumo do anúncio: variações não informadas',listing['name'],pack,
                'Cadastro do resumo mensal Shopee. O arquivo não informa SKU nem distribuição por variação. Importe Order.all para detalhar.',now,now))
