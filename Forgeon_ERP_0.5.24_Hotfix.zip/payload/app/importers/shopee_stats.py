from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from datetime import datetime
from openpyxl import load_workbook
import re, shutil

from config import IMPORT_DIR
from database import db, get_setting
from importers.common import num, file_hash, norm
from importers.shopee_catalog import ensure_stats_catalog

@dataclass
class StatsPreview:
    period_start:str
    period_end:str
    month_key:str
    orders:float
    units:float
    sales:float
    canceled:float
    refunded:float
    cards:float
    lives:float
    videos:float
    affiliate:float
    ads:float
    products:list
    warnings:list = field(default_factory=list)
    unit_source:str = "produtos"

def _find(wb,prefix):
    p=prefix.lower()
    for n in wb.sheetnames:
        if n.lower().startswith(p): return wb[n]
    return None

def _iso_date(s):
    return datetime.strptime(s,"%d/%m/%Y").date().isoformat()

def parse_stats(path):
    wb=load_workbook(path,data_only=True,read_only=True)
    try:
        paid=_find(wb,"Produto Pago");prods=_find(wb,"Product Contribution (paid");sources=_find(wb,"(Pedidos Pagos)Fontes de Tr")
        if paid is None:raise ValueError("Não encontrei a aba Produto Pago.")
        if prods is None:raise ValueError("Não encontrei Product Contribution (paid ...).")
        period=str(paid['A2'].value or '').replace(' ','')
        match=re.fullmatch(r'(\d{2}/\d{2}/\d{4})-(\d{2}/\d{2}/\d{4})',period)
        if not match:raise ValueError('Período inválido em Produto Pago!A2: '+period)
        start,end=_iso_date(match[1]),_iso_date(match[2]);products={}
        for row in prods.iter_rows(min_row=6,values_only=True):
            item=str(row[0] or '').strip()
            if isinstance(row[0],(int,float)) and float(row[0]).is_integer():item=str(int(row[0]))
            if not(item.isdigit() and len(item)>=6):continue
            entry=products.setdefault(item,{'item_id':item,'name':str(row[1] or '').strip(),'sales':0.,'orders':0.,'units':0.})
            entry['sales']+=num(row[4]);entry['orders']+=num(row[7]);entry['units']+=num(row[8])
        sales=num(paid['B2'].value);product_units=sum(entry['units'] for entry in products.values());units=product_units
        source='produtos';warnings=[];channel_totals=[]
        for sheet in wb:
            if not norm(sheet.title).startswith('(pedido pago)'):continue
            for row in sheet.iter_rows(values_only=True):
                if norm(row[0]) in {'card do produto','lives','video do vendedor','afiliado shopee'} and len(row)>6 and row[6] is not None:
                    channel_totals.append((num(row[2]),num(row[6])))
        if channel_totals and abs(sum(value for value,_ in channel_totals)-sales)<.02:
            units=sum(value for _,value in channel_totals);source='fontes de tráfego pagas'
        if abs(units-product_units)>.001:warnings.append(f"Fontes pagas: {units:g} unidades; produtos identificados: {product_units:g}. Diferença sem identificação individual: {units-product_units:g}.")
        channels=[num(sources.cell(2,column).value) if sources else 0 for column in range(4,9)]
        return StatsPreview(start,end,start[:7],num(paid['D2'].value),units,sales,num(paid['I2'].value),num(paid['K2'].value),*channels,list(products.values()),warnings,source)
    finally:wb.close()

def import_stats(path):
    path=Path(path); p=parse_stats(path)
    digest=file_hash(path); now=datetime.now().isoformat(timespec="seconds")
    archive=IMPORT_DIR/"shopee"/"estatisticas"/p.month_key.replace("-","_")
    archive.mkdir(parents=True,exist_ok=True)
    dest=archive/f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{path.name}"
    shutil.copy2(path,dest)
    with db() as con:
        con.execute("""INSERT INTO monthly_stats(
          month_key,period_start,period_end,paid_orders,paid_units,paid_sales,canceled_orders,refunded_orders,
          card_sales,live_sales,video_sales,affiliate_sales,ads_sales,source_file,source_hash,imported_at
        ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        ON CONFLICT(month_key) DO UPDATE SET
          period_start=excluded.period_start,period_end=excluded.period_end,paid_orders=excluded.paid_orders,
          paid_units=excluded.paid_units,paid_sales=excluded.paid_sales,canceled_orders=excluded.canceled_orders,
          refunded_orders=excluded.refunded_orders,card_sales=excluded.card_sales,live_sales=excluded.live_sales,
          video_sales=excluded.video_sales,affiliate_sales=excluded.affiliate_sales,ads_sales=excluded.ads_sales,
          source_file=excluded.source_file,source_hash=excluded.source_hash,imported_at=excluded.imported_at""",
          (p.month_key,p.period_start,p.period_end,p.orders,p.units,p.sales,p.canceled,p.refunded,p.cards,p.lives,
           p.videos,p.affiliate,p.ads,path.name,digest,now))
        con.execute("DELETE FROM monthly_stats_products WHERE month_key=?",(p.month_key,))
        if p.products:
            con.executemany("INSERT INTO monthly_stats_products(month_key,shopee_item_id,product_name,orders,units,sales) VALUES (?,?,?,?,?,?)",
                            [(p.month_key,x["item_id"],x["name"],x["orders"],x["units"],x["sales"]) for x in p.products])

        existing={r["shopee_item_id"]:r["id"] for r in con.execute("SELECT id,shopee_item_id FROM listings WHERE shopee_item_id IS NOT NULL").fetchall()}
        updates=[]; inserts=[]
        for x in p.products:
            lid=existing.get(x["item_id"])
            if lid: updates.append((x["name"],now,lid))
            else: inserts.append((x["item_id"],x["name"],now,now))
        if updates: con.executemany("UPDATE listings SET name=?,updated_at=? WHERE id=?",updates)
        if inserts: con.executemany("INSERT INTO listings(shopee_item_id,name,created_at,updated_at) VALUES (?,?,?,?)",inserts)

        ensure_stats_catalog(con)

        con.execute("INSERT INTO imports(source_type,file_name,file_hash,period_start,period_end,month_keys,archived_path,imported_at) VALUES (?,?,?,?,?,?,?,?)",
                    ("shopee_stats",path.name,digest,p.period_start,p.period_end,p.month_key,str(dest),now))
    return p,dest

