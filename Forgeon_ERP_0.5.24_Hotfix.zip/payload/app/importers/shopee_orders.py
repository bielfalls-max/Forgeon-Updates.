from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from datetime import datetime
from openpyxl import load_workbook
import shutil,hashlib

from config import IMPORT_DIR
from database import db, get_setting
from importers.shopee_catalog import ensure_stats_catalog
from importers.common import num,norm,dt_iso,file_hash,filename_period,variant_key

@dataclass
class OrdersPreview:
    period_start:str|None
    period_end:str|None
    month_keys:list
    unique_orders:int
    lines:int
    units:float
    gross_subtotal:float
    actual_fees:float
    statuses:dict
    scope:str = "orders"
    warnings:list = field(default_factory=list)

def _headers(ws):
    return {norm(ws.cell(1,c).value):c for c in range(1,ws.max_column+1)}

def _col(h,*names):
    for n in names:
        k=norm(n)
        if k in h:return h[k]
    return None

def parse_orders(path):
    wb=load_workbook(path,data_only=True,read_only=False)
    try:
        if "orders" not in wb.sheetnames: raise ValueError("A planilha não contém a aba 'orders'.")
        ws=wb["orders"]
        header_values=next(ws.iter_rows(min_row=1,max_row=1,values_only=True))
        h={norm(v):i for i,v in enumerate(header_values) if v is not None}
        def idx(*names):
            for n in names:
                k=norm(n)
                if k in h:return h[k]
            return None
        required=["ID do pedido","Status do pedido","Data de criação do pedido","Nome do Produto","Quantidade"]
        missing=[x for x in required if idx(x) is None]
        if missing: raise ValueError("Colunas ausentes: "+", ".join(missing))
        c={
          "order":idx("ID do pedido"),"status":idx("Status do pedido"),"ret":idx("Status da Devolução / Reembolso"),
          "created":idx("Data de criação do pedido"),"paid":idx("Hora do pagamento do pedido"),
          "main_sku":idx("Nº de referência do SKU principal","No de referência do SKU principal"),
          "listing":idx("Nome do Produto"),"sku":idx("Número de referência SKU","Numero de referência SKU"),
          "variation":idx("Nome da variação","Nome da variacao"),"orig":idx("Preço original","Preco original"),
          "agreed":idx("Preço acordado","Preco acordado"),"qty":idx("Quantidade"),
          "returned":idx("Returned quantity"),"subtotal":idx("Subtotal do produto"),
          "order_value":idx("Valor Total"),"reverse":idx("Taxa de Envio Reversa"),
          "trans":idx("Taxa de transação","Taxa de transacao"),"commission":idx("Taxa de comissão líquida","Taxa de comissao liquida"),
          "service":idx("Taxa de serviço líquida","Taxa de servico liquida"),
        }
        def get(vals,key):
            i=c.get(key)
            return vals[i] if i is not None and i < len(vals) else None

        rows=[];orders={};statuses={};dates=[];units=subtotal=0;line_counts={}
        for vals in ws.iter_rows(min_row=2,values_only=True):
            oid=str(get(vals,"order") or "").strip()
            if not oid:continue
            status=str(get(vals,"status") or "").strip();statuses[status]=statuses.get(status,0)+1
            created=dt_iso(get(vals,"created"));paid=dt_iso(get(vals,"paid")) if c["paid"] is not None else None
            date_ref=paid or created
            if date_ref:dates.append(date_ref[:10])
            main=str(get(vals,"main_sku") or "").strip();listing=str(get(vals,"listing") or "").strip()
            sku=str(get(vals,"sku") or "").strip();variation=str(get(vals,"variation") or "").strip()
            vkey=variant_key(sku,main,variation,listing);line_counts[oid]=line_counts.get(oid,0)+1
            row={
              "order_id":oid,"status":status,"return_status":str(get(vals,"ret") or "").strip(),
              "created_at":created,"paid_at":paid,"main_sku":main,"listing_name":listing,
              "sku":sku,"variation_name":variation,"variant_key":vkey,"line_index":line_counts[oid],
              "quantity":num(get(vals,"qty")),"returned_quantity":num(get(vals,"returned")),
              "original_price":num(get(vals,"orig")),"agreed_price":num(get(vals,"agreed")),
              "subtotal":num(get(vals,"subtotal")),"order_value":num(get(vals,"order_value")),
              "reverse":num(get(vals,"reverse")),"transaction":num(get(vals,"trans")),
              "commission":num(get(vals,"commission")),"service":num(get(vals,"service")),
            }
            rows.append(row);units+=row["quantity"];subtotal+=row["subtotal"]
            if oid not in orders:orders[oid]=row
        start,end=filename_period(path)
        if not start and dates:start=min(dates)
        if not end and dates:end=max(dates)
        month_keys=sorted({(x["paid_at"] or x["created_at"] or "")[:7] for x in rows if (x["paid_at"] or x["created_at"])})
        fees=sum(o["reverse"]+o["transaction"]+o["commission"]+o["service"] for o in orders.values())
        scope='toship' if 'toship' in Path(path).name.lower() else 'all' if 'order.all' in Path(path).name.lower() else 'orders'
        warnings=[]
        if scope=='toship':warnings.append('Arquivo A Enviar: contém somente pedidos aguardando envio, não todas as vendas do mês. Para detalhar todas as variações, exporte Todos os pedidos (Order.all) na Shopee.')
        if not rows:warnings.append('Arquivo sem pedidos; nenhum pedido existente será removido.')
        return OrdersPreview(start,end,month_keys,len(orders),len(rows),units,subtotal,fees,statuses,scope,warnings),rows,orders
    finally:
        wb.close()

def import_orders(path):
    path=Path(path); preview,rows,orders=parse_orders(path)
    digest=file_hash(path); now=datetime.now().isoformat(timespec="seconds")
    archive=IMPORT_DIR/"shopee"/"pedidos"/((preview.period_start or "sem_data")[:7].replace("-","_"))
    archive.mkdir(parents=True,exist_ok=True)
    dest=archive/f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{path.name}"
    shutil.copy2(path,dest)

    with db() as con:
        setting=con.execute("SELECT value FROM settings WHERE key='default_packaging_cost'").fetchone()
        pack_default=float(setting["value"] if setting else 0.30)

        # Resolve SKU collisions without collapsing different characters. Existing
        # imported costs/IDs are preserved, and conflicting SKUs remain reviewable.
        known=[dict(row) for row in con.execute('SELECT * FROM variants')]
        for row in rows:
            sku=row['sku'];identity=norm(row['variation_name'] or row['listing_name'])
            matches=[v for v in known if sku and str(v['sku'] or '').casefold()==sku.casefold() and norm(v['variation_name'] or v['listing_name'])==identity]
            if matches:row['variant_key']=matches[0]['variant_key']
            elif sku and any(v['variant_key']==row['variant_key'] for v in known):
                suffix=hashlib.sha256((norm(row['listing_name'])+'|'+identity).encode()).hexdigest()[:12]
                row['variant_key']=f'SKU:{sku}|VAR:{suffix}'
            if not any(v['variant_key']==row['variant_key'] for v in known):known.append(row)
        # Replace line items only for IDs present in this import, never a month.
        if orders:
            ids=list(orders)
            for offset in range(0,len(ids),400):
                batch=ids[offset:offset+400];marks=','.join('?' for _ in batch)
                con.execute(f'DELETE FROM order_items WHERE order_id IN ({marks})',batch)

        # Pedidos em lote.
        order_values=[]
        for oid,o in orders.items():
            ref=o["paid_at"] or o["created_at"]; month=(ref or "")[:7]
            fees=o["reverse"]+o["transaction"]+o["commission"]+o["service"]
            order_values.append((oid,month,o["status"],o["return_status"],o["created_at"],o["paid_at"],o["main_sku"],o["listing_name"],
                                 o["order_value"],o["reverse"],o["transaction"],o["commission"],o["service"],fees,path.name,now))
        con.executemany("""INSERT INTO orders(
          order_id,month_key,status,return_status,created_at,paid_at,main_sku,listing_name,order_value,
          reverse_shipping_fee,transaction_fee,commission_fee,service_fee,total_platform_fee,source_file,imported_at
        ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        ON CONFLICT(order_id) DO UPDATE SET month_key=excluded.month_key,status=excluded.status,return_status=excluded.return_status,
        created_at=excluded.created_at,paid_at=excluded.paid_at,main_sku=excluded.main_sku,listing_name=excluded.listing_name,
        order_value=excluded.order_value,reverse_shipping_fee=excluded.reverse_shipping_fee,transaction_fee=excluded.transaction_fee,
        commission_fee=excluded.commission_fee,service_fee=excluded.service_fee,total_platform_fee=excluded.total_platform_fee,
        source_file=excluded.source_file,imported_at=excluded.imported_at""",order_values)

        item_values=[(r["order_id"],r["line_index"],r["variant_key"],r["sku"],r["main_sku"],r["listing_name"],r["variation_name"],
                      r["quantity"],r["returned_quantity"],r["original_price"],r["agreed_price"],r["subtotal"]) for r in rows]
        con.executemany("""INSERT INTO order_items(order_id,line_index,variant_key,sku,main_sku,listing_name,variation_name,
          quantity,returned_quantity,original_price,agreed_price,subtotal) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",item_values)

        # Atualiza cada variante apenas uma vez, não uma vez por linha de pedido.
        meta={}
        for r in rows:
            meta[r["variant_key"]]=r
        existing={r["variant_key"]:r for r in con.execute("SELECT id,variant_key,boneco_name FROM variants").fetchall()}
        listings={str(r["name"] or "").strip().lower():r["id"] for r in con.execute("SELECT id,name FROM listings").fetchall()}

        updates=[]; inserts=[]
        for vkey,r in meta.items():
            listing_id=listings.get(str(r["listing_name"] or "").strip().lower())
            old=existing.get(vkey)
            if old:
                updates.append((listing_id,r["sku"],r["main_sku"],r["listing_name"],r["variation_name"],
                                r["variation_name"] or r["listing_name"],now,old["id"]))
            else:
                inserts.append((listing_id,vkey,r["sku"],r["main_sku"],r["listing_name"],r["variation_name"],
                                r["variation_name"] or r["listing_name"],pack_default,now,now))
        if updates:
            con.executemany("""UPDATE variants SET listing_id=COALESCE(?,listing_id),sku=?,main_sku=?,listing_name=?,variation_name=?,
                boneco_name=COALESCE(NULLIF(TRIM(boneco_name),''),?),updated_at=? WHERE id=?""",updates)
        if inserts:
            con.executemany("""INSERT INTO variants(listing_id,variant_key,sku,main_sku,listing_name,variation_name,boneco_name,packaging_cost,created_at,updated_at)
                VALUES (?,?,?,?,?,?,?,?,?,?)""",inserts)

        ensure_stats_catalog(con)
        from services.sku_catalog import sync_existing
        sync_existing(con)

        con.execute("INSERT INTO imports(source_type,file_name,file_hash,period_start,period_end,month_keys,archived_path,imported_at) VALUES (?,?,?,?,?,?,?,?)",
                    ("shopee_orders",path.name,digest,preview.period_start,preview.period_end,",".join(preview.month_keys),str(dest),now))
    return preview,dest

