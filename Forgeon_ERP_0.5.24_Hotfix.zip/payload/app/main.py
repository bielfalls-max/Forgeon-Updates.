from __future__ import annotations
import sys,logging,re,shutil,unicodedata
from pathlib import Path
from datetime import datetime
from PySide6.QtCore import Qt,QDate,QTimer,QObject,QThread,Signal,QLocale
from PySide6.QtGui import QPixmap,QIcon,QColor,QKeySequence,QShortcut
from PySide6.QtWidgets import *

from config import APP_ROOT,APP_NAME,APP_VERSION,ASSETS_DIR,LOG_DIR,PHOTO_DIR,TEMPLATES_DIR,EXPORT_DIR
from database import initialize_database,db,all_settings,set_setting,get_setting,create_backup,DEFAULT_COLORS,sync_variant_weight_from_colors
from importers.shopee_stats import parse_stats,import_stats
from importers.shopee_orders import parse_orders,import_orders
from importers.common import detect_shopee_file_type
from importers.bambu_3mf import parse_3mf,parse_print_file,ThreeMFError,ThreeMFNotSlicedError,format_duration,aggregate_plate_filaments,project_totals
from services.reporting import month_report,actual_orders_preview,variant_unit_cost,top_bonecos,filament_usage_month_and_fortnight,variant_color_summary
from ui.widgets import MetricCard,MultiLineChart,BarsChart
from ui.forgeon_pro_theme import PRO_STYLE as STYLE

logging.basicConfig(filename=LOG_DIR/"forgeon.log",level=logging.INFO,format="%(asctime)s %(levelname)s %(message)s")


def brl(v):
    s=f"{float(v or 0):,.2f}".replace(",","X").replace(".",",").replace("X",".")
    return "R$ "+s

def _mapping_norm(text):
    value=unicodedata.normalize("NFKD",str(text or "")).encode("ascii","ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+"," ",value).strip()

def month_label(k):
    ms=["Jan","Fev","Mar","Abr","Mai","Jun","Jul","Ago","Set","Out","Nov","Dez"]
    try:y,m=map(int,k.split("-"));return f"{ms[m-1]}/{str(y)[2:]}"
    except:return k

class ProductDialog(QDialog):
    def __init__(self,parent,row=None):
        super().__init__(parent);self.row=row;self.setWindowTitle("Produto / variação");self.resize(560,520)
        f=QFormLayout(self)
        self.boneco=QLineEdit();self.sku=QLineEdit();self.main=QLineEdit();self.listing=QLineEdit();self.var=QLineEdit()
        for imported in (self.sku,self.main,self.listing,self.var):
            imported.setReadOnly(row is not None)
            if row is not None:imported.setToolTip("Identificador existente preservado para manter os vínculos das importações.")
        self.reserved_sku=None
        if row is None:
            reserve_button=QPushButton("ESCOLHER SKU RESERVADO");reserve_button.clicked.connect(self.choose_reserved_sku);f.addRow(reserve_button)
        self.weight=QDoubleSpinBox();self.weight.setRange(0,100000);self.weight.setDecimals(2)
        self.hours=QDoubleSpinBox();self.hours.setRange(0,10000);self.hours.setDecimals(2)
        self.manual=QDoubleSpinBox();self.manual.setRange(0,100000);self.manual.setDecimals(2);self.manual.setPrefix("R$ ")
        self.pack=QDoubleSpinBox();self.pack.setRange(0,10000);self.pack.setDecimals(2);self.pack.setPrefix("R$ ")
        self.other=QDoubleSpinBox();self.other.setRange(0,100000);self.other.setDecimals(2);self.other.setPrefix("R$ ")
        self.notes=QTextEdit();self.notes.setFixedHeight(70)
        for label,w in [("Boneco",self.boneco),("SKU",self.sku),("SKU principal",self.main),("Anúncio",self.listing),("Variação Shopee",self.var),
                        ("Peso total (g)",self.weight),("Horas de impressão",self.hours),("Custo manual",self.manual),
                        ("Embalagem",self.pack),("Outros custos",self.other),("Observações",self.notes)]: f.addRow(label,w)
        bb=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);bb.accepted.connect(self.accept);bb.rejected.connect(self.reject);f.addRow(bb)
        if row:
            self.boneco.setText(row["boneco_name"] or row["variation_name"] or "")
            self.sku.setText(row["sku"] or "");self.main.setText(row["main_sku"] or "");self.listing.setText(row["listing_name"] or "")
            self.var.setText(row["variation_name"] or "")
            with db() as con:
                cr=con.execute("SELECT COUNT(*) qtd,COALESCE(SUM(grams_per_unit),0) total FROM variant_colors WHERE variant_id=?",(row["id"],)).fetchone()
            color_count=int(cr["qtd"] or 0);color_total=float(cr["total"] or 0)
            self.weight.setValue(color_total if color_count else float(row["weight_g"] or 0))
            if color_count:
                self.weight.setReadOnly(True)
                self.weight.setToolTip("Peso automático: soma das gramas cadastradas em Cores / Gramas.")
            else:
                self.weight.setToolTip("Sem cores cadastradas: o peso pode ser informado manualmente.")
            self.hours.setValue(float(row["print_hours"] or 0))
            self.manual.setValue(float(row["manual_cost"] or 0));self.pack.setValue(float(row["packaging_cost"] or 0));self.other.setValue(float(row["other_cost"] or 0))
            self.notes.setPlainText(row["notes"] or "")
    def choose_reserved_sku(self):
        from services.sku_catalog import reservations
        rows=reservations()
        if not rows:QMessageBox.information(self,"SKUs","Reserve um código em Vínculos de SKU antes de escolher.");return
        labels=[f"{row['sku']} — {row['product_name']}" for row in rows]
        label,ok=QInputDialog.getItem(self,"SKU reservado","Escolha o código:",labels,0,False)
        if ok:
            selected=rows[labels.index(label)];self.sku.setText(selected['sku']);self.reserved_sku=selected['sku']
            if not self.boneco.text():self.boneco.setText(selected['product_name'])

    def values(self):
        return dict(reserved_sku=self.reserved_sku==self.sku.text().strip(),boneco_name=self.boneco.text().strip(),sku=self.sku.text().strip(),main_sku=self.main.text().strip(),listing_name=self.listing.text().strip(),
                    variation_name=self.var.text().strip(),weight_g=self.weight.value(),print_hours=self.hours.value(),
                    manual_cost=self.manual.value(),packaging_cost=self.pack.value(),other_cost=self.other.value(),notes=self.notes.toPlainText().strip())

class ColorUsageDialog(QDialog):
    MAX_COLORS=8
    def __init__(self,parent,variant_id,title):
        super().__init__(parent);self.variant_id=variant_id
        self.setWindowTitle(f"Cores / gramas • {title}");self.resize(580,545)
        root=QVBoxLayout(self)
        hint=QLabel("Informe até 8 cores e quantos gramas de cada cor são usados em UMA unidade desse boneco.")
        hint.setWordWrap(True);hint.setObjectName("Hint");root.addWidget(hint)
        self.rows=[]
        grid=QGridLayout();grid.addWidget(QLabel("Cor"),0,0);grid.addWidget(QLabel("g / peça"),0,1)
        with db() as con:
            saved=con.execute("SELECT slot,color_name,grams_per_unit FROM variant_colors WHERE variant_id=? ORDER BY slot",(variant_id,)).fetchall()
        saved_map={int(r["slot"]):(r["color_name"],float(r["grams_per_unit"])) for r in saved}
        for i in range(self.MAX_COLORS):
            combo=QComboBox();combo.setEditable(True);combo.addItem("");combo.addItems(DEFAULT_COLORS)
            grams=QDoubleSpinBox();grams.setRange(0,10000);grams.setDecimals(2);grams.setSuffix(" g")
            if (i+1) in saved_map:
                c,g=saved_map[i+1];combo.setCurrentText(c);grams.setValue(g)
            grams.valueChanged.connect(self.update_total)
            grid.addWidget(combo,i+1,0);grid.addWidget(grams,i+1,1);self.rows.append((combo,grams))
        root.addLayout(grid)

        total_box=QFrame();total_box.setObjectName("Panel")
        total_layout=QHBoxLayout(total_box);total_layout.setContentsMargins(12,8,12,8)
        total_layout.addWidget(QLabel("PESO AUTOMÁTICO DA PEÇA"))
        total_layout.addStretch()
        self.total_weight_label=QLabel("0.0 g")
        self.total_weight_label.setStyleSheet("font-size:15pt;font-weight:800;color:#ff7a00")
        total_layout.addWidget(self.total_weight_label)
        root.addWidget(total_box)

        auto_hint=QLabel("O peso acima é a soma das cores e será gravado automaticamente na coluna Peso ao salvar.")
        auto_hint.setObjectName("Hint");auto_hint.setWordWrap(True);root.addWidget(auto_hint)

        bb=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);bb.accepted.connect(self.save_and_accept);bb.rejected.connect(self.reject);root.addWidget(bb)
        self.update_total()

    def update_total(self,*_):
        total=sum(grams.value() for _,grams in self.rows)
        self.total_weight_label.setText(f"{total:.1f} g")

    def save_and_accept(self):
        vals=[]
        for slot,(combo,grams) in enumerate(self.rows,1):
            color=combo.currentText().strip();g=grams.value()
            if color and g>0:vals.append((slot,color,g))
        if len(vals)>8:
            QMessageBox.warning(self,"Cores","Máximo de 8 cores.");return
        with db() as con:
            con.execute("DELETE FROM variant_colors WHERE variant_id=?",(self.variant_id,))
            for slot,color,g in vals:
                con.execute("INSERT INTO variant_colors(variant_id,slot,color_name,grams_per_unit) VALUES (?,?,?,?)",(self.variant_id,slot,color,g))
            total=sync_variant_weight_from_colors(con,self.variant_id)
        if total is not None:
            QMessageBox.information(self,"Peso atualizado",f"Peso atualizado automaticamente para {total:.1f} g.")
        self.accept()


class ThreeMFImportDialog(QDialog):
    """Pré-visualiza um 3MF fatiado e, por padrão, soma TODAS as placas do projeto."""
    def __init__(self,parent,result,target_title,packaging=0.30,other=0.0,new_product=False,default_name="",default_sku=""):
        super().__init__(parent)
        self.result=result;self.target_title=target_title;self.packaging=float(packaging or 0);self.other=float(other or 0)
        self.new_product=bool(new_product)
        self.setWindowTitle(f"Importar 3MF • {target_title}");self.resize(940,720)
        root=QVBoxLayout(self)

        head=QLabel(f"Destino: {target_title}")
        head.setStyleSheet("font-size:14pt;font-weight:700;color:#efbf62")
        root.addWidget(head)
        hint=QLabel(
            "Por padrão o ERP soma TODAS as placas do 3MF: todas as cores, todos os gramas e o tempo de impressão de cada placa. "
            "Assim o custo representa o personagem completo, mesmo quando as peças estão divididas em várias placas."
        )
        hint.setObjectName("Hint");hint.setWordWrap(True);root.addWidget(hint)

        self.product_name=None;self.product_sku=None;self.reserved_sku=None
        if self.new_product:
            identity=QFrame();identity.setObjectName("Panel")
            ident=QFormLayout(identity);ident.setContentsMargins(12,10,12,10)
            self.product_name=QLineEdit(default_name)
            self.product_name.setPlaceholderText("Ex.: Tails articulado")
            self.product_sku=QLineEdit(default_sku)
            self.product_sku.setPlaceholderText("Opcional — pode deixar vazio se ainda não vende na Shopee")
            ident.addRow("Nome do produto",self.product_name)
            ident.addRow("SKU (opcional)",self.product_sku)
            reserved=QPushButton("ESCOLHER SKU RESERVADO");reserved.clicked.connect(self.choose_reserved_sku);ident.addRow(reserved)
            root.addWidget(identity)

        controls=QHBoxLayout()
        self.scope=QComboBox()
        total_seconds=sum(max(0.0,p.prediction_seconds) for p in result.plates)
        total_g=sum(max(0.0,p.total_filament_g) for p in result.plates)
        self.scope.addItem(
            f"PROJETO INTEIRO • {len(result.plates)} placas • {format_duration(total_seconds)} • {total_g:.1f} g",
            "all"
        )
        for i,p in enumerate(result.plates):
            self.scope.addItem(
                f"Somente Placa {p.index} • {format_duration(p.prediction_seconds)} • {p.total_filament_g:.1f} g",
                i
            )
        self.qty=QSpinBox();self.qty.setRange(1,99);self.qty.setValue(1);self.qty.setSuffix(" un.")
        self.qty.setToolTip("Use valor maior que 1 somente se o 3MF inteiro contiver mais de um boneco completo igual.")
        self.auto_cost=QCheckBox("Usar custo automático do 3MF")
        self.auto_cost.setChecked(True)
        self.auto_cost.setToolTip("Ao aplicar, zera eventual custo manual para o cálculo usar peso + horas + parâmetros globais.")
        controls.addWidget(QLabel("Importar:"));controls.addWidget(self.scope,2)
        controls.addWidget(QLabel("Bonecos completos iguais no 3MF:"));controls.addWidget(self.qty);controls.addWidget(self.auto_cost)
        root.addLayout(controls)

        self.meta=QLabel();self.meta.setObjectName("Hint");self.meta.setWordWrap(True);root.addWidget(self.meta)

        self.table=QTableWidget(0,5)
        self.table.setHorizontalHeaderLabels(["Cor no ERP","Cor 3MF","Material","Total selecionado","Por boneco"])
        self.table.verticalHeader().setVisible(False);self.table.setAlternatingRowColors(True)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(0,QHeaderView.Stretch)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        root.addWidget(self.table,1)
        self.color_combos=[];self.display_filaments=[]

        summary=QFrame();summary.setObjectName("Panel");sg=QGridLayout(summary);sg.setContentsMargins(14,10,14,10)
        self.sum_weight=QLabel("—");self.sum_hours=QLabel("—");self.sum_cost=QLabel("—");self.sum_price=QLabel("—");self.sum_profit=QLabel("—")
        for w in [self.sum_weight,self.sum_hours,self.sum_cost,self.sum_price,self.sum_profit]:w.setStyleSheet("font-size:13pt;font-weight:800")
        pairs=[("Peso total por boneco",self.sum_weight),("Horas totais por boneco",self.sum_hours),("Custo total estimado",self.sum_cost),("Preço sugerido Shopee",self.sum_price),("Lucro estimado",self.sum_profit)]
        for i,(label,w) in enumerate(pairs):
            a=QLabel(label);a.setObjectName("Hint");sg.addWidget(a,0,i);sg.addWidget(w,1,i)
        root.addWidget(summary)

        caution=QLabel(
            "Projeto inteiro = soma das placas. Se a Placa 1 usa amarelo, a Placa 2 usa branco e a Placa 3 usa preto, "
            "as três cores entram juntas no cadastro. Cores repetidas em várias placas são somadas. Suportes, purga e trocas de cor continuam incluídos."
        )
        caution.setObjectName("Hint");caution.setWordWrap(True);root.addWidget(caution)

        # IMPORTANTE: usar Ok/AcceptRole. O botão Apply tem ApplyRole e NÃO dispara
        # o sinal accepted() do QDialogButtonBox, por isso na v0.2.9 o clique parecia não fazer nada.
        bb=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel)
        self.import_button=bb.button(QDialogButtonBox.Ok)
        self.import_button.setText("IMPORTAR TUDO E PRECIFICAR")
        bb.accepted.connect(self.accept_validated);bb.rejected.connect(self.reject);root.addWidget(bb)

        self.scope.currentIndexChanged.connect(self.rebuild)
        self.qty.valueChanged.connect(self.update_summary)
        self.rebuild()

    def choose_reserved_sku(self):
        from services.sku_catalog import reservations
        rows=reservations()
        if not rows:QMessageBox.information(self,"SKUs","Reserve um código em Vínculos de SKU.");return
        labels=[f"{row['sku']} — {row['product_name']}" for row in rows]
        label,ok=QInputDialog.getItem(self,"SKU reservado","Escolha o código:",labels,0,False)
        if ok:
            row=rows[labels.index(label)];self.reserved_sku=row['sku'];self.product_sku.setText(row['sku'])
            if row['product_name']:self.product_name.setText(row['product_name'])

    def selected_plates(self):
        data=self.scope.currentData()
        if data=="all":
            return list(self.result.plates)
        try:
            return [self.result.plates[int(data)]]
        except Exception:
            return list(self.result.plates)

    def aggregate_filaments(self):
        """Agrupa a mesma cor/material quando ela aparece em várias placas."""
        return aggregate_plate_filaments(self.selected_plates())

    def rebuild(self,*_):
        plates=self.selected_plates();self.color_combos=[];self.display_filaments=self.aggregate_filaments()
        self.table.setRowCount(len(self.display_filaments))
        for r,f in enumerate(self.display_filaments):
            combo=QComboBox();combo.setEditable(True);combo.addItems(DEFAULT_COLORS)
            friendly=f.friendly_name
            if combo.findText(friendly)<0:combo.addItem(friendly)
            combo.setCurrentText(friendly)
            combo.currentTextChanged.connect(self.update_summary)
            self.table.setCellWidget(r,0,combo);self.color_combos.append(combo)
            swatch=QTableWidgetItem(f.hex_color or "—")
            if f.hex_color:
                swatch.setBackground(QColor(f.hex_color));rgb=QColor(f.hex_color)
                swatch.setForeground(QColor("#000000") if rgb.lightness()>150 else QColor("#ffffff"))
            self.table.setItem(r,1,swatch)
            self.table.setItem(r,2,QTableWidgetItem(f.filament_type or "—"))
            self.table.setItem(r,3,QTableWidgetItem(f'{f.used_g:.2f} g'))
            self.table.setItem(r,4,QTableWidgetItem(""))

        printers=sorted({p.printer_model_id for p in plates if p.printer_model_id})
        nozzles=sorted({str(p.nozzle_diameters) for p in plates if p.nozzle_diameters})
        objects=[]
        for p in plates:
            for obj in p.objects:
                if obj not in objects:objects.append(obj)
        plate_ids=", ".join(str(p.index) for p in plates)
        objs=", ".join(objects[:6]) if objects else "não informado"
        self.meta.setText(
            f"Arquivo: {Path(self.result.file_path).name}  •  Placas incluídas: {plate_ids}  •  "
            f"Impressora: {', '.join(printers) or 'não informada'}  •  Bico: {', '.join(nozzles) or '—'} mm  •  "
            f"Objetos: {objs}"
        )
        self.update_summary()

    def mapped_colors(self):
        qty=max(1,self.qty.value());agg={}
        for i,f in enumerate(self.display_filaments):
            name=self.color_combos[i].currentText().strip() or f.friendly_name or f.hex_color or f"Cor {i+1}"
            agg[name]=agg.get(name,0.0)+max(0.0,f.used_g)/qty
        return [(name,g) for name,g in sorted(agg.items(),key=lambda x:x[1],reverse=True) if g>0]

    def estimate(self):
        plates=self.selected_plates();qty=max(1,self.qty.value())
        colors=self.mapped_colors();weight=sum(g for _,g in colors)
        hours=sum(p.print_hours for p in plates)/qty
        s=all_settings()
        filament=weight*float(s.get("filament_price_kg",0))/1000
        energy=hours*(float(s.get("printer_power_w",0))/1000)*float(s.get("energy_price_kwh",0))
        machine=hours*float(s.get("machine_hour_cost",0))
        labor=float(s.get("labor_cost",0));subtotal=filament+energy+machine+labor+self.other
        production=subtotal*(1+float(s.get("failure_rate_pct",0))/100)
        total=production+self.packaging
        markup=float(s.get("markup_pct",0))/100;fee=float(s.get("shopee_fee_pct",0))/100
        before=total*(1+markup);price=before/(1-fee) if fee<1 else 0
        fee_value=price*fee;profit=price-fee_value-total
        return {"colors":colors,"weight":weight,"hours":hours,"cost":total,"price":price,"profit":profit}

    def update_summary(self,*_):
        qty=max(1,self.qty.value())
        for r,f in enumerate(self.display_filaments):
            it=self.table.item(r,4)
            if it:it.setText(f'{max(0.0,f.used_g)/qty:.2f} g')
        e=self.estimate()
        self.sum_weight.setText(f'{e["weight"]:.2f} g')
        self.sum_hours.setText(f'{e["hours"]:.2f} h')
        self.sum_cost.setText(brl(e["cost"]))
        self.sum_price.setText(brl(e["price"]))
        self.sum_profit.setText(brl(e["profit"]))

    def accept_validated(self):
        # Valida os dados antes de fechar. Ao aceitar, o chamador grava tudo no banco.
        if self.new_product and (self.product_name is None or not self.product_name.text().strip()):
            QMessageBox.warning(self,"Novo produto","Preencha o nome do produto antes de importar.")
            if self.product_name is not None:self.product_name.setFocus()
            return
        e=self.estimate()
        if not e["colors"]:
            QMessageBox.warning(self,"3MF","O arquivo não trouxe consumo de filamento em gramas.");return
        if len(e["colors"])>8:
            QMessageBox.warning(self,"3MF",f"Depois do agrupamento ainda existem {len(e['colors'])} cores. O cadastro aceita no máximo 8. Una cores equivalentes escolhendo o mesmo nome no campo 'Cor no ERP'.");return
        if e["hours"]<=0:
            ans=QMessageBox.question(self,"3MF","O 3MF trouxe as gramas, mas não trouxe tempo de impressão. Deseja importar mesmo assim?")
            if ans!=QMessageBox.Yes:return
        if hasattr(self,"import_button"):
            self.import_button.setEnabled(False)
            self.import_button.setText("IMPORTANDO...")
        self.accept()

    def values(self):
        e=self.estimate();plates=self.selected_plates()
        return {
            "colors":e["colors"],"weight_g":e["weight"],"print_hours":e["hours"],
            "plate_indexes":[p.index for p in plates],
            "plates_total_g":sum(p.total_filament_g for p in plates),
            "plates_seconds":sum(p.prediction_seconds for p in plates),
            "quantity":self.qty.value(),"auto_cost":self.auto_cost.isChecked(),
            "printer":", ".join(sorted({p.printer_model_id for p in plates if p.printer_model_id})),
            "nozzle":", ".join(sorted({str(p.nozzle_diameters) for p in plates if p.nozzle_diameters})),
            "scope":"all" if len(plates)==len(self.result.plates) else "plate",
            "product_name":self.product_name.text().strip() if self.product_name is not None else "",
            "sku":self.product_sku.text().strip() if self.product_sku is not None else "",
            "reserved_sku":self.product_sku is not None and self.reserved_sku==self.product_sku.text().strip(),
        }


class ImportWorker(QObject):
    finished=Signal(object)
    error=Signal(str)
    progress=Signal(str)

    def __init__(self,stats_file,order_file):
        super().__init__();self.stats_file=stats_file;self.order_file=order_file

    def run(self):
        try:
            msgs=[]
            if self.stats_file:
                self.progress.emit("Lendo estatísticas da Shopee...")
                p,_=import_stats(self.stats_file)
                msgs.append(f"Stats: {p.period_start}→{p.period_end} • {p.orders:.0f} pedidos • {brl(p.sales)}")
                msgs.extend(p.warnings)
            if self.order_file:
                self.progress.emit("Lendo pedidos, variações e taxas...")
                p,_=import_orders(self.order_file)
                msgs.append(f"Pedidos: {p.period_start}→{p.period_end} • {p.unique_orders} pedidos • {p.units:.0f} itens")
                msgs.extend(p.warnings)
            self.finished.emit(msgs)
        except Exception as e:
            logging.exception("import worker")
            self.error.emit(str(e))


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__();self.setWindowTitle(f"{APP_NAME} PRO • {APP_VERSION}");self.resize(1580,960)
        icon=ASSETS_DIR/"forgeon_icon.png"
        if icon.exists():self.setWindowIcon(QIcon(str(icon)))
        self.order_file="";self.stats_file="";self.order_preview=None;self.stats_preview=None
        self._debounce_timers={};self._month_cache={}
        self.import_thread=None;self.import_worker=None
        root=QWidget();self.setCentralWidget(root)
        outer=QVBoxLayout(root);outer.setContentsMargins(0,0,0,0);outer.setSpacing(0)
        # Compact top bar: branding, global page finder, backup/status.
        top=QFrame();top.setObjectName("TopBar");top.setFixedHeight(69)
        tl=QHBoxLayout(top);tl.setContentsMargins(14,6,16,6);tl.setSpacing(13)
        toggle=QPushButton("≡");toggle.setObjectName("SidebarToggle");toggle.setToolTip("Expandir / recolher menu")
        toggle.setFixedWidth(38);toggle.clicked.connect(self._toggle_sidebar);tl.addWidget(toggle)
        emblem_path=ASSETS_DIR/"forgeon_icon.png"
        if emblem_path.exists():
            emblem=QLabel();emblem.setFixedSize(49,49)
            emblem.setPixmap(QPixmap(str(emblem_path)).scaled(49,49,Qt.KeepAspectRatio,Qt.SmoothTransformation))
            emblem.setToolTip("Forgeon Studio - emblema original")
            tl.addWidget(emblem)
        brand=QVBoxLayout();brand.setSpacing(1)
        brand_name=QLabel("FORGEON STUDIO");brand_name.setObjectName("BrandText")
        brand_sub=QLabel("Gestão de impressão 3D");brand_sub.setObjectName("BrandSubtext")
        brand.addWidget(brand_name);brand.addWidget(brand_sub);tl.addLayout(brand)
        tl.addSpacing(20)
        self.global_search=QLineEdit();self.global_search.setObjectName("GlobalSearch")
        self.global_search.setPlaceholderText("Buscar página: produtos, pedidos, planilhas...  (Ctrl+K)")
        self.global_search.setMaximumWidth(470);self.global_search.returnPressed.connect(self._open_search_match)
        self.global_search.textChanged.connect(self._filter_navigation)
        tl.addWidget(self.global_search,2);tl.addStretch(1)
        backup=QPushButton("FAZER BACKUP");backup.setObjectName("Secondary");backup.clicked.connect(self.backup);tl.addWidget(backup)
        update_button=QPushButton("ATUALIZAR");update_button.setObjectName("Secondary");tl.addWidget(update_button)
        from ui.online_updates import OnlineUpdater
        self.online_updater=OnlineUpdater(self,update_button)
        badge=QLabel(f"v{APP_VERSION}");badge.setObjectName("TopBadge");tl.addWidget(badge)
        outer.addWidget(top)
        self.shortcut_search=QShortcut(QKeySequence("Ctrl+K"),self)
        self.shortcut_search.activated.connect(self._focus_search)
        # All pre-existing pages remain in their original indexes so that
        # goto(), dirty flags, buttons and report refreshers stay compatible.
        pages=[("Dashboard",self.make_dashboard),("Precificação",self.make_pricing),("Importação",self.make_import),("Pedidos",self.make_orders),
               ("Produtos",self.make_products),("Planilhas",self.make_spreadsheets),("Mapeamento",self.make_mapping),
               ("Financeiro",self.make_finance),("Relatórios",self.make_reports),("Configurações",self.make_settings)]
        pages.append(("Notas de atualização",self.make_release_notes))
        self.page_names=[name for name,_ in pages]
        self._page_dirty=set(range(len(pages)))
        self.stack=QStackedWidget();self.nav=[None]*len(pages)
        self._sidebar_groups=[];self._sidebar_compact=False
        area=QWidget();body=QHBoxLayout(area);body.setContentsMargins(0,0,0,0);body.setSpacing(0)
        self.sidebar=QFrame();self.sidebar.setObjectName("SideBar");self.sidebar.setFixedWidth(246)
        sbl=QVBoxLayout(self.sidebar);sbl.setContentsMargins(7,10,7,8);sbl.setSpacing(0)
        sidebar_scroll=QScrollArea();sidebar_scroll.setObjectName("SidebarScroll");sidebar_scroll.setWidgetResizable(True)
        sidebar_scroll.setFrameShape(QFrame.NoFrame);sidebar_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        content=QWidget();content.setObjectName("SidebarContent");nav_layout=QVBoxLayout(content)
        nav_layout.setContentsMargins(5,2,5,8);nav_layout.setSpacing(3)
        sections=[
            ("VISÃO GERAL",[(0,"Dashboard")]),
            ("VENDAS",[(3,"Pedidos"),(5,"Planilhas"),(2,"Importação")]),
            ("PRODUÇÃO",[(4,"Produtos"),(1,"Precificação"),(6,"Mapeamento")]),
            ("GESTÃO E FINANÇAS",[(7,"Financeiro"),(8,"Relatórios")]),
            ("SISTEMA",[(9,"Configurações")]),
        ]
        self._sidebar_full_names={}
        for section, entries in sections:
            heading=QLabel(section);heading.setObjectName("NavGroup");nav_layout.addWidget(heading)
            indexes=[]
            for index,name in entries:
                b=QPushButton("Visão geral" if index==0 else "Vínculos de SKU" if index==6 else name);b.setObjectName("SideNav");b.setCheckable(True)
                b.setToolTip(name);b.setMinimumHeight(41)
                b.clicked.connect(lambda _checked=False, i=index:self.goto(i))
                nav_layout.addWidget(b);self.nav[index]=b;indexes.append(index)
                self._sidebar_full_names[index]=name
            self._sidebar_groups.append((heading,indexes))
        nav_layout.addStretch(1)
        notes=QPushButton("Notas de atualização");notes.setObjectName("SideNav");notes.setCheckable(True)
        notes_index=self.page_names.index("Notas de atualização")
        notes.setToolTip("Histórico de mudanças por versão");notes.clicked.connect(lambda:self.goto(notes_index))
        self.nav[notes_index]=notes;self._sidebar_full_names[notes_index]="Notas de atualização"
        nav_layout.addWidget(notes)
        sidebar_scroll.setWidget(content);sbl.addWidget(sidebar_scroll,1)
        foot=QFrame();foot.setObjectName("SidebarFooter");fl=QVBoxLayout(foot)
        fl.setContentsMargins(11,7,8,4)
        self.sidebar_footer=QLabel("Seus dados ficam neste dispositivo")
        self.sidebar_footer.setObjectName("Hint");self.sidebar_footer.setWordWrap(True);fl.addWidget(self.sidebar_footer)
        sbl.addWidget(foot)
        body.addWidget(self.sidebar)
        for name,fn in pages:self.stack.addWidget(fn())
        body.addWidget(self.stack,1)
        outer.addWidget(area,1)
        for field in self.findChildren(QAbstractSpinBox):
            field.setLocale(QLocale(QLocale.Portuguese,QLocale.Brazil))
            field.setAlignment(Qt.AlignRight)
        self.statusBar().showMessage("Pronto")
        self.goto(0)

    def closeEvent(self,event):
        if self.online_updater.task is not None and self.online_updater.task.isRunning():
            event.ignore()
            QMessageBox.information(self,"Atualizações","Aguarde a consulta ou o download terminar antes de fechar o ERP.")
            return
        for name in ('import_thread',):
            thread=getattr(self,name,None)
            if thread is not None and thread.isRunning():
                event.ignore()
                QMessageBox.information(self,"Operacao em andamento","Aguarde a operacao em segundo plano terminar antes de fechar o ERP.")
                return
        super().closeEvent(event)

    def _focus_search(self):
        self.global_search.setFocus()
        self.global_search.selectAll()

    def _filter_navigation(self,query):
        import unicodedata
        def normalize(value):
            return ''.join(c for c in unicodedata.normalize('NFKD',str(value or '').lower()) if not unicodedata.combining(c))
        q=normalize(query).strip()
        if q and self._sidebar_compact:
            self._toggle_sidebar()
        for i,b in enumerate(self.nav):
            if b is not None:b.setVisible(not q or q in normalize(self.page_names[i]))
        for heading,indexes in self._sidebar_groups:
            heading.setVisible(not self._sidebar_compact and (not q or any(self.nav[i].isVisible() for i in indexes)))

    def _open_search_match(self):
        for i,b in enumerate(self.nav):
            if b is not None and b.isVisible():
                self.goto(i)
                self.global_search.clear()
                self.stack.setFocus()
                return
        self.statusBar().showMessage("Nenhuma página encontrada. Tente: Produtos, Pedidos ou Planilhas.",5000)

    def _toggle_sidebar(self):
        self._sidebar_compact=not self._sidebar_compact
        self.sidebar.setFixedWidth(76 if self._sidebar_compact else 246)
        for i,b in enumerate(self.nav):
            if b is not None:
                label="Visão geral" if i==0 else "Vínculos de SKU" if i==6 else self.page_names[i]
                b.setText(label[:2].upper() if self._sidebar_compact else label)
                b.setToolTip(self.page_names[i])
        for heading,indexes in self._sidebar_groups:
            heading.setVisible(not self._sidebar_compact)
        self.sidebar_footer.setVisible(not self._sidebar_compact)
        if self.global_search.text().strip():
            self._filter_navigation(self.global_search.text())

    def disclosure(self,title,content):
        frame=QFrame();frame.setObjectName("Disclosure")
        layout=QVBoxLayout(frame);layout.setContentsMargins(0,0,0,0)
        button=QToolButton();button.setText(title);button.setCheckable(True)
        button.setToolButtonStyle(Qt.ToolButtonTextBesideIcon);button.setArrowType(Qt.RightArrow)
        button.setSizePolicy(QSizePolicy.Expanding,QSizePolicy.Fixed)
        content.setVisible(False)
        def toggle(checked):
            content.setVisible(checked)
            button.setArrowType(Qt.DownArrow if checked else Qt.RightArrow)
        button.toggled.connect(toggle);layout.addWidget(button);layout.addWidget(content)
        return frame

    def shell(self,title,hint=""):
        w=QWidget();l=QVBoxLayout(w);l.setContentsMargins(24,18,24,20);l.setSpacing(12)
        row=QHBoxLayout();t=QLabel(title);t.setObjectName("PageTitle");row.addWidget(t);row.addStretch();l.addLayout(row)
        if hint:
            h=QLabel(hint);h.setObjectName("Hint");h.setWordWrap(True);l.addWidget(h)
        return w,l

    def make_dashboard(self):
        # The same live metrics/queries as the previous dashboard, reorganized
        # into a scrollable ERP-PRO layout. No invented sales numbers.
        w=QWidget();host=QVBoxLayout(w);host.setContentsMargins(0,0,0,0)
        scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setFrameShape(QFrame.NoFrame)
        body=QWidget();l=QVBoxLayout(body);l.setContentsMargins(20,18,20,22);l.setSpacing(15)
        header=QHBoxLayout();heading=QVBoxLayout()
        title=QLabel("Visão geral");title.setObjectName("PageTitle")
        hint=QLabel("Acompanhe o resultado do mês selecionado.")
        hint.setObjectName("Hint");hint.setWordWrap(True)
        heading.addWidget(title);heading.addWidget(hint);header.addLayout(heading,1)
        jump=QPushButton("Importar vendas");jump.setObjectName("GoldAction")
        jump.clicked.connect(lambda:self.goto(2));header.addWidget(jump)
        l.addLayout(header)
        filters=QHBoxLayout()
        self.dashboard_month=QComboBox();self.dashboard_month.setMinimumWidth(155)
        self.dashboard_month.currentIndexChanged.connect(self.refresh_dashboard)
        self.dashboard_range=QComboBox();self.dashboard_range.addItem("Últimos 3 meses",3)
        self.dashboard_range.addItem("Últimos 6 meses",6)
        self.dashboard_range.addItem("Últimos 12 meses",12)
        self.dashboard_range.addItem("Todo histórico",0)
        self.dashboard_range.setCurrentIndex(1)
        self.dashboard_range.currentIndexChanged.connect(self.refresh_dashboard)
        clear=QPushButton("LIMPAR FILTROS");clear.setObjectName("Secondary")
        clear.clicked.connect(self.clear_dashboard_filters)
        filters.addWidget(QLabel("Mês:"));filters.addWidget(self.dashboard_month)
        filters.addSpacing(10);filters.addWidget(QLabel("Histórico:"));filters.addWidget(self.dashboard_range)
        filters.addStretch(1);filters.addWidget(clear);l.addLayout(filters)
        # All six existing real-data cards, with legible spacing at laptop sizes.
        cards=QGridLayout();cards.setSpacing(12)
        self.c_sales=MetricCard("FATURAMENTO PAGO")
        self.c_orders=MetricCard("PEDIDOS PAGOS")
        self.c_units=MetricCard("PEÇAS VENDIDAS")
        self.c_fees=MetricCard("TAXAS DO MARKETPLACE")
        self.c_result=MetricCard("RESULTADO")
        self.c_cash=MetricCard("SALDO DE CAIXA")
        metrics=[self.c_sales,self.c_orders,self.c_units,self.c_fees,self.c_result,self.c_cash]
        for i,c in enumerate(metrics):
            c.setMinimumHeight(101);c.setProperty("accent","gold" if i in (1,4) else "red" if i in (0,3) else "neutral")
            cards.addWidget(c,i//3,i%3)
        for col in range(3):cards.setColumnStretch(col,1)
        l.addLayout(cards)
        charts=QGridLayout();charts.setSpacing(13)
        self.chart=MultiLineChart("Faturamento, resultado e caixa")
        self.origins=BarsChart("Canais de vendas (dados Shopee)")
        self.chart.setMinimumHeight(290);self.origins.setMinimumHeight(290)
        chart_frame=QFrame();chart_frame.setObjectName("DashboardPanel")
        ch=QVBoxLayout(chart_frame);ch.setContentsMargins(9,9,9,9);ch.addWidget(self.chart)
        origins_frame=QFrame();origins_frame.setObjectName("DashboardPanel")
        ol=QVBoxLayout(origins_frame);ol.setContentsMargins(9,9,9,9);ol.addWidget(self.origins)
        charts.addWidget(chart_frame,0,0);charts.addWidget(origins_frame,0,1)
        charts.setColumnStretch(0,3);charts.setColumnStretch(1,2);l.addLayout(charts)
        detail=QGridLayout();detail.setSpacing(13)
        self.recent_orders=self.panel_table("Pedidos recentes",["Pedido","Boneco","Variação","Qtd","Valor"],rows=6)
        self.top_variations=self.panel_table("Produtos mais vendidos",["Boneco","Unid.","Fonte / SKUs"],rows=6)
        self.color_usage=self.panel_table("Consumo de filamento por cor",["Cor","Quinzena kg","Mês kg"],rows=8)
        self.import_status=self.panel_label("Cobertura dos dados importados")
        detail.addWidget(self.recent_orders,0,0,1,2)
        detail.addWidget(self.top_variations,0,2)
        detail.addWidget(self.color_usage,1,0,1,3)
        detail.addWidget(self.import_status,2,0,1,3)
        for col in range(3):detail.setColumnStretch(col,1)
        l.addLayout(detail)
        l.addStretch(1)
        scroll.setWidget(body);host.addWidget(scroll)
        return w

    def make_pricing(self):
        w,l=self.shell(
            "Precificação",
            "Selecione um produto ou importe um 3MF para calcular custos e preço de venda."
        )

        saved_bar=QHBoxLayout()
        self.pr_saved_product=QComboBox();self.pr_saved_product.setEditable(True);self.pr_saved_product.setMinimumWidth(460);self.pr_saved_product.setInsertPolicy(QComboBox.NoInsert);self.pr_saved_product.setPlaceholderText("Buscar produto salvo por boneco, variação ou SKU...")
        load_saved=QPushButton("CARREGAR PRODUTO");load_saved.setObjectName("Secondary");load_saved.clicked.connect(self.load_saved_pricing_product)
        import_3mf=QPushButton("LER 3MF / AUTO PRECIFICAR");import_3mf.clicked.connect(self.import_3mf_from_pricing)
        saved_bar.addWidget(QLabel("Produto salvo:"));saved_bar.addWidget(self.pr_saved_product,1);saved_bar.addWidget(load_saved);saved_bar.addWidget(import_3mf)
        l.addLayout(saved_bar)

        globals_box=QFrame();globals_box.setObjectName("Panel")
        gv=QVBoxLayout(globals_box);gv.setContentsMargins(16,12,16,12)
        gt=QLabel("Padrões usados automaticamente");gt.setStyleSheet("font-weight:800;color:#ff7a00");gv.addWidget(gt)
        self.pr_global_labels={}
        gg=QGridLayout()
        defs=[("filament_price_kg","Filamento/kg"),("energy_price_kwh","Energia/kWh"),("printer_power_w","Potência"),
              ("machine_hour_cost","Hora máquina"),("labor_cost","Mão de obra"),("failure_rate_pct","Falha"),
              ("markup_pct","Markup"),("shopee_fee_pct","Taxa Shopee")]
        for i,(key,label) in enumerate(defs):
            a=QLabel(label);a.setObjectName("Hint");b=QLabel("—");b.setStyleSheet("font-weight:700")
            gg.addWidget(a,(i//4)*2,i%4);gg.addWidget(b,(i//4)*2+1,i%4);self.pr_global_labels[key]=b
        gv.addLayout(gg)
        edit_globals=QPushButton("EDITAR PADRÕES EM CONFIGURAÇÕES");edit_globals.setObjectName("Secondary");edit_globals.clicked.connect(lambda:self.goto(self.page_names.index("Configurações")))
        gv.addWidget(edit_globals,alignment=Qt.AlignRight)
        l.addWidget(self.disclosure("Parâmetros de custo usados no cálculo",globals_box))

        content=QHBoxLayout()
        left=QFrame();left.setObjectName("Panel")
        lf=QFormLayout(left);lf.setContentsMargins(18,16,18,16);lf.setSpacing(10)

        self.pr_boneco=QLineEdit();self.pr_variation=QLineEdit();self.pr_sku=QLineEdit()
        for imported in (self.pr_boneco,self.pr_variation,self.pr_sku):
            imported.setReadOnly(True);imported.setPlaceholderText("Selecione um produto salvo acima")
        self.pr_weight=QDoubleSpinBox();self.pr_weight.setRange(0,100000);self.pr_weight.setDecimals(2);self.pr_weight.setSuffix(" g")
        self.pr_hours=QDoubleSpinBox();self.pr_hours.setRange(0,10000);self.pr_hours.setDecimals(2);self.pr_hours.setSuffix(" h")
        self.pr_packaging=QDoubleSpinBox();self.pr_packaging.setRange(0,100000);self.pr_packaging.setDecimals(2);self.pr_packaging.setPrefix("R$ ")
        self.pr_other=QDoubleSpinBox();self.pr_other.setRange(0,100000);self.pr_other.setDecimals(2);self.pr_other.setPrefix("R$ ")
        self.pr_test_price=QDoubleSpinBox();self.pr_test_price.setRange(0,1000000);self.pr_test_price.setDecimals(2);self.pr_test_price.setPrefix("R$ ")

        for label,widget in [
            ("Boneco",self.pr_boneco),("Variação",self.pr_variation),("SKU",self.pr_sku),
            ("Peso total",self.pr_weight),("Tempo de impressão",self.pr_hours),
            ("Embalagem desta peça",self.pr_packaging),("Outros custos desta peça",self.pr_other),
            ("Preço para testar",self.pr_test_price),
        ]: lf.addRow(label,widget)

        buttons=QHBoxLayout();clear=QPushButton("LIMPAR");clear.setObjectName("Secondary");clear.clicked.connect(self.clear_pricing);buttons.addWidget(clear);buttons.addStretch();lf.addRow(buttons)

        right=QFrame();right.setObjectName("Panel")
        rv=QVBoxLayout(right);rv.setContentsMargins(18,16,18,16);rv.setSpacing(10)
        title=QLabel("Resumo da precificação");title.setStyleSheet("font-size:14pt;font-weight:700;color:#efbf62");rv.addWidget(title)
        self.pr_result_labels={};grid=QGridLayout();detail_widget=QWidget();detail_grid=QGridLayout(detail_widget);detail_grid.setContentsMargins(0,0,0,0);primary_row=0;detail_row=0
        result_defs=[
            ("filament","Custo filamento"),("energy","Energia"),("machine","Máquina"),("labor","Mão de obra"),
            ("other","Outros custos"),("failure_value","Perdas/falha"),("production","Custo de produção"),
            ("packaging","Embalagem"),("total_cost","Custo total"),("price_before_fee","Preço c/ markup"),
            ("suggested","Preço sugerido Shopee"),("fee_value","Taxa no preço sugerido"),("profit","Lucro"),("margin","Margem"),
        ]
        for i,(key,label) in enumerate(result_defs):
            a=QLabel(label);a.setObjectName("Hint");b=QLabel("—");b.setStyleSheet("font-size:14pt;font-weight:700");b.setTextInteractionFlags(Qt.TextSelectableByMouse)
            if key in {"total_cost","suggested","profit","margin"}:
                grid.addWidget(a,primary_row,0);grid.addWidget(b,primary_row,1,alignment=Qt.AlignRight);primary_row+=1
            else:
                detail_grid.addWidget(a,detail_row,0);detail_grid.addWidget(b,detail_row,1,alignment=Qt.AlignRight);detail_row+=1
            self.pr_result_labels[key]=b
        rv.addLayout(grid)
        rv.addWidget(self.disclosure("Detalhar composição do custo",detail_widget))
        sep=QFrame();sep.setFrameShape(QFrame.HLine);sep.setStyleSheet("color:#303744");rv.addWidget(sep)
        test_title=QLabel("Simulação pelo preço informado");test_title.setStyleSheet("font-weight:800");rv.addWidget(test_title)
        self.pr_test_result=QLabel("Informe um preço para comparar.");self.pr_test_result.setWordWrap(True);self.pr_test_result.setObjectName("Hint");rv.addWidget(self.pr_test_result)
        rv.addStretch()
        save=QPushButton("APLICAR CUSTOS AO PRODUTO SELECIONADO");save.clicked.connect(self.save_pricing_as_product);rv.addWidget(save)
        color_btn=QPushButton("APLICAR CUSTOS E CONFIGURAR CORES");color_btn.setObjectName("Secondary");color_btn.clicked.connect(lambda:self.save_pricing_as_product(open_colors=True));rv.addWidget(color_btn)
        content.addWidget(left,1);content.addWidget(right,1);l.addLayout(content)

        for spin in [self.pr_weight,self.pr_hours,self.pr_packaging,self.pr_other,self.pr_test_price]:
            spin.valueChanged.connect(self.recalculate_pricing)
        self.load_pricing_defaults()
        return w

    def make_import(self):
        w,l=self.shell("Importação Shopee","Selecione as estatísticas e Todos os pedidos (Order.all). Arquivos A Enviar são parciais e não contêm todas as variações vendidas.")
        auto=QPushButton("SELECIONAR ARQUIVO(S) SHOPEE AUTOMATICAMENTE");auto.clicked.connect(self.pick_auto_files);l.addWidget(auto,alignment=Qt.AlignLeft)
        grid=QGridLayout()
        self.order_box=self.file_panel("1 • PEDIDOS DETALHADOS","Order.all...xlsx",self.pick_orders)
        self.stats_box=self.file_panel("2 • ESTATÍSTICAS DA LOJA","shopee-shop-stats...xlsx",self.pick_stats)
        grid.addWidget(self.order_box,0,0);grid.addWidget(self.stats_box,0,1);l.addLayout(grid)
        bar=QHBoxLayout();self.preview_badge=QLabel("Selecione um ou os dois arquivos");self.preview_badge.setObjectName("Badge");bar.addWidget(self.preview_badge)
        self.import_state=QLabel("Pronto");self.import_state.setObjectName("Hint");bar.addWidget(self.import_state);bar.addStretch()
        self.import_button=QPushButton("IMPORTAR E CRUZAR DADOS");self.import_button.clicked.connect(self.do_import);bar.addWidget(self.import_button);l.addLayout(bar)
        self.preview_table=self.table(["Fonte","Período","Pedidos","Unidades","Vendas / Subtotal","Taxas","Observação"],5);l.addWidget(self.preview_table)
        fbar=QHBoxLayout();self.import_search=QLineEdit();self.import_search.setPlaceholderText("Filtrar histórico por arquivo...");self._connect_debounced(self.import_search,self.refresh_imports,"import_search")
        self.import_source_filter=QComboBox();self.import_source_filter.addItem("Todas as fontes");self.import_source_filter.currentIndexChanged.connect(self.refresh_imports)
        self.import_month_filter=QComboBox();self.import_month_filter.addItem("Todos os meses");self.import_month_filter.currentIndexChanged.connect(self.refresh_imports)
        clear=QPushButton("LIMPAR FILTROS");clear.setObjectName("Secondary");clear.clicked.connect(self.clear_import_filters)
        fbar.addWidget(self.import_search,2);fbar.addWidget(self.import_source_filter,1);fbar.addWidget(self.import_month_filter,1);fbar.addWidget(clear);l.addLayout(fbar)
        self.import_history=self.table(["Data","Fonte","Arquivo","Período","Arquivo preservado"],4);l.addWidget(self.import_history);return w

    def make_orders(self):
        w,l=self.shell("Pedidos","Mostra qual boneco e qual variação foram vendidos, além das taxas reais do Order.all.")
        bar=QHBoxLayout();self.order_search=QLineEdit();self.order_search.setPlaceholderText("Buscar pedido, boneco, SKU ou variação...")
        self.order_status=QComboBox();self.order_status.addItem("Todos os status");self.order_status.currentIndexChanged.connect(self.refresh_orders)
        self.order_month=QComboBox();self.order_month.addItem("Todos os meses");self.order_month.currentIndexChanged.connect(self.refresh_orders)
        self.order_boneco=QComboBox();self.order_boneco.addItem("Todos os bonecos");self.order_boneco.currentIndexChanged.connect(self.refresh_orders)
        clear=QPushButton("LIMPAR FILTROS");clear.setObjectName("Secondary");clear.clicked.connect(self.clear_order_filters)
        self._connect_debounced(self.order_search,self.refresh_orders,"order_search");bar.addWidget(self.order_search,3);bar.addWidget(self.order_month,1);bar.addWidget(self.order_status,1);bar.addWidget(self.order_boneco,1);bar.addWidget(clear);l.addLayout(bar)
        self.orders_table=self.table(["Pedido","Status","Pagamento","SKU","Boneco","Variação","Qtd","Subtotal","Comissão","Serviço","Taxas totais"],5);l.addWidget(self.orders_table);return w

    def make_products(self):
        w,l=self.shell(
            "Produtos, custos e cores",
            "Um boneco por linha. SKUs e anúncios ficam reunidos; os dados exibidos são do cadastro mais completo. Use VER ANÚNCIOS para consultar ou editar cada origem."
        )
        bar=QHBoxLayout()
        new=QPushButton("NOVO PRODUTO");new.clicked.connect(self.add_product)
        edit=QPushButton("EDITAR PRODUTO / CUSTO");edit.clicked.connect(self.edit_product)
        colors=QPushButton("CORES / GRAMAS");colors.setObjectName("Secondary");colors.clicked.connect(self.edit_selected_colors)
        copy_btn=QPushButton("COPIAR INFORMAÇÕES");copy_btn.setObjectName("Secondary");copy_btn.clicked.connect(self.copy_product_info)
        import_3mf=QPushButton("3MF NO PRODUTO SELECIONADO");import_3mf.clicked.connect(self.import_3mf_for_selected_product)
        new_3mf=QPushButton("NOVO PRODUTO VIA 3MF");new_3mf.clicked.connect(self.import_new_product_from_3mf)
        bar.addWidget(new);bar.addWidget(edit);bar.addWidget(colors);bar.addStretch();l.addLayout(bar)
        extra=QHBoxLayout();extra.addWidget(copy_btn);extra.addWidget(import_3mf);extra.addWidget(new_3mf);extra.addStretch();l.addLayout(extra)
        fbar=QHBoxLayout();self.product_search=QLineEdit();self.product_search.setPlaceholderText("Buscar boneco, variação, SKU ou anúncio...");self._connect_debounced(self.product_search,self.refresh_products,"product_search")
        self.product_boneco=QComboBox();self.product_boneco.addItem("Todos os bonecos");self.product_boneco.currentIndexChanged.connect(self.refresh_products)
        self.product_status=QComboBox();self.product_status.addItems(["Todos os status","Completo","Falta custo","Falta cores"]);self.product_status.currentIndexChanged.connect(self.refresh_products)
        self.product_color=QComboBox();self.product_color.addItem("Todas as cores");self.product_color.currentIndexChanged.connect(self.refresh_products)
        clearf=QPushButton("LIMPAR FILTROS");clearf.setObjectName("Secondary");clearf.clicked.connect(self.clear_product_filters)
        fbar.addWidget(self.product_search,3);fbar.addWidget(self.product_boneco,1);fbar.addWidget(self.product_status,1);fbar.addWidget(self.product_color,1);fbar.addWidget(clearf);l.addLayout(fbar)
        self.product_show_listings=QCheckBox("VER ANÚNCIOS / CADASTROS INDIVIDUAIS");self.product_show_listings.toggled.connect(self.refresh_products);l.addWidget(self.product_show_listings)
        self.products_table=self.table(
            ["Boneco","Variação / anúncio","SKU","Cores / g","Peso (auto)","Horas","Custo usado","Embalagem","Preço sugerido","Status"],3
        )
        l.addWidget(self.products_table)
        hint=QLabel(
            "A cópia mantém o SKU/anúncio do destino, copia custos e cores, e recalcula o peso automaticamente. "
            "Para um produto que ainda não existe no ERP/Shopee, use NOVO PRODUTO para cadastro manual ou NOVO PRODUTO VIA 3MF: basta informar o nome e o 3MF já preenche cores, gramas, peso, horas e preço."
        )
        hint.setObjectName("Hint");hint.setWordWrap(True);l.addWidget(hint)
        return w

    def make_mapping(self):
        w,l=self.shell("Mapeamento de SKUs","Use esta aba quando anúncios diferentes usam SKUs diferentes para o mesmo personagem. O SKU de origem continua rastreável, mas custos, cores e agrupamento dos relatórios passam a usar o produto de destino.")
        tabs=QTabWidget();l.addWidget(tabs)
        registry=QWidget();rl=QVBoxLayout(registry)
        self.sku_search=QLineEdit();self.sku_search.setPlaceholderText("Buscar SKU ou personagem...");self.sku_search.textChanged.connect(self.refresh_sku_catalog);rl.addWidget(self.sku_search)
        actions=QHBoxLayout()
        for label,callback in [("RESERVAR PRÓXIMO SKU",self.reserve_next_sku),("RESERVAR SKU MANUAL",self.reserve_manual_sku),("CORRIGIR SKU SELECIONADO",self.correct_selected_sku)]:
            button=QPushButton(label);button.clicked.connect(callback);actions.addWidget(button)
        rl.addLayout(actions)
        self.sku_table=self.table(["SKU","Personagem / produto","Variação","Situação"],1);rl.addWidget(self.sku_table)
        hint=QLabel("Códigos repetidos ficam em vermelho. Reservas mantêm uma lista crescente e impedem reutilização. Corrigir altera o cadastro do ERP; pedidos preservam o SKU original para auditoria. Atualize também o SKU na Shopee para evitar reimportar o código errado.");hint.setWordWrap(True);rl.addWidget(hint)
        tabs.addTab(registry,"SKUs e personagens")
        mappings=QWidget();l=QVBoxLayout(mappings);tabs.addTab(mappings,"Vínculos de custos e cores")
        filters=QHBoxLayout();self.map_search=QLineEdit();self.map_search.setPlaceholderText("Buscar SKU, boneco, anúncio ou destino...");self._connect_debounced(self.map_search,self.refresh_mapping,"map_search")
        self.map_status=QComboBox();self.map_status.addItems(["Todos","Somente mapeados","Somente não mapeados"]);self.map_status.currentIndexChanged.connect(self.refresh_mapping)
        filters.addWidget(self.map_search,3);filters.addWidget(self.map_status,1);l.addLayout(filters)
        self.map_table=self.table(["Boneco atual","SKU origem","Anúncio / variação","Mapeado para","SKU destino","Status"],2);self.map_table.itemSelectionChanged.connect(self._mapping_selection_changed);l.addWidget(self.map_table,1)
        box=QFrame();box.setObjectName("Panel");bh=QHBoxLayout(box);bh.setContentsMargins(12,10,12,10)
        self.map_target=QComboBox();self.map_target.setMinimumWidth(200);self.map_note=QLineEdit();self.map_note.setPlaceholderText("Observação opcional")
        save=QPushButton("MAPEAR SKU SELECIONADO");save.clicked.connect(self._mapping_save);remove=QPushButton("REMOVER MAPEAMENTO");remove.setObjectName("Secondary");remove.clicked.connect(self._mapping_remove)
        bh.addWidget(QLabel("Produto correto:"));bh.addWidget(self.map_target,2);l.addWidget(box)
        actions=QHBoxLayout();actions.addWidget(self.map_note,1);actions.addWidget(save);actions.addWidget(remove);l.addLayout(actions)
        hint=QLabel("Exemplo: se SKU 000041 e SKU SONIC-A representam o mesmo Sonic, selecione o SKU errado/alternativo na tabela e mapeie para o cadastro principal do Sonic. Pedidos antigos e futuros continuam mantendo o SKU original para auditoria.");hint.setObjectName("Hint");hint.setWordWrap(True);l.addWidget(hint)
        return w

    def refresh_mapping(self):
        if not hasattr(self,"map_table"):return
        search=_mapping_norm(self.map_search.text()) if hasattr(self,"map_search") else "";status=self.map_status.currentText() if hasattr(self,"map_status") else "Todos";current_target=self.map_target.currentData() if hasattr(self,"map_target") else None
        with db() as con:
            rows=con.execute("""SELECT v.id,v.boneco_name,v.sku,v.listing_name,v.variation_name,vm.target_variant_id,vm.notes,
                                       tv.boneco_name target_boneco,tv.sku target_sku,tv.variation_name target_var,tv.listing_name target_listing
                                FROM variants v LEFT JOIN variant_mappings vm ON vm.source_variant_id=v.id LEFT JOIN variants tv ON tv.id=vm.target_variant_id
                                WHERE v.active=1 ORDER BY v.boneco_name,v.sku,v.id""").fetchall()
            targets=con.execute("SELECT id,boneco_name,sku,variation_name,listing_name FROM variants WHERE active=1 ORDER BY boneco_name,sku,id").fetchall()
        self.map_target.blockSignals(True);self.map_target.clear();self.map_target.addItem("Selecione o produto correto...",None)
        for r in targets:
            name=r["boneco_name"] or r["variation_name"] or r["listing_name"] or "Produto";self.map_target.addItem(f'{name} • SKU {r["sku"] or "—"} • {r["variation_name"] or "sem variação"}',r["id"])
        ix=self.map_target.findData(current_target)
        if ix>=0:self.map_target.setCurrentIndex(ix)
        self.map_target.blockSignals(False)
        out=[];ids=[]
        for r in rows:
            mapped=bool(r["target_variant_id"])
            if status=="Somente mapeados" and not mapped:continue
            if status=="Somente não mapeados" and mapped:continue
            source_name=r["boneco_name"] or r["variation_name"] or r["listing_name"] or "—";target_name=r["target_boneco"] or r["target_var"] or r["target_listing"] or "—"
            blob=_mapping_norm(" ".join([source_name,r["sku"] or "",r["listing_name"] or "",r["variation_name"] or "",target_name,r["target_sku"] or ""]))
            if search and search not in blob:continue
            out.append([source_name,r["sku"] or "—",f'{r["listing_name"] or "—"} • {r["variation_name"] or "sem variação"}',target_name if mapped else "—",r["target_sku"] or "—","MAPEADO" if mapped else "PENDENTE"]);ids.append(r["id"])
        self.fill(self.map_table,out,ids)
        self.refresh_sku_catalog()

    def refresh_sku_catalog(self):
        if not hasattr(self,"sku_table"):return
        from services.sku_catalog import sync_existing
        with db() as con:
            sync_existing(con)
            products=con.execute("SELECT id,sku,boneco_name,listing_name,variation_name FROM variants WHERE active=1 OR (sku IS NOT NULL AND TRIM(sku)<>'') ORDER BY sku,id").fetchall()
            reserved=con.execute("SELECT sku,product_name,retired FROM sku_registry WHERE variant_id IS NULL ORDER BY sku").fetchall()
        counts={}
        for row in products:
            key=str(row['sku'] or '').strip().casefold()
            if key:counts[key]=counts.get(key,0)+1
        query=self.sku_search.text().strip().casefold();rows=[];ids=[];duplicates=[]
        for row in products:
            code=str(row['sku'] or '').strip();name=row['boneco_name'] or row['listing_name'];duplicate=counts.get(code.casefold(),0)>1
            if query and query not in f"{code} {name} {row['variation_name']}".casefold():continue
            rows.append([code or '—',name,row['variation_name'] or '',"REPETIDO — corrigir" if duplicate else 'Em uso' if code else 'Sem SKU']);ids.append(row['id']);duplicates.append(duplicate)
        for row in reserved:
            if query and query not in f"{row['sku']} {row['product_name']}".casefold():continue
            rows.append([row['sku'],row['product_name'],'','Anterior — não reutilizar' if row['retired'] else 'Reservado']);ids.append(None);duplicates.append(False)
        self.fill(self.sku_table,rows,ids)
        for index,duplicate in enumerate(duplicates):
            if duplicate:
                for column in range(self.sku_table.columnCount()):
                    item=self.sku_table.item(index,column);item.setBackground(QColor('#641e27'));item.setForeground(QColor('#ffffff'));item.setToolTip('Este SKU aparece em mais de um cadastro. Corrija o código ou confira os produtos antes de vincular custos.')

    def reserve_next_sku(self):
        from services.sku_catalog import reserve_next
        name,ok=QInputDialog.getText(self,"Reservar SKU","Personagem / produto para esta reserva (opcional):")
        if not ok:return
        code=reserve_next(name);self.refresh_sku_catalog();QMessageBox.information(self,"SKU reservado",f"Código reservado: {code}. Use Escolher SKU reservado ao cadastrar o produto.")

    def reserve_manual_sku(self):
        from services.sku_catalog import reserve
        code,ok=QInputDialog.getText(self,"Reservar SKU","Código (zeros à esquerda serão mantidos):")
        if not ok:return
        name,ok=QInputDialog.getText(self,"Reservar SKU","Personagem / produto (opcional):")
        if not ok:return
        try:reserve(code,name);self.refresh_sku_catalog()
        except ValueError as exc:QMessageBox.warning(self,"SKU",str(exc))

    def correct_selected_sku(self):
        from services.sku_catalog import correct
        row=self.sku_table.currentRow();item=self.sku_table.item(row,0) if row>=0 else None
        vid=item.data(Qt.UserRole) if item else None
        if not vid:QMessageBox.information(self,"SKU","Selecione a linha de um produto; reservas ainda não estão vinculadas a um cadastro.");return
        code,ok=QInputDialog.getText(self,"Corrigir SKU","Novo código para este produto:",text=item.text() if item.text()!='—' else '')
        if not ok:return
        try:correct(vid,code);self.invalidate_data_pages();self.refresh_mapping();self.refresh_products();self.refresh_pricing_page()
        except ValueError as exc:QMessageBox.warning(self,"SKU",str(exc))

    def _mapping_source_id(self):
        r=self.map_table.currentRow() if hasattr(self,"map_table") else -1
        if r<0 or not self.map_table.item(r,0):return None
        return self.map_table.item(r,0).data(Qt.UserRole)

    def _mapping_selection_changed(self):
        sid=self._mapping_source_id()
        if not sid:return
        with db() as con:r=con.execute("SELECT target_variant_id,notes FROM variant_mappings WHERE source_variant_id=?",(sid,)).fetchone()
        if r:
            ix=self.map_target.findData(r["target_variant_id"])
            if ix>=0:self.map_target.setCurrentIndex(ix)
            self.map_note.setText(r["notes"] or "")
        else:
            self.map_target.setCurrentIndex(0);self.map_note.clear()

    def _mapping_save(self):
        source=self._mapping_source_id();target=self.map_target.currentData()
        if not source:
            QMessageBox.information(self,"Mapeamento","Selecione um SKU na tabela.");return
        if not target:
            QMessageBox.information(self,"Mapeamento","Escolha o produto correto no campo Produto correto.");return
        if source==target:
            QMessageBox.warning(self,"Mapeamento","Origem e destino são o mesmo cadastro. Não é necessário mapear.");return
        with db() as con:
            seen={source};root=int(target)
            for _ in range(20):
                if root in seen:
                    QMessageBox.critical(self,"Mapeamento","Esse mapeamento criaria um ciclo. Escolha o produto principal/canônico como destino.");return
                seen.add(root);r=con.execute("SELECT target_variant_id FROM variant_mappings WHERE source_variant_id=?",(root,)).fetchone()
                if not r:break
                root=int(r["target_variant_id"])
            con.execute("INSERT INTO variant_mappings(source_variant_id,target_variant_id,notes,updated_at) VALUES (?,?,?,?) ON CONFLICT(source_variant_id) DO UPDATE SET target_variant_id=excluded.target_variant_id,notes=excluded.notes,updated_at=excluded.updated_at",(source,root,self.map_note.text().strip(),datetime.now().isoformat(timespec="seconds")))
        self.invalidate_data_pages();self.mark_dirty("Mapeamento");self.refresh_mapping();QMessageBox.information(self,"Mapeamento","SKU mapeado. Os relatórios e o consumo de filamento passarão a usar os dados do produto de destino.")

    def _mapping_remove(self):
        source=self._mapping_source_id()
        if not source:
            QMessageBox.information(self,"Mapeamento","Selecione um SKU na tabela.");return
        with db() as con:con.execute("DELETE FROM variant_mappings WHERE source_variant_id=?",(source,))
        self.invalidate_data_pages();self.mark_dirty("Mapeamento");self.refresh_mapping()


    def add_product(self):
        from services.erp_catalog import create_product
        dialog=ProductDialog(self)
        dialog.pack.setValue(float(get_setting("default_packaging_cost","0.30") or 0))
        if dialog.exec()!=QDialog.Accepted:return
        try:vid=create_product(dialog.values())
        except ValueError as exc:QMessageBox.warning(self,"Novo produto",str(exc));return
        self.invalidate_data_pages();self.refresh_products();self.refresh_pricing_page()
        for row in range(self.products_table.rowCount()):
            if self.products_table.item(row,0).data(Qt.UserRole)==vid:self.products_table.selectRow(row);break
        self.statusBar().showMessage("Produto cadastrado. Configure as cores e gramas ou importe um 3MF.",6000)

    def make_spreadsheets(self):
        from services.erp_spreadsheets import KINDS
        page,layout=self.shell("Planilhas","Exporte os dados do ERP em Excel, com valores numéricos prontos para análise.")
        form=QFormLayout();self.sheet_kind=QComboBox()
        for key,label in KINDS.items():self.sheet_kind.addItem(label,key)
        self.sheet_month=QComboBox();self.sheet_month.addItem("Todo o histórico",None)
        self.sheet_kind.currentIndexChanged.connect(self._sheet_kind_changed)
        form.addRow("Conteúdo:",self.sheet_kind);form.addRow("Mês:",self.sheet_month);layout.addLayout(form)
        hint=QLabel("Produtos e custos exporta todo o catálogo ativo e as cores/gramas. Pedidos, financeiro e relatórios podem ser filtrados por mês. Os relatórios mensais seguem os mesmos cálculos da tela Relatórios e dependem das estatísticas importadas. Estas planilhas são de gestão do ERP.")
        hint.setWordWrap(True);hint.setObjectName("Hint");layout.addWidget(hint)
        button=QPushButton("GERAR PLANILHA EXCEL");button.clicked.connect(self.export_spreadsheet);layout.addWidget(button,alignment=Qt.AlignLeft)
        folder=QPushButton("ABRIR PASTA DE EXPORTAÇÕES");folder.setObjectName("Secondary");folder.clicked.connect(self.open_exports_folder);layout.addWidget(folder,alignment=Qt.AlignLeft)
        self.sheet_status=QLabel("Escolha o conteúdo e gere o arquivo .xlsx.");self.sheet_status.setWordWrap(True);layout.addWidget(self.sheet_status);layout.addStretch()
        self._sheet_kind_changed();return page

    def open_exports_folder(self):
        from PySide6.QtGui import QDesktopServices
        from PySide6.QtCore import QUrl
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(EXPORT_DIR)))

    def _sheet_kind_changed(self):
        self.sheet_month.setEnabled(self.sheet_kind.currentData() not in ('products','skus'))

    def refresh_spreadsheets(self):
        with db() as con:
            months=[r[0] for r in con.execute("SELECT month_key FROM monthly_stats UNION SELECT month_key FROM orders UNION SELECT substr(purchase_date,1,7) FROM filament_purchases UNION SELECT substr(expense_date,1,7) FROM expenses ORDER BY 1") if r[0]]
        self._set_combo_items(self.sheet_month,[(key,key) for key in months],"Todo o histórico",None)

    def export_spreadsheet(self):
        from services.erp_spreadsheets import export_erp
        kind=self.sheet_kind.currentData();month=self.sheet_month.currentData() if kind not in ('products','skus') else None
        path,_=QFileDialog.getSaveFileName(self,"Gerar planilha do ERP",str(EXPORT_DIR/f"forgeon_{kind}_{month or 'completo'}.xlsx"),"Excel (*.xlsx)")
        if not path:return
        if not path.lower().endswith('.xlsx'):path+='.xlsx'
        try:
            result=export_erp(path,kind,month);self.sheet_status.setText(f"Planilha gerada: {result}")
        except Exception as exc:
            logging.exception("ERP spreadsheet export");QMessageBox.warning(self,"Planilhas",str(exc))

    def make_finance(self):
        w,l=self.shell("Financeiro","Compras e despesas entram automaticamente no mês da data cadastrada.")
        bar=QHBoxLayout();a=QPushButton("NOVA COMPRA DE FILAMENTO");a.clicked.connect(self.add_filament);b=QPushButton("NOVA DESPESA / MEI");b.clicked.connect(self.add_expense)
        bar.addWidget(a);bar.addWidget(b);bar.addStretch();l.addLayout(bar)
        fbar=QHBoxLayout();self.finance_search=QLineEdit();self.finance_search.setPlaceholderText("Buscar descrição/observação...");self._connect_debounced(self.finance_search,self.refresh_finance,"finance_search")
        self.finance_month=QComboBox();self.finance_month.addItem("Todos os meses");self.finance_month.currentIndexChanged.connect(self.refresh_finance)
        self.finance_category=QComboBox();self.finance_category.addItem("Todas as categorias");self.finance_category.currentIndexChanged.connect(self.refresh_finance)
        clear=QPushButton("LIMPAR FILTROS");clear.setObjectName("Secondary");clear.clicked.connect(self.clear_finance_filters)
        fbar.addWidget(self.finance_search,2);fbar.addWidget(self.finance_month,1);fbar.addWidget(self.finance_category,1);fbar.addWidget(clear);l.addLayout(fbar)
        self.finance_summary=self.table(["Mês","Vendas","Taxas","Produção","Embalagens","Filamento comprado","MEI","Outras despesas","Saldo caixa"],7);l.addWidget(self.finance_summary)
        tabs=QTabWidget();self.fil_table=self.table(["Data","Rolos","Valor/rolo","Frete/outros","Total","Observação"],5);self.exp_table=self.table(["Data","Categoria","Descrição","Valor"],3)
        tabs.addTab(self.fil_table,"Compras de filamento");tabs.addTab(self.exp_table,"Despesas / MEI");l.addWidget(tabs);return w

    def make_reports(self):
        w,l=self.shell("Relatórios","Histórico mensal para identificar picos, quedas e recuperação das vendas.")
        fbar=QHBoxLayout();self.report_year=QComboBox();self.report_year.addItem("Todos os anos");self.report_year.currentIndexChanged.connect(self.refresh_reports)
        self.report_range=QComboBox();self.report_range.addItem("Todo histórico",0);self.report_range.addItem("Últimos 3 meses",3);self.report_range.addItem("Últimos 6 meses",6);self.report_range.addItem("Últimos 12 meses",12);self.report_range.currentIndexChanged.connect(self.refresh_reports)
        self.report_coverage=QComboBox();self.report_coverage.addItems(["Todas as taxas","Somente taxas reais","Somente estimadas"]);self.report_coverage.currentIndexChanged.connect(self.refresh_reports)
        clear=QPushButton("LIMPAR FILTROS");clear.setObjectName("Secondary");clear.clicked.connect(self.clear_report_filters)
        fbar.addWidget(QLabel("Ano:"));fbar.addWidget(self.report_year);fbar.addWidget(QLabel("Período:"));fbar.addWidget(self.report_range);fbar.addWidget(QLabel("Cobertura:"));fbar.addWidget(self.report_coverage);fbar.addStretch();fbar.addWidget(clear);l.addLayout(fbar)
        g=QGridLayout();self.r_best=MetricCard("MELHOR MÊS");self.r_last=MetricCard("ÚLTIMO MÊS");self.r_var=MetricCard("VARIAÇÃO");self.r_margin=MetricCard("MARGEM")
        for i,c in enumerate([self.r_best,self.r_last,self.r_var,self.r_margin]):g.addWidget(c,0,i)
        l.addLayout(g);self.report_chart=MultiLineChart("Histórico mensal");l.addWidget(self.report_chart)
        self.report_table=self.table(["Mês","Período","Pedidos","Unidades","Vendas","Taxas","Resultado","Caixa","Cobertura"],8);l.addWidget(self.report_table);return w

    def make_release_notes(self):
        w,l=self.shell("Notas de atualização",f"Versão instalada: {APP_VERSION}")
        from ui.release_notes import RELEASE_NOTES
        view=QTextBrowser();view.setObjectName("ReleaseNotes");view.setOpenExternalLinks(False)
        view.setHtml(RELEASE_NOTES);l.addWidget(view,1)
        return w

    def make_settings(self):
        w,l=self.shell("Configurações","Parâmetros de custos, taxas da plataforma e dados fiscais.")
        self.settings_search=QLineEdit();self.settings_search.setPlaceholderText("Filtrar configurações...");self._connect_debounced(self.settings_search,self.filter_settings,"settings_search");l.addWidget(self.settings_search)
        scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setFrameShape(QFrame.NoFrame)
        content=QWidget();root=QVBoxLayout(content);root.setContentsMargins(0,0,8,0);root.setSpacing(14)

        cost=QFrame();cost.setObjectName("Panel");cv=QVBoxLayout(cost);ct=QLabel("CUSTOS E PRECIFICAÇÃO");ct.setStyleSheet("font-weight:800;color:#ff7a00");cv.addWidget(ct)
        form=QFormLayout();self.settings={};self.settings_rows=[]
        defs=[("filament_price_kg","Filamento / kg","R$ "),("energy_price_kwh","Energia / kWh","R$ "),("printer_power_w","Potência impressora (W)",""),
              ("machine_hour_cost","Hora máquina","R$ "),("labor_cost","Mão de obra por peça","R$ "),("failure_rate_pct","Falha (%)",""),
              ("default_packaging_cost","Embalagem padrão","R$ "),("markup_pct","Markup (%)",""),("shopee_fee_pct","Taxa Shopee estimada (%)","")]
        for k,label,prefix in defs:
            spin=QDoubleSpinBox();spin.setRange(0,1000000);spin.setDecimals(2)
            if prefix:spin.setPrefix(prefix)
            self.settings[k]=spin;form.addRow(label,spin);self.settings_rows.append((label,form.labelForField(spin),spin))
        cv.addLayout(form)

        market=QFrame();market.setObjectName("Panel");mv=QVBoxLayout(market);mt=QLabel("DADOS FISCAIS");mt.setStyleSheet("font-weight:800;color:#ff7a00");mv.addWidget(mt)
        mf=QFormLayout();self.settings_text={}
        text_defs=[
            ("shopee_ncm","NCM padrão"),
            ("shopee_cfop_same","CFOP mesmo estado"),("shopee_cfop_diff","CFOP outro estado"),("shopee_origin","Origem"),
            ("shopee_csosn","CSOSN"),("shopee_cest","CEST"),("shopee_measure_unit","Unidade de medida"),
            ("shopee_pis_cofins_cst","CST PIS/Cofins"),("shopee_tax_total_pct","% total de tributos"),
            ("shopee_operation_type","Tipo de operação"),("shopee_ex_tipi","EX TIPI"),("shopee_fci_num","Número FCI"),
            ("shopee_recopi_num","Número RECOPI"),("shopee_additional_info","Informações adicionais NF"),
        ]
        for k,label in text_defs:
            edit=QLineEdit();self.settings_text[k]=edit;mf.addRow(label,edit);self.settings_rows.append((label,mf.labelForField(edit),edit))
        mv.addLayout(mf)

        self.settings_tabs=QTabWidget();self.settings_tabs.setDocumentMode(True)
        for panel,title in [(cost,"Custos e taxas"),(market,"Fiscal")]:
            page=QWidget();layout=QVBoxLayout(page);layout.addWidget(panel);layout.addStretch()
            self.settings_tabs.addTab(page,title)
        root.addWidget(self.settings_tabs)
        root.addStretch();scroll.setWidget(content);l.addWidget(scroll,1)
        save=QPushButton("SALVAR CONFIGURAÇÕES");save.clicked.connect(self.save_settings);l.addWidget(save,alignment=Qt.AlignLeft)
        return w

    def table(self,headers,stretch_col):
        t=QTableWidget(0,len(headers));t.setHorizontalHeaderLabels(headers);t.setAlternatingRowColors(True);t.setEditTriggers(QAbstractItemView.NoEditTriggers)
        t.setSelectionBehavior(QAbstractItemView.SelectRows);t.verticalHeader().setVisible(False);t.horizontalHeader().setHighlightSections(False);t.verticalHeader().setDefaultSectionSize(42);t.setShowGrid(False)
        t.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        if stretch_col<len(headers):t.horizontalHeader().setSectionResizeMode(stretch_col,QHeaderView.Stretch)
        return t

    def panel_table(self,title,headers,rows=6):
        f=QFrame();f.setObjectName("Panel");lay=QVBoxLayout(f);lay.setContentsMargins(10,8,10,8)
        a=QLabel(title);a.setStyleSheet("font-weight:800;font-size:11pt");lay.addWidget(a)
        t=self.table(headers,0);t.setMinimumHeight(145);t.setMaximumHeight(190);lay.addWidget(t)
        f.table=t
        return f

    def panel_label(self,title):
        f=QFrame();f.setObjectName("Panel");l=QVBoxLayout(f);l.setContentsMargins(10,8,10,8)
        a=QLabel(title);a.setStyleSheet("font-weight:800;font-size:11pt")
        self.coverage_text=QLabel("Sem dados");self.coverage_text.setWordWrap(True);self.coverage_text.setObjectName("Hint")
        l.addWidget(a);l.addWidget(self.coverage_text);l.addStretch();f.setMinimumHeight(180);return f

    def file_panel(self,title,subtitle,fn):
        f=QFrame();f.setObjectName("Panel");l=QVBoxLayout(f);a=QLabel(title);a.setStyleSheet("font-size:12pt;font-weight:800;color:#ff7a00");b=QLabel(subtitle);b.setObjectName("Hint")
        status=QLabel("Nenhum arquivo selecionado");status.setWordWrap(True);status.setProperty("fileStatus",True);btn=QPushButton("SELECIONAR ARQUIVO");btn.clicked.connect(fn)
        l.addWidget(a);l.addWidget(b);l.addWidget(status);l.addWidget(btn,alignment=Qt.AlignLeft);return f

    def file_status_label(self,panel):
        labs=panel.findChildren(QLabel);return labs[-1]

    def assign_shopee_file(self,p,expected=None):
        kind=detect_shopee_file_type(p)
        if kind=="orders":
            pr,_,_=parse_orders(p);self.order_file=p;self.order_preview=pr
            self.file_status_label(self.order_box).setText(f"{Path(p).name}\n{pr.period_start} → {pr.period_end} • {pr.unique_orders} pedidos • {pr.units:.0f} un.")
            if expected=="stats":QMessageBox.information(self,"Arquivo identificado","Esse arquivo é PEDIDOS (Order.all). Coloquei automaticamente no campo correto.")
        elif kind=="stats":
            pr=parse_stats(p);self.stats_file=p;self.stats_preview=pr
            self.file_status_label(self.stats_box).setText(f"{Path(p).name}\n{pr.period_start} → {pr.period_end} • {pr.orders:.0f} pedidos • {brl(pr.sales)}")
            if expected=="orders":QMessageBox.information(self,"Arquivo identificado","Esse arquivo é ESTATÍSTICAS (shop-stats). Coloquei automaticamente no campo correto.")
        else:
            raise ValueError("Arquivo Shopee não reconhecido.\nAceitos: Order.all...xlsx e shopee-shop-stats...xlsx")
        self.refresh_preview()

    def pick_auto_files(self):
        paths,_=QFileDialog.getOpenFileNames(self,"Selecionar arquivo(s) Shopee",str(Path.home()),"Excel (*.xlsx *.xlsm)")
        if not paths:return
        erros=[]
        for p in paths:
            try:self.assign_shopee_file(p)
            except Exception as e:erros.append(f"{Path(p).name}: {e}")
        if erros:QMessageBox.warning(self,"Alguns arquivos não foram reconhecidos","\n\n".join(erros))

    def pick_orders(self):
        p,_=QFileDialog.getOpenFileName(self,"Selecionar relatório Shopee",str(Path.home()),"Excel (*.xlsx *.xlsm)")
        if p:
            try:self.assign_shopee_file(p,expected="orders")
            except Exception as e:QMessageBox.critical(self,"Shopee",str(e))

    def pick_stats(self):
        p,_=QFileDialog.getOpenFileName(self,"Selecionar relatório Shopee",str(Path.home()),"Excel (*.xlsx *.xlsm)")
        if p:
            try:self.assign_shopee_file(p,expected="stats")
            except Exception as e:QMessageBox.critical(self,"Shopee",str(e))

    def refresh_preview(self):
        rows=[]
        if self.order_preview:
            p=self.order_preview;rows.append(["Order.all",f"{p.period_start} → {p.period_end}",p.unique_orders,p.units,brl(p.gross_subtotal),brl(p.actual_fees)," | ".join(p.warnings) if p.warnings else "Pedidos importados; não apaga outros pedidos do mês"])
        if self.stats_preview:
            p=self.stats_preview;rows.append(["shop-stats",f"{p.period_start} → {p.period_end}",p.orders,p.units,brl(p.sales),"—"," | ".join(p.warnings) if p.warnings else "Totais oficiais e resumo por anúncio; não identifica todas as variações"])
        self.fill(self.preview_table,rows)
        if self.order_preview and self.stats_preview:
            if self.order_preview.period_end!=self.stats_preview.period_end:self.preview_badge.setText(f"PERÍODOS DIFERENTES • pedidos até {self.order_preview.period_end} • stats até {self.stats_preview.period_end}")
            else:self.preview_badge.setText("PEDIDOS PARCIAIS: exporte Todos os pedidos (Order.all)" if self.order_preview.scope=="toship" or self.order_preview.unique_orders<self.stats_preview.orders else "PERÍODOS ALINHADOS — confira a cobertura")
        else:self.preview_badge.setText("Importação parcial disponível")

    def do_import(self):
        if not self.order_file and not self.stats_file:
            QMessageBox.information(self,"Importação","Selecione pelo menos um arquivo.");return
        if self.import_thread and self.import_thread.isRunning():
            QMessageBox.information(self,"Importação","Já existe uma importação em andamento.");return

        self.import_button.setEnabled(False)
        self.import_state.setText("Importando em segundo plano...")
        self.statusBar().showMessage("Importação Shopee em andamento — você pode usar outras abas")

        self.import_thread=QThread(self)
        self.import_worker=ImportWorker(self.stats_file,self.order_file)
        self.import_worker.moveToThread(self.import_thread)
        self.import_thread.started.connect(self.import_worker.run)
        self.import_worker.progress.connect(self.on_import_progress)
        self.import_worker.finished.connect(self.on_import_finished)
        self.import_worker.error.connect(self.on_import_error)
        self.import_worker.finished.connect(self.import_thread.quit)
        self.import_worker.error.connect(self.import_thread.quit)
        self.import_thread.finished.connect(self._cleanup_import_thread)
        self.import_thread.start()

    def on_import_progress(self,text):
        if hasattr(self,"import_state"):self.import_state.setText(text)
        self.statusBar().showMessage(text)

    def on_import_finished(self,msgs):
        self.import_button.setEnabled(True);self.import_state.setText("Importação concluída")
        self.invalidate_data_pages()
        # Atualiza somente a aba de importação agora; as demais serão carregadas ao abrir.
        self.refresh_imports();self.refresh_preview()
        self.statusBar().showMessage("Importação concluída",5000)
        QMessageBox.information(self,"Forgeon Studio","Importação concluída.\n\n"+"\n".join(msgs)+"\n\nAs outras abas serão atualizadas quando você abri-las.")

    def on_import_error(self,text):
        self.import_button.setEnabled(True);self.import_state.setText("Falha na importação")
        self.statusBar().showMessage("Falha na importação",5000)
        QMessageBox.critical(self,"Falha na importação",text)

    def _cleanup_import_thread(self):
        if self.import_worker:self.import_worker.deleteLater()
        if self.import_thread:self.import_thread.deleteLater()
        self.import_worker=None;self.import_thread=None

    def _connect_debounced(self,widget,callback,key,delay=250):
        timer=QTimer(self);timer.setSingleShot(True);timer.setInterval(delay)
        timer.timeout.connect(callback);self._debounce_timers[key]=timer
        widget.textChanged.connect(lambda _text,t=timer:(t.stop(),t.start()))

    def goto(self,i):
        self.stack.setCurrentIndex(i)
        for x,b in enumerate(self.nav):b.setChecked(x==i)
        self.refresh_page(i)

    def refresh_page(self,i,force=False):
        if not force and i not in self._page_dirty:return
        refreshers={
            0:self.refresh_dashboard,
            1:self.refresh_pricing_page,
            2:self.refresh_imports,
            3:self.refresh_orders,
            4:self.refresh_products,
            5:self.refresh_spreadsheets,
            6:self.refresh_mapping,
            7:self.refresh_finance,
            8:self.refresh_reports,
            9:self.refresh_settings,
        }
        fn=refreshers.get(i)
        if fn:
            self.statusBar().showMessage(f"Atualizando {self.page_names[i]}...")
            QApplication.setOverrideCursor(Qt.WaitCursor)
            try:fn()
            finally:
                QApplication.restoreOverrideCursor();self.statusBar().showMessage("Pronto",1500)
        self._page_dirty.discard(i)

    def mark_dirty(self,*names):
        if not names:
            self._page_dirty.update(range(len(self.page_names)));return
        for name in names:
            if name in self.page_names:self._page_dirty.add(self.page_names.index(name))

    def invalidate_data_pages(self):
        self._month_cache.clear()
        self.mark_dirty("Dashboard","Precificação","Importação","Pedidos","Produtos","Planilhas","Mapeamento","Financeiro","Relatórios")

    def month_data(self,month_key):
        if month_key not in self._month_cache:self._month_cache[month_key]=month_report(month_key)
        return self._month_cache[month_key]

    def refresh_pricing_page(self):
        self.refresh_pricing_saved_products();self.load_pricing_defaults();self.recalculate_pricing()

    def _set_combo_items(self,combo,items,first_label=None,first_data=None,preferred=None):
        if combo is None:return
        current=preferred if preferred is not None else combo.currentData()
        current_text=combo.currentText()
        combo.blockSignals(True);combo.clear()
        if first_label is not None:combo.addItem(first_label,first_data)
        for label,data in items:combo.addItem(str(label),data)
        ix=combo.findData(current) if current is not None else -1
        if ix<0 and current_text:ix=combo.findText(current_text)
        if ix>=0:combo.setCurrentIndex(ix)
        combo.blockSignals(False)

    def clear_dashboard_filters(self):
        if self.dashboard_month.count():self.dashboard_month.setCurrentIndex(self.dashboard_month.count()-1)
        self.dashboard_range.setCurrentIndex(1)
        self.refresh_dashboard()

    def clear_import_filters(self):
        self.import_search.clear();self.import_source_filter.setCurrentIndex(0);self.import_month_filter.setCurrentIndex(0);self.refresh_imports()

    def clear_order_filters(self):
        self.order_search.clear();self.order_month.setCurrentIndex(0);self.order_status.setCurrentIndex(0);self.order_boneco.setCurrentIndex(0);self.refresh_orders()

    def clear_product_filters(self):
        self.product_search.clear();self.product_boneco.setCurrentIndex(0);self.product_status.setCurrentIndex(0);self.product_color.setCurrentIndex(0);self.refresh_products()

    def clear_finance_filters(self):
        self.finance_search.clear();self.finance_month.setCurrentIndex(0);self.finance_category.setCurrentIndex(0);self.refresh_finance()

    def clear_report_filters(self):
        self.report_year.setCurrentIndex(0);self.report_range.setCurrentIndex(0);self.report_coverage.setCurrentIndex(0);self.refresh_reports()

    def filter_settings(self):
        if not hasattr(self,"settings_rows"):return
        q=self.settings_search.text().strip().lower()
        for label,lab,w in self.settings_rows:
            visible=(not q or q in label.lower())
            if lab:lab.setVisible(visible)
            w.setVisible(visible)
        if hasattr(self,"settings_tabs"):
            matches=[]
            for i in range(self.settings_tabs.count()):
                page=self.settings_tabs.widget(i)
                match=not q or any(q in label.lower() and page.isAncestorOf(field) for label,_,field in self.settings_rows)
                self.settings_tabs.setTabVisible(i,match)
                if match:matches.append(i)
            if matches and self.settings_tabs.currentIndex() not in matches:self.settings_tabs.setCurrentIndex(matches[0])

    def refresh_pricing_saved_products(self):
        if not hasattr(self,"pr_saved_product"):return
        current=self.pr_saved_product.currentData()
        with db() as con:rows=con.execute("SELECT id,boneco_name,variation_name,sku FROM variants WHERE active=1 ORDER BY boneco_name,variation_name,sku").fetchall()
        self.pr_saved_product.blockSignals(True);self.pr_saved_product.clear();self.pr_saved_product.addItem("Selecione ou digite para buscar...",None)
        for r in rows:
            name=r["boneco_name"] or r["variation_name"] or "Produto"
            self.pr_saved_product.addItem(f'{name} • {r["variation_name"] or "sem variação"} • SKU {r["sku"] or "—"}',r["id"])
        ix=self.pr_saved_product.findData(current)
        if ix>=0:self.pr_saved_product.setCurrentIndex(ix)
        self.pr_saved_product.blockSignals(False)

    def load_saved_pricing_product(self):
        vid=self.pr_saved_product.currentData() if hasattr(self,"pr_saved_product") else None
        if not vid:
            QMessageBox.information(self,"Precificação","Selecione um produto salvo na lista.");return
        with db() as con:r=con.execute("SELECT * FROM variants WHERE id=?",(vid,)).fetchone()
        if not r:return
        self.pr_boneco.setText(r["boneco_name"] or r["variation_name"] or r["listing_name"] or "")
        self.pr_variation.setText(r["variation_name"] or "");self.pr_sku.setText(r["sku"] or "")
        self.pr_weight.setValue(float(r["weight_g"] or 0));self.pr_hours.setValue(float(r["print_hours"] or 0))
        self.pr_packaging.setValue(float(r["packaging_cost"] or 0));self.pr_other.setValue(float(r["other_cost"] or 0));self.recalculate_pricing()

    def save_settings(self):
        for k,w in self.settings.items():set_setting(k,w.value())
        for k,w in getattr(self,"settings_text",{}).items():set_setting(k,w.text().strip())
        self._month_cache.clear()
        self.mark_dirty("Dashboard","Precificação","Produtos","Planilhas","Mapeamento","Financeiro","Relatórios")
        self.load_pricing_defaults()
        QMessageBox.information(self,"Configurações","Configurações salvas. As outras abas serão recalculadas quando você abri-las.")

    def load_pricing_defaults(self):
        self.pr_defaults=all_settings()
        if hasattr(self,"pr_global_labels"):
            formats={
                "filament_price_kg":lambda v:brl(v),"energy_price_kwh":lambda v:brl(v),
                "printer_power_w":lambda v:f"{float(v):.0f} W","machine_hour_cost":lambda v:brl(v),
                "labor_cost":lambda v:brl(v),"failure_rate_pct":lambda v:f"{float(v):.2f}%",
                "markup_pct":lambda v:f"{float(v):.2f}%","shopee_fee_pct":lambda v:f"{float(v):.2f}%",
            }
            for k,label in self.pr_global_labels.items():label.setText(formats[k](self.pr_defaults.get(k,0)))
        if hasattr(self,"pr_packaging") and self.pr_packaging.value()==0:
            self.pr_packaging.setValue(float(self.pr_defaults.get("default_packaging_cost",0.30)))
        self.recalculate_pricing()

    def clear_pricing(self):
        self.pr_boneco.clear();self.pr_variation.clear();self.pr_sku.clear()
        if hasattr(self,"pr_saved_product"):self.pr_saved_product.setCurrentIndex(0)
        self.pr_weight.setValue(0);self.pr_hours.setValue(0);self.pr_other.setValue(0);self.pr_test_price.setValue(0)
        self.pr_packaging.setValue(float(getattr(self,"pr_defaults",{}).get("default_packaging_cost",0.30)))
        self.recalculate_pricing()

    def pricing_values(self):
        s=getattr(self,"pr_defaults",None) or all_settings()
        weight=self.pr_weight.value();hours=self.pr_hours.value()
        filament=weight*float(s.get("filament_price_kg",0))/1000
        energy=hours*(float(s.get("printer_power_w",0))/1000)*float(s.get("energy_price_kwh",0))
        machine=hours*float(s.get("machine_hour_cost",0))
        labor=float(s.get("labor_cost",0));other=self.pr_other.value()
        subtotal=filament+energy+machine+labor+other
        failure_value=subtotal*(float(s.get("failure_rate_pct",0))/100)
        production=subtotal+failure_value
        packaging=self.pr_packaging.value();total_cost=production+packaging
        price_before_fee=total_cost*(1+float(s.get("markup_pct",0))/100)
        fee_rate=float(s.get("shopee_fee_pct",0))/100
        suggested=price_before_fee/(1-fee_rate) if fee_rate<1 else 0
        fee_value=suggested*fee_rate;profit=suggested-fee_value-total_cost
        margin=(profit/suggested*100) if suggested>0 else 0
        test=self.pr_test_price.value();test_fee=test*fee_rate;test_profit=test-test_fee-total_cost;test_margin=(test_profit/test*100) if test>0 else 0
        return {"filament":filament,"energy":energy,"machine":machine,"labor":labor,"other":other,
                "failure_value":failure_value,"production":production,"packaging":packaging,"total_cost":total_cost,
                "price_before_fee":price_before_fee,"suggested":suggested,"fee_value":fee_value,"profit":profit,"margin":margin,
                "test_price":test,"test_fee":test_fee,"test_profit":test_profit,"test_margin":test_margin}

    def recalculate_pricing(self):
        if not hasattr(self,"pr_result_labels"):
            return
        v=self.pricing_values()
        money_keys=["filament","energy","machine","labor","other","failure_value","production","packaging",
                    "total_cost","price_before_fee","suggested","fee_value","profit"]
        for k in money_keys:
            self.pr_result_labels[k].setText(brl(v[k]))
        self.pr_result_labels["margin"].setText(f'{v["margin"]:.1f}%')

        if v["test_price"]>0:
            color="#49d17d" if v["test_profit"]>=0 else "#ff5a5f"
            self.pr_test_result.setText(
                f'Preço: {brl(v["test_price"])}  •  Taxa: {brl(v["test_fee"])}  •  '
                f'Lucro: {brl(v["test_profit"])}  •  Margem: {v["test_margin"]:.1f}%'
            )
            self.pr_test_result.setStyleSheet(f"color:{color};font-weight:700")
        else:
            self.pr_test_result.setText("Informe um preço para comparar.")
            self.pr_test_result.setStyleSheet("color:#7e8a99")

    def save_pricing_as_product(self,open_colors=False):
        vid=self.pr_saved_product.currentData() if hasattr(self,"pr_saved_product") else None
        if not vid:
            QMessageBox.information(self,"Precificação","Selecione um produto salvo. A aba Precificação não cria mais cadastros duplicados; o catálogo vem de Produtos/Importação.")
            return
        if self.pr_weight.value()<=0 or self.pr_hours.value()<=0:
            ans=QMessageBox.question(self,"Custo incompleto","Peso ou horas estão zerados. Deseja aplicar mesmo assim?")
            if ans!=QMessageBox.Yes:return
        now=datetime.now().isoformat(timespec="seconds")
        with db() as con:
            con.execute("""UPDATE variants SET weight_g=?,print_hours=?,packaging_cost=?,other_cost=?,updated_at=? WHERE id=?""",
                        (self.pr_weight.value(),self.pr_hours.value(),self.pr_packaging.value(),self.pr_other.value(),now,vid))
        self.invalidate_data_pages();self.refresh_pricing_page()
        QMessageBox.information(self,"Precificação",f"Custos aplicados ao produto selecionado.\n\nPreço sugerido: {brl(self.pricing_values()['suggested'])}")
        if open_colors:self.open_color_editor(vid)

    def _apply_3mf_to_variant(self,vid,path):
        with db() as con:
            row=con.execute("SELECT * FROM variants WHERE id=?",(vid,)).fetchone()
        if not row:
            QMessageBox.warning(self,"3MF","Produto não encontrado.");return False
        try:
            result=parse_3mf(path)
        except ThreeMFNotSlicedError as e:
            QMessageBox.warning(self,"3MF sem fatiamento",str(e));return False
        except ThreeMFError as e:
            QMessageBox.critical(self,"Erro ao ler 3MF",str(e));return False
        except Exception as e:
            logging.exception("3mf import");QMessageBox.critical(self,"Erro ao ler 3MF",str(e));return False

        title=f'{row["boneco_name"] or row["variation_name"] or row["listing_name"]} • SKU {row["sku"] or "—"}'
        dlg=ThreeMFImportDialog(self,result,title,row["packaging_cost"],row["other_cost"])
        if dlg.exec()!=QDialog.Accepted:return False
        vals=dlg.values();now=datetime.now().isoformat(timespec="seconds")
        plates_text=",".join(str(x) for x in vals["plate_indexes"])
        scope_text="projeto inteiro" if vals.get("scope")=="all" else f"placa {plates_text}"
        note=f'3MF: {Path(path).name} • {scope_text} • placas {plates_text} • qtd bonecos {vals["quantity"]}'
        try:
            with db() as con:
                con.execute("DELETE FROM variant_colors WHERE variant_id=?",(vid,))
                for slot,(color,g) in enumerate(vals["colors"],1):
                    con.execute("INSERT INTO variant_colors(variant_id,slot,color_name,grams_per_unit) VALUES (?,?,?,?)",(vid,slot,color,g))
                manual=0.0 if vals["auto_cost"] else float(row["manual_cost"] or 0)
                old_notes=(row["notes"] or "").strip()
                new_notes=(old_notes+"\n"+note).strip() if note not in old_notes else old_notes
                con.execute("""UPDATE variants SET weight_g=?,print_hours=?,manual_cost=?,notes=?,updated_at=? WHERE id=?""",
                            (vals["weight_g"],vals["print_hours"],manual,new_notes,now,vid))
                sync_variant_weight_from_colors(con,vid)
        except Exception as e:
            logging.exception("3mf apply")
            QMessageBox.critical(self,"Erro ao importar 3MF",f"O 3MF foi lido corretamente, mas ocorreu um erro ao salvar os dados:\n\n{e}")
            return False
        self._month_cache.clear();self.invalidate_data_pages()
        return True

    def _new_product_name_from_3mf(self,path):
        name=Path(path).name
        for suffix in (".gcode.3mf",".3mf"):
            if name.lower().endswith(suffix):
                name=name[:-len(suffix)]
                break
        name=re.sub(r"[_-]+"," ",name).strip()
        return name

    def _create_product_from_3mf(self,path):
        try:
            result=parse_3mf(path)
        except ThreeMFNotSlicedError as e:
            QMessageBox.warning(self,"3MF sem fatiamento",str(e));return None
        except ThreeMFError as e:
            QMessageBox.critical(self,"Erro ao ler 3MF",str(e));return None
        except Exception as e:
            logging.exception("3mf new product parse");QMessageBox.critical(self,"Erro ao ler 3MF",str(e));return None

        default_pack=float(get_setting("default_packaging_cost","0.30") or 0.30)
        default_name=self._new_product_name_from_3mf(path)
        dlg=ThreeMFImportDialog(
            self,result,"NOVO PRODUTO",default_pack,0.0,
            new_product=True,default_name=default_name,default_sku=""
        )
        if dlg.exec()!=QDialog.Accepted:return None
        vals=dlg.values();name=vals["product_name"].strip();sku=vals["sku"].strip()
        now=datetime.now().isoformat(timespec="seconds")
        variant_key=f"SKU:{sku}" if sku else f"MANUAL3MF:{datetime.now().strftime('%Y%m%d%H%M%S%f')}"

        with db() as con:
            from services.sku_catalog import check_available,attach
            con.execute('BEGIN IMMEDIATE')
            if sku:
                try:check_available(con,sku,bool(vals.get('reserved_sku')))
                except ValueError as exc:QMessageBox.warning(self,"SKU",str(exc));return None
                existing=con.execute("SELECT id,boneco_name,variation_name,listing_name FROM variants WHERE variant_key=? OR sku=? LIMIT 1",(variant_key,sku)).fetchone()
                if existing:
                    QMessageBox.warning(
                        self,"SKU já cadastrado",
                        f'O SKU {sku} já existe no ERP como "{existing["boneco_name"] or existing["variation_name"] or existing["listing_name"]}".\n\n'
                        'Use o botão 3MF NO PRODUTO SELECIONADO para atualizar esse cadastro.'
                    )
                    return None
            con.execute("""INSERT INTO variants(
                variant_key,sku,main_sku,listing_name,variation_name,boneco_name,
                weight_g,print_hours,manual_cost,packaging_cost,other_cost,notes,active,created_at,updated_at
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (variant_key,sku,"",name,name,name,vals["weight_g"],vals["print_hours"],0.0,default_pack,0.0,
             f'Cadastro criado automaticamente pelo 3MF: {Path(path).name}',1,now,now))
            vid=con.execute("SELECT last_insert_rowid() id").fetchone()["id"]
            for slot,(color,g) in enumerate(vals["colors"],1):
                con.execute("INSERT INTO variant_colors(variant_id,slot,color_name,grams_per_unit) VALUES (?,?,?,?)",(vid,slot,color,g))
            sync_variant_weight_from_colors(con,vid)
            attach(con,sku,vid,name)

        self._month_cache.clear();self.invalidate_data_pages();self.refresh_products();self.refresh_pricing_page()
        with db() as con:
            row=con.execute("SELECT * FROM variants WHERE id=?",(vid,)).fetchone()
        settings=all_settings();cost=variant_unit_cost(row,settings)
        fee=float(settings.get("shopee_fee_pct",0))/100;markup=float(settings.get("markup_pct",0))/100
        price=(cost+float(row["packaging_cost"] or 0))*(1+markup)/(1-fee) if fee<1 else 0
        QMessageBox.information(
            self,"Produto criado pelo 3MF",
            f'Cadastro concluído.\n\nProduto: {name}\nSKU: {sku or "não informado"}\n'
            f'Peso: {float(row["weight_g"] or 0):.2f} g\nTempo: {float(row["print_hours"] or 0):.2f} h\n'
            f'Custo usado: {brl(cost)}\nPreço sugerido: {brl(price)}\n\n'
            'O produto já está disponível em Produtos e Precificação.'
        )
        return vid

    def import_new_product_from_3mf(self):
        path,_=QFileDialog.getOpenFileName(self,"Selecionar 3MF do novo produto",str(Path.home()),"3MF (*.3mf);;Todos os arquivos (*)")
        if not path:return None
        return self._create_product_from_3mf(path)

    def import_3mf_for_selected_product(self):
        vid=self.selected_variant_id()
        if not vid:
            self.import_new_product_from_3mf();return
        path,_=QFileDialog.getOpenFileName(self,"Selecionar 3MF fatiado",str(Path.home()),"3MF (*.3mf);;Todos os arquivos (*)")
        if not path:return
        if self._apply_3mf_to_variant(vid,path):
            self.refresh_products()
            with db() as con:r=con.execute("SELECT * FROM variants WHERE id=?",(vid,)).fetchone()
            settings=all_settings();cost=variant_unit_cost(r,settings);fee=float(settings.get("shopee_fee_pct",0))/100;markup=float(settings.get("markup_pct",0))/100
            price=(cost+float(r["packaging_cost"] or 0))*(1+markup)/(1-fee) if fee<1 else 0
            QMessageBox.information(self,"3MF importado",f'Dados aplicados com sucesso.\n\nPeso: {float(r["weight_g"] or 0):.2f} g\nTempo: {float(r["print_hours"] or 0):.2f} h\nCusto usado: {brl(cost)}\nPreço sugerido: {brl(price)}')

    def import_3mf_from_pricing(self):
        vid=self.pr_saved_product.currentData() if hasattr(self,"pr_saved_product") else None
        if not vid:
            path,_=QFileDialog.getOpenFileName(self,"Selecionar 3MF do novo produto",str(Path.home()),"3MF (*.3mf);;Todos os arquivos (*)")
            if not path:return
            new_vid=self._create_product_from_3mf(path)
            if new_vid:
                self.refresh_pricing_page()
                ix=self.pr_saved_product.findData(new_vid)
                if ix>=0:self.pr_saved_product.setCurrentIndex(ix)
                self.load_saved_pricing_product()
            return
        path,_=QFileDialog.getOpenFileName(self,"Selecionar 3MF fatiado",str(Path.home()),"3MF (*.3mf);;Todos os arquivos (*)")
        if not path:return
        if self._apply_3mf_to_variant(vid,path):
            self.refresh_pricing_page()
            # Mantém o mesmo item carregado e atualiza os campos/painel de preço.
            ix=self.pr_saved_product.findData(vid)
            if ix>=0:self.pr_saved_product.setCurrentIndex(ix)
            self.load_saved_pricing_product()
            QMessageBox.information(self,"3MF importado","Peso, horas e cores foram importados. A precificação foi recalculada automaticamente com os padrões atuais.")

    def selected_variant_id(self):
        r=self.products_table.currentRow()
        if r<0:return None
        return self.products_table.item(r,0).data(Qt.UserRole)

    def edit_product(self):
        vid=self.selected_variant_id()
        if not vid:
            QMessageBox.information(self,"Produtos","Selecione uma variação.");return
        with db() as con:row=con.execute("SELECT * FROM variants WHERE id=?",(vid,)).fetchone()
        dlg=ProductDialog(self,row)
        if dlg.exec():
            v=dlg.values();now=datetime.now().isoformat(timespec="seconds")
            with db() as con:
                con.execute("""UPDATE variants SET boneco_name=?,weight_g=?,print_hours=?,
                               manual_cost=?,packaging_cost=?,other_cost=?,notes=?,updated_at=? WHERE id=?""",
                (v["boneco_name"],v["weight_g"],v["print_hours"],v["manual_cost"],v["packaging_cost"],v["other_cost"],v["notes"],now,vid))
            self.invalidate_data_pages();self.refresh_products()

    def edit_selected_colors(self):
        vid=self.selected_variant_id()
        if not vid:
            QMessageBox.information(self,"Produtos","Selecione uma variação.");return
        self.open_color_editor(vid)

    def open_color_editor(self,vid):
        with db() as con:r=con.execute("SELECT * FROM variants WHERE id=?",(vid,)).fetchone()
        if not r:return
        title=(r["boneco_name"] or r["variation_name"] or r["listing_name"])
        if ColorUsageDialog(self,vid,title).exec():
            self.invalidate_data_pages();self.refresh_products()

    def copy_product_info(self):
        target_id=self.selected_variant_id()
        if not target_id:
            QMessageBox.information(self,"Produtos","Selecione primeiro a linha que RECEBERÁ as informações.")
            return

        with db() as con:
            target=con.execute("SELECT * FROM variants WHERE id=?",(target_id,)).fetchone()
            sources=con.execute("SELECT * FROM variants WHERE active=1 AND id<>? ORDER BY boneco_name,variation_name,sku",(target_id,)).fetchall()

        if not sources:
            QMessageBox.information(self,"Produtos","Não existe outra variação para copiar.")
            return

        dlg=QDialog(self);dlg.setWindowTitle("Copiar informações de outro produto");dlg.resize(650,220)
        form=QFormLayout(dlg)
        info=QLabel(
            f'Destino: {target["boneco_name"] or target["variation_name"] or target["listing_name"]} • '
            f'{target["variation_name"] or "sem variação"} • SKU {target["sku"] or "—"}'
        )
        info.setWordWrap(True)
        combo=QComboBox()
        for r in sources:
            label=f'{r["boneco_name"] or r["variation_name"] or r["listing_name"]} • {r["variation_name"] or "sem variação"} • SKU {r["sku"] or "—"}'
            combo.addItem(label,r["id"])
        note=QLabel(
            "Serão copiados: nome do boneco, peso, horas, custo manual, embalagem, outros custos, observações e cores/gramas. "
            "SKU, anúncio e variação Shopee do destino NÃO mudam."
        )
        note.setWordWrap(True);note.setObjectName("Hint")
        form.addRow("Destino",info);form.addRow("Copiar de",combo);form.addRow(note)
        bb=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel);bb.accepted.connect(dlg.accept);bb.rejected.connect(dlg.reject);form.addRow(bb)

        if dlg.exec()!=QDialog.Accepted:return
        source_id=combo.currentData()

        with db() as con:
            source=con.execute("SELECT * FROM variants WHERE id=?",(source_id,)).fetchone()
            con.execute("""UPDATE variants SET boneco_name=?,weight_g=?,print_hours=?,manual_cost=?,
                           packaging_cost=?,other_cost=?,notes=?,updated_at=? WHERE id=?""",
                        (source["boneco_name"] or source["variation_name"] or source["listing_name"],
                         source["weight_g"],source["print_hours"],source["manual_cost"],source["packaging_cost"],
                         source["other_cost"],source["notes"],datetime.now().isoformat(timespec="seconds"),target_id))
            con.execute("DELETE FROM variant_colors WHERE variant_id=?",(target_id,))
            colors=con.execute("SELECT slot,color_name,grams_per_unit FROM variant_colors WHERE variant_id=? ORDER BY slot",(source_id,)).fetchall()
            for c in colors:
                con.execute("INSERT INTO variant_colors(variant_id,slot,color_name,grams_per_unit) VALUES (?,?,?,?)",
                            (target_id,c["slot"],c["color_name"],c["grams_per_unit"]))
            sync_variant_weight_from_colors(con,target_id)

        self.invalidate_data_pages();self.refresh_products()
        QMessageBox.information(self,"Produtos","Informações copiadas. Você pode editar o destino normalmente.")

    def add_filament(self):
        d=QDialog(self);d.setWindowTitle("Compra de filamento");f=QFormLayout(d)
        dt=QDateEdit(QDate.currentDate());dt.setCalendarPopup(True);dt.setDisplayFormat("dd/MM/yyyy")
        q=QDoubleSpinBox();q.setRange(.01,9999);q.setValue(1);v=QDoubleSpinBox();v.setRange(0,999999);v.setPrefix("R$ ");fr=QDoubleSpinBox();fr.setRange(0,999999);fr.setPrefix("R$ ");n=QLineEdit()
        for a,b in [("Data",dt),("Qtd. rolos",q),("Valor / rolo",v),("Frete / outros",fr),("Observação",n)]:f.addRow(a,b)
        bb=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);bb.accepted.connect(d.accept);bb.rejected.connect(d.reject);f.addRow(bb)
        if d.exec():
            with db() as con:con.execute("INSERT INTO filament_purchases(purchase_date,rolls,value_per_roll,freight_other,notes) VALUES (?,?,?,?,?)",
                                        (dt.date().toString("yyyy-MM-dd"),q.value(),v.value(),fr.value(),n.text()))
            self._month_cache.clear();self.mark_dirty("Dashboard","Financeiro","Relatórios");self.refresh_finance()

    def add_expense(self):
        d=QDialog(self);d.setWindowTitle("Despesa / MEI");f=QFormLayout(d)
        dt=QDateEdit(QDate.currentDate());dt.setCalendarPopup(True);dt.setDisplayFormat("dd/MM/yyyy")
        c=QComboBox();c.addItems(["MEI / DAS","Embalagens","Manutenção","Ferramentas","Energia extra","Outras despesas"]);desc=QLineEdit();v=QDoubleSpinBox();v.setRange(0,9999999);v.setPrefix("R$ ")
        for a,b in [("Data",dt),("Categoria",c),("Descrição",desc),("Valor",v)]:f.addRow(a,b)
        bb=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);bb.accepted.connect(d.accept);bb.rejected.connect(d.reject);f.addRow(bb)
        if d.exec():
            with db() as con:con.execute("INSERT INTO expenses(expense_date,category,description,value) VALUES (?,?,?,?)",(dt.date().toString("yyyy-MM-dd"),c.currentText(),desc.text(),v.value()))
            self._month_cache.clear();self.mark_dirty("Dashboard","Financeiro","Relatórios");self.refresh_finance()

    def backup(self):
        try:QMessageBox.information(self,"Backup",f"Backup criado:\n{create_backup()}")
        except Exception as e:QMessageBox.critical(self,"Backup",str(e))

    def fill(self,t,rows,user_ids=None):
        t.setUpdatesEnabled(False);t.setSortingEnabled(False)
        try:
            t.clearContents();t.setRowCount(len(rows))
            for r,row in enumerate(rows):
                for c,val in enumerate(row):
                    it=QTableWidgetItem(str(val))
                    if user_ids and c==0:it.setData(Qt.UserRole,user_ids[r])
                    t.setItem(r,c,it)
        finally:
            t.setUpdatesEnabled(True)

    def refresh_all(self):
        # Mantido apenas por compatibilidade interna. Não recarrega todas as abas de uma vez.
        self.invalidate_data_pages();self.refresh_page(self.stack.currentIndex(),force=True)

    def refresh_settings(self):
        if not hasattr(self,"settings"):return
        s=all_settings()
        for k,w in self.settings.items():
            try:w.setValue(float(s.get(k,0) or 0))
            except Exception:w.setValue(0)
        for k,w in getattr(self,"settings_text",{}).items():w.setText(str(s.get(k,"") or ""))

    def refresh_products(self):
        if not hasattr(self,"products_table"):return
        search=(self.product_search.text().strip().lower() if hasattr(self,"product_search") else "")
        boneco_filter=(self.product_boneco.currentData() if hasattr(self,"product_boneco") else None)
        status_filter=(self.product_status.currentText() if hasattr(self,"product_status") else "Todos os status")
        color_filter=(self.product_color.currentData() if hasattr(self,"product_color") else None)
        with db() as con:
            rows=con.execute("SELECT * FROM variants WHERE active=1 ORDER BY boneco_name,variation_name,sku").fetchall()
            color_rows=con.execute("SELECT variant_id,color_name,grams_per_unit FROM variant_colors ORDER BY variant_id,slot").fetchall()
            bonecos=[r["b"] for r in con.execute("SELECT DISTINCT COALESCE(NULLIF(TRIM(boneco_name),''),variation_name,listing_name) b FROM variants WHERE active=1 ORDER BY b").fetchall() if r["b"]]
            colors=[r["color_name"] for r in con.execute("SELECT DISTINCT color_name FROM variant_colors WHERE TRIM(color_name)<>'' ORDER BY color_name").fetchall()]
            settings={r["key"]:r["value"] for r in con.execute("SELECT key,value FROM settings").fetchall()}
        by_variant={}
        for c in color_rows:by_variant.setdefault(c["variant_id"],[]).append(c)
        self._set_combo_items(self.product_boneco,[(x,x) for x in bonecos],"Todos os bonecos",None,boneco_filter)
        self._set_combo_items(self.product_color,[(x,x) for x in colors],"Todas as cores",None,color_filter)
        boneco_filter=self.product_boneco.currentData();color_filter=self.product_color.currentData()
        vals=[];ids=[];fee=float(settings.get("shopee_fee_pct","30.12"))/100;markup=float(settings.get("markup_pct","190"))/100
        from services.product_groups import group_products
        grouped=not self.product_show_listings.isChecked()
        product_groups=group_products(rows,by_variant) if grouped else [(dict(r),[dict(r)]) for r in rows]
        self._product_group_members={}
        for r,members in product_groups:
            self._product_group_members[r["id"]]=members
            boneco=r["boneco_name"] or r["variation_name"] or r["listing_name"]
            clist=by_variant.get(r["id"],[])
            summary=" • ".join(f'{c["color_name"]} {float(c["grams_per_unit"]):g}g' for c in clist)
            cost_ok=float(r["manual_cost"] or 0)>0 or (float(r["weight_g"] or 0)>0 and float(r["print_hours"] or 0)>0)
            colors_ok=bool(clist)
            if cost_ok and colors_ok:display_status="OK"
            elif not cost_ok and not colors_ok:display_status="FALTA CUSTO + CORES"
            elif not cost_ok:display_status="FALTA CUSTO"
            else:display_status="FALTA CORES"
            if boneco_filter and not any((m["boneco_name"] or m["variation_name"] or m["listing_name"])==boneco_filter for m in members):continue
            if color_filter and not any(str(c["color_name"]).lower()==str(color_filter).lower() for c in clist):continue
            if status_filter=="Completo" and display_status!="OK":continue
            if status_filter=="Falta custo" and "CUSTO" not in display_status:continue
            if status_filter=="Falta cores" and "CORES" not in display_status:continue
            blob=" ".join([boneco or "",r["variation_name"] or "",r["sku"] or "",r["listing_name"] or "",summary]).lower()
            blob+=" "+" ".join(" ".join(str(m[k] or "") for k in ("boneco_name","variation_name","listing_name","sku")) for m in members).lower()
            if search and search not in blob:continue
            cost=variant_unit_cost(r,settings);price=(cost+float(r["packaging_cost"] or 0))*(1+markup)/(1-fee) if fee<1 else 0
            color_total=sum(float(c["grams_per_unit"] or 0) for c in clist)
            weight_display=f"{color_total:.1f} g • AUTO" if clist else f'{r["weight_g"]:.1f} g'
            variation_display=f"{len(members)} cadastros / anúncios" if grouped and len(members)>1 else (r["variation_name"] or "Sem variação")
            sku_display=", ".join(sorted({m["sku"] for m in members if m["sku"]})) or "—"
            signatures={(m["weight_g"],m["print_hours"],m["manual_cost"],m["packaging_cost"],m["other_cost"],tuple((c["color_name"],c["grams_per_unit"]) for c in by_variant.get(m["id"],[]))) for m in members}
            if grouped and len(signatures)>1:display_status+=" • CADASTROS DIVERGENTES"
            vals.append([boneco,variation_display,sku_display,summary or "PREENCHER CORES",weight_display,f'{r["print_hours"]:.2f} h',brl(cost),brl(r["packaging_cost"]),brl(price),display_status]);ids.append(r["id"])
        self.fill(self.products_table,vals,ids)
        for index,vid in enumerate(ids):
            members=self._product_group_members[vid]
            detail="\n".join(f"{m['boneco_name']} | {m['variation_name']} | SKU {m['sku'] or '—'} | {m['listing_name']}" for m in members)
            for column in range(self.products_table.columnCount()):self.products_table.item(index,column).setToolTip(detail+"\nEditar/custos/cores/3MF usam o cadastro mais completo exibido. Para outra origem, marque VER ANÚNCIOS.")

    def refresh_orders(self):
        if not hasattr(self,"orders_table"):return
        search=(self.order_search.text().strip().lower() if hasattr(self,"order_search") else "")
        status=(self.order_status.currentText() if hasattr(self,"order_status") else "Todos os status")
        month=(self.order_month.currentData() if hasattr(self,"order_month") else None)
        boneco_filter=(self.order_boneco.currentData() if hasattr(self,"order_boneco") else None)
        boneco_expr="COALESCE(NULLIF(TRIM(cv.boneco_name),''),NULLIF(TRIM(v.boneco_name),''),NULLIF(TRIM(oi.variation_name),''),oi.listing_name)"
        with db() as con:
            statuses=[r["status"] for r in con.execute("SELECT DISTINCT status FROM orders WHERE status<>'' ORDER BY status").fetchall()]
            months=[r["month_key"] for r in con.execute("SELECT DISTINCT month_key FROM orders WHERE month_key<>'' ORDER BY month_key").fetchall()]
            bonecos=[r["b"] for r in con.execute(f"""SELECT DISTINCT {boneco_expr} b
                FROM order_items oi
                LEFT JOIN variants v ON v.variant_key=oi.variant_key
                LEFT JOIN variant_mappings vm ON vm.source_variant_id=v.id
                LEFT JOIN variants cv ON cv.id=vm.target_variant_id
                WHERE b IS NOT NULL ORDER BY b""").fetchall()]
            self._set_combo_items(self.order_status,[(x,x) for x in statuses],"Todos os status",None,status if status!="Todos os status" else None)
            self._set_combo_items(self.order_month,[(month_label(x),x) for x in months],"Todos os meses",None,month)
            self._set_combo_items(self.order_boneco,[(x,x) for x in bonecos if x],"Todos os bonecos",None,boneco_filter)
            status=self.order_status.currentText();month=self.order_month.currentData();boneco_filter=self.order_boneco.currentData()

            where=[];params=[]
            if status!="Todos os status":where.append("o.status=?");params.append(status)
            if month:where.append("o.month_key=?");params.append(month)
            if boneco_filter:where.append(f"{boneco_expr}=?");params.append(boneco_filter)
            if search:
                where.append(f"LOWER(COALESCE(o.order_id,'')||' '||COALESCE(oi.sku,'')||' '||COALESCE({boneco_expr},'')||' '||COALESCE(oi.variation_name,'')) LIKE ?")
                params.append(f"%{search}%")
            clause=(" WHERE "+" AND ".join(where)) if where else ""
            rows=con.execute(f"""SELECT o.order_id,o.status,o.month_key,o.paid_at,o.commission_fee,o.service_fee,o.total_platform_fee,
                                      oi.sku,oi.variation_name,oi.quantity,oi.subtotal,{boneco_expr} boneco
                               FROM order_items oi JOIN orders o ON o.order_id=oi.order_id
                               LEFT JOIN variants v ON v.variant_key=oi.variant_key
                               LEFT JOIN variant_mappings vm ON vm.source_variant_id=v.id
                               LEFT JOIN variants cv ON cv.id=vm.target_variant_id
                               {clause}
                               ORDER BY COALESCE(o.paid_at,o.created_at) DESC LIMIT 1500""",params).fetchall()
        out=[[r["order_id"],r["status"],(r["paid_at"] or "—")[:16],r["sku"] or "—",r["boneco"] or "—",r["variation_name"] or "—",
              f'{r["quantity"]:.0f}',brl(r["subtotal"]),brl(r["commission_fee"]),brl(r["service_fee"]),brl(r["total_platform_fee"])] for r in rows]
        self.fill(self.orders_table,out)

    def refresh_imports(self):
        if not hasattr(self,"import_history"):return
        search=self.import_search.text().strip().lower() if hasattr(self,"import_search") else ""
        source=self.import_source_filter.currentData() if hasattr(self,"import_source_filter") else None
        month=self.import_month_filter.currentData() if hasattr(self,"import_month_filter") else None
        with db() as con:
            sources=[r["source_type"] for r in con.execute("SELECT DISTINCT source_type FROM imports ORDER BY source_type").fetchall()]
            months=[r["m"] for r in con.execute("SELECT DISTINCT substr(period_start,1,7) m FROM imports WHERE period_start IS NOT NULL AND period_start<>'' ORDER BY m").fetchall() if r["m"]]
            self._set_combo_items(self.import_source_filter,[(x,x) for x in sources],"Todas as fontes",None,source)
            self._set_combo_items(self.import_month_filter,[(month_label(x),x) for x in months],"Todos os meses",None,month)
            source=self.import_source_filter.currentData();month=self.import_month_filter.currentData()
            where=[];params=[]
            if source:where.append("source_type=?");params.append(source)
            if month:where.append("substr(period_start,1,7)=?");params.append(month)
            if search:
                where.append("LOWER(COALESCE(file_name,'')||' '||COALESCE(source_type,'')||' '||COALESCE(archived_path,'')) LIKE ?")
                params.append(f"%{search}%")
            clause=(" WHERE "+" AND ".join(where)) if where else ""
            rows=con.execute(f"SELECT * FROM imports{clause} ORDER BY imported_at DESC LIMIT 500",params).fetchall()
        self.fill(self.import_history,[[r["imported_at"].replace("T"," "),r["source_type"],r["file_name"],f'{r["period_start"] or "?"} → {r["period_end"] or "?"}',r["archived_path"]] for r in rows])

    def refresh_finance(self):
        if not hasattr(self,"finance_summary"):return
        search=self.finance_search.text().strip().lower() if hasattr(self,"finance_search") else ""
        selected_month=self.finance_month.currentData() if hasattr(self,"finance_month") else None
        selected_cat=self.finance_category.currentData() if hasattr(self,"finance_category") else None
        with db() as con:
            stat_months=[r["month_key"] for r in con.execute("SELECT month_key FROM monthly_stats ORDER BY month_key").fetchall()]
            purchase_months=[r["m"] for r in con.execute("SELECT DISTINCT substr(purchase_date,1,7) m FROM filament_purchases ORDER BY m").fetchall() if r["m"]]
            expense_months=[r["m"] for r in con.execute("SELECT DISTINCT substr(expense_date,1,7) m FROM expenses ORDER BY m").fetchall() if r["m"]]
            categories=[r["category"] for r in con.execute("SELECT DISTINCT category FROM expenses WHERE TRIM(category)<>'' ORDER BY category").fetchall()]
            fs=con.execute("SELECT * FROM filament_purchases ORDER BY purchase_date DESC,id DESC").fetchall()
            es=con.execute("SELECT * FROM expenses ORDER BY expense_date DESC,id DESC").fetchall()
        all_months=sorted(set(stat_months+purchase_months+expense_months))
        self._set_combo_items(self.finance_month,[(month_label(x),x) for x in all_months],"Todos os meses",None,selected_month)
        self._set_combo_items(self.finance_category,[(x,x) for x in categories],"Todas as categorias",None,selected_cat)
        selected_month=self.finance_month.currentData();selected_cat=self.finance_category.currentData()
        data=[]
        for m in stat_months:
            if selected_month and m!=selected_month:continue
            x=self.month_data(m);data.append([month_label(m),brl(x["stats"]["paid_sales"]),brl(x["fees"]),brl(x["production"]),brl(x["packaging"]),brl(x["filament"]),brl(x["mei"]),brl(x["other"]),brl(x["cash"])])
        self.fill(self.finance_summary,data)
        fil=[]
        for r in fs:
            if selected_month and not str(r["purchase_date"]).startswith(selected_month):continue
            blob=" ".join([r["purchase_date"] or "",r["notes"] or ""]).lower()
            if search and search not in blob:continue
            fil.append([r["purchase_date"],r["rolls"],brl(r["value_per_roll"]),brl(r["freight_other"]),brl(r["rolls"]*r["value_per_roll"]+r["freight_other"]),r["notes"]])
        exp=[]
        for r in es:
            if selected_month and not str(r["expense_date"]).startswith(selected_month):continue
            if selected_cat and r["category"]!=selected_cat:continue
            blob=" ".join([r["expense_date"] or "",r["category"] or "",r["description"] or "",r["notes"] or ""]).lower()
            if search and search not in blob:continue
            exp.append([r["expense_date"],r["category"],r["description"],brl(r["value"])])
        self.fill(self.fil_table,fil);self.fill(self.exp_table,exp)

    def refresh_reports(self):
        if not hasattr(self,"report_table"):return
        selected_year=self.report_year.currentData() if hasattr(self,"report_year") else None
        limit=self.report_range.currentData() if hasattr(self,"report_range") else 0
        coverage=self.report_coverage.currentText() if hasattr(self,"report_coverage") else "Todas as taxas"
        with db() as con:all_months=[r["month_key"] for r in con.execute("SELECT month_key FROM monthly_stats ORDER BY month_key").fetchall()]
        years=sorted({m[:4] for m in all_months})
        self._set_combo_items(self.report_year,[(y,y) for y in years],"Todos os anos",None,selected_year)
        selected_year=self.report_year.currentData()
        months=[m for m in all_months if not selected_year or m.startswith(selected_year+"-")]
        if limit and len(months)>limit:months=months[-int(limit):]
        rows=[];sales=[];results=[];cash=[];kept=[]
        for m in months:
            x=self.month_data(m);s=x["stats"]
            if coverage=="Somente taxas reais" and x["fee_mode"]!="real":continue
            if coverage=="Somente estimadas" and x["fee_mode"]=="real":continue
            kept.append(m);sales.append(float(s["paid_sales"]));results.append(x["after"]);cash.append(x["cash"])
            cov=f'REAL {x["detail_min"]}→{x["detail_max"]}' if x["fee_mode"]=="real" else "TAXA ESTIMADA"
            if x["partial"]:cov+=" • CUSTOS PARCIAIS"
            rows.append([month_label(m),f'{s["period_start"]}→{s["period_end"]}',f'{s["paid_orders"]:.0f}',f'{s["paid_units"]:.0f}',brl(s["paid_sales"]),brl(x["fees"]),brl(x["after"]),brl(x["cash"]),cov])
        self.fill(self.report_table,rows);self.report_chart.set_data([month_label(m) for m in kept],[("Vendas",sales),("Resultado",results),("Caixa",cash)])
        if kept:
            best=max(range(len(sales)),key=lambda i:sales[i]);self.r_best.set_value(brl(sales[best]),month_label(kept[best]));self.r_last.set_value(brl(sales[-1]),month_label(kept[-1]))
            var=((sales[-1]/sales[-2]-1)*100) if len(sales)>1 and sales[-2] else 0;self.r_var.set_value(f"{var:+.1f}%","vs. mês anterior filtrado")
            x=self.month_data(kept[-1]);margin=x["after"]/float(x["stats"]["paid_sales"] or 1)*100;self.r_margin.set_value(f"{margin:.1f}%","resultado / vendas")
        else:
            for c in [self.r_best,self.r_last,self.r_var,self.r_margin]:c.set_value("—")

    def refresh_dashboard(self):
        if not hasattr(self,"c_sales"):return
        selected=self.dashboard_month.currentData() if hasattr(self,"dashboard_month") else None
        chart_limit=self.dashboard_range.currentData() if hasattr(self,"dashboard_range") else 6
        with db() as con:months=[r["month_key"] for r in con.execute("SELECT month_key FROM monthly_stats ORDER BY month_key").fetchall()]
        self._set_combo_items(self.dashboard_month,[(month_label(x),x) for x in months],None,None,selected)
        if not months:
            for c in [self.c_sales,self.c_orders,self.c_units,self.c_fees,self.c_result,self.c_cash]:c.set_value("—")
            self.chart.set_data([],[]);self.origins.set_data([]);self.fill(self.top_variations.table,[]);self.fill(self.recent_orders.table,[]);self.fill(self.color_usage.table,[]);return
        if self.dashboard_month.currentData() not in months:
            self.dashboard_month.blockSignals(True);self.dashboard_month.setCurrentIndex(len(months)-1);self.dashboard_month.blockSignals(False)
        m=self.dashboard_month.currentData() or months[-1]
        x=self.month_data(m);s=x["stats"]
        self.c_sales.set_value(brl(s["paid_sales"]),month_label(m));self.c_orders.set_value(f'{s["paid_orders"]:.0f}',f'cancelados: {s["canceled_orders"]:.0f}')
        self.c_units.set_value(f'{s["paid_units"]:.0f}',"unidades pagas");self.c_fees.set_value(brl(x["fees"]),x["fee_mode"].upper())
        self.c_result.set_value(brl(x["after"]),"PARCIAL — faltam pedidos detalhados" if x["partial"] else f'{x["missing_costs"]} variações sem custo' if x["missing_costs"] else "custos preenchidos");self.c_cash.set_value(brl(x["cash"]),"movimento de caixa")
        upto=months[:months.index(m)+1]
        if chart_limit and len(upto)>int(chart_limit):upto=upto[-int(chart_limit):]
        sales=[];res=[];cash=[]
        for k in upto:
            z=self.month_data(k);sales.append(float(z["stats"]["paid_sales"]));res.append(z["after"]);cash.append(z["cash"])
        self.chart.set_data([month_label(k) for k in upto],[("Vendas",sales),("Resultado",res),("Caixa",cash)])
        self.origins.set_data([("Cards",float(s["card_sales"])),("Lives",float(s["live_sales"])),("Vídeos",float(s["video_sales"])),("Afiliado",float(s["affiliate_sales"])),("Anúncios",float(s["ads_sales"]))])
        self.coverage_text.setText(f"Stats oficiais:\n{s['period_start']} → {s['period_end']}\n\nPedidos detalhados:\n{x['detail_min'] or 'não importado'} → {x['detail_max'] or 'não importado'}\n\nTaxas: {x['fee_mode'].upper()}")
        if x['partial']:
            self.coverage_text.setText(self.coverage_text.text()+f"\n\nCOBERTURA PARCIAL: {x['detail_orders']} pedidos detalhados / {s['paid_orders']:.0f} pagos no resumo. Custos e consumo por cor usam somente os pedidos detalhados. Importe Todos os pedidos (Order.all) para todas as variações.")
        if abs(x['catalog_gap_units'])>.001:self.coverage_text.setText(self.coverage_text.text()+f"\nUnidades sem identificação no resumo por produto: {x['catalog_gap_units']:g}.")
        self.color_usage.findChildren(QLabel)[0].setText("Consumo por cor — pedidos detalhados (PARCIAL)" if x['partial'] else "Consumo de filamento por cor")
        tops=top_bonecos(m,6);self.fill(self.top_variations.table,[[r["boneco"] or "—",f'{r["units"]:.0f}','Resumo' if r["skus"] is None else f'{r["skus"]:.0f}'] for r in tops])
        with db() as con:
            rec=con.execute("""SELECT o.order_id,o.status,o.paid_at,oi.quantity,oi.subtotal,COALESCE(NULLIF(TRIM(cv.boneco_name),''),NULLIF(TRIM(v.boneco_name),''),NULLIF(TRIM(oi.variation_name),''),oi.listing_name) boneco,oi.variation_name FROM order_items oi JOIN orders o ON o.order_id=oi.order_id LEFT JOIN variants v ON v.variant_key=oi.variant_key LEFT JOIN variant_mappings vm ON vm.source_variant_id=v.id LEFT JOIN variants cv ON cv.id=vm.target_variant_id WHERE o.month_key=? AND o.status<>'Cancelado' ORDER BY COALESCE(o.paid_at,o.created_at) DESC LIMIT 6""",(m,)).fetchall()
        self.fill(self.recent_orders.table,[[r["order_id"],r["boneco"] or "—",r["variation_name"] or "—",f'{r["quantity"]:.0f}',brl(r["subtotal"])] for r in rec])
        usage=filament_usage_month_and_fortnight(m);rows=[["TOTAL",f'{usage["fortnight_kg"]:.3f}',f'{usage["month_kg"]:.3f}']]+[[r["color"],f'{r["fortnight_kg"]:.3f}',f'{r["month_kg"]:.3f}'] for r in usage["rows"][:7]]
        if not usage["rows"]:rows=[["Cadastre cores","—","—"]]
        self.fill(self.color_usage.table,rows)


def main():
    initialize_database();app=QApplication(sys.argv);app.setStyleSheet(STYLE);w=MainWindow();w.show();sys.exit(app.exec())

if __name__=="__main__":main()
