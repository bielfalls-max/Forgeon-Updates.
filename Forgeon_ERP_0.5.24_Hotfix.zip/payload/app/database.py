import sqlite3, shutil
from contextlib import contextmanager, closing
from datetime import datetime
from config import DB_PATH, BACKUP_DIR

SCHEMA = """
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS settings(
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS listings(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  shopee_item_id TEXT UNIQUE,
  main_sku TEXT,
  name TEXT NOT NULL,
  active INTEGER DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS variants(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  listing_id INTEGER,
  variant_key TEXT UNIQUE NOT NULL,
  sku TEXT,
  main_sku TEXT,
  listing_name TEXT NOT NULL,
  variation_name TEXT,
  boneco_name TEXT DEFAULT '',
  weight_g REAL DEFAULT 0,
  print_hours REAL DEFAULT 0,
  manual_cost REAL DEFAULT 0,
  packaging_cost REAL DEFAULT 0.30,
  other_cost REAL DEFAULT 0,
  notes TEXT DEFAULT '',
  active INTEGER DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY(listing_id) REFERENCES listings(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS variant_colors(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  variant_id INTEGER NOT NULL,
  slot INTEGER NOT NULL,
  color_name TEXT NOT NULL,
  grams_per_unit REAL NOT NULL DEFAULT 0,
  UNIQUE(variant_id,slot),
  FOREIGN KEY(variant_id) REFERENCES variants(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS sku_registry(
  sku TEXT PRIMARY KEY COLLATE NOCASE,
  product_name TEXT NOT NULL DEFAULT '',
  retired INTEGER NOT NULL DEFAULT 0,
  variant_id INTEGER,
  created_at TEXT NOT NULL,
  FOREIGN KEY(variant_id) REFERENCES variants(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS monthly_stats(
  month_key TEXT PRIMARY KEY,
  period_start TEXT NOT NULL,
  period_end TEXT NOT NULL,
  paid_orders REAL DEFAULT 0,
  paid_units REAL DEFAULT 0,
  paid_sales REAL DEFAULT 0,
  canceled_orders REAL DEFAULT 0,
  refunded_orders REAL DEFAULT 0,
  card_sales REAL DEFAULT 0,
  live_sales REAL DEFAULT 0,
  video_sales REAL DEFAULT 0,
  affiliate_sales REAL DEFAULT 0,
  ads_sales REAL DEFAULT 0,
  source_file TEXT,
  source_hash TEXT,
  imported_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS monthly_stats_products(
  month_key TEXT NOT NULL,
  shopee_item_id TEXT NOT NULL,
  product_name TEXT NOT NULL,
  orders REAL DEFAULT 0,
  units REAL DEFAULT 0,
  sales REAL DEFAULT 0,
  PRIMARY KEY(month_key, shopee_item_id),
  FOREIGN KEY(month_key) REFERENCES monthly_stats(month_key) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS orders(
  order_id TEXT PRIMARY KEY,
  month_key TEXT NOT NULL,
  status TEXT,
  return_status TEXT,
  created_at TEXT,
  paid_at TEXT,
  main_sku TEXT,
  listing_name TEXT,
  order_value REAL DEFAULT 0,
  reverse_shipping_fee REAL DEFAULT 0,
  transaction_fee REAL DEFAULT 0,
  commission_fee REAL DEFAULT 0,
  service_fee REAL DEFAULT 0,
  total_platform_fee REAL DEFAULT 0,
  source_file TEXT,
  imported_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS order_items(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id TEXT NOT NULL,
  line_index INTEGER NOT NULL,
  variant_key TEXT NOT NULL,
  sku TEXT,
  main_sku TEXT,
  listing_name TEXT,
  variation_name TEXT,
  quantity REAL DEFAULT 0,
  returned_quantity REAL DEFAULT 0,
  original_price REAL DEFAULT 0,
  agreed_price REAL DEFAULT 0,
  subtotal REAL DEFAULT 0,
  UNIQUE(order_id,line_index),
  FOREIGN KEY(order_id) REFERENCES orders(order_id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS imports(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  source_type TEXT NOT NULL,
  file_name TEXT NOT NULL,
  file_hash TEXT NOT NULL,
  period_start TEXT,
  period_end TEXT,
  month_keys TEXT,
  archived_path TEXT,
  imported_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS filament_purchases(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  purchase_date TEXT NOT NULL,
  rolls REAL NOT NULL,
  value_per_roll REAL NOT NULL,
  freight_other REAL DEFAULT 0,
  notes TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS expenses(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  expense_date TEXT NOT NULL,
  category TEXT NOT NULL,
  description TEXT DEFAULT '',
  value REAL NOT NULL,
  notes TEXT DEFAULT ''
);

CREATE INDEX IF NOT EXISTS idx_orders_month ON orders(month_key);
CREATE INDEX IF NOT EXISTS idx_orders_paid ON orders(paid_at);
CREATE INDEX IF NOT EXISTS idx_items_order ON order_items(order_id);
CREATE INDEX IF NOT EXISTS idx_expenses_month ON expenses(expense_date);
CREATE INDEX IF NOT EXISTS idx_filament_month ON filament_purchases(purchase_date);
CREATE INDEX IF NOT EXISTS idx_variant_colors_variant ON variant_colors(variant_id);
CREATE INDEX IF NOT EXISTS idx_variant_colors_color ON variant_colors(color_name,variant_id);
CREATE INDEX IF NOT EXISTS idx_orders_month_status_paid ON orders(month_key,status,paid_at,created_at);
CREATE INDEX IF NOT EXISTS idx_order_items_variant ON order_items(variant_key,order_id);
CREATE INDEX IF NOT EXISTS idx_order_items_sku ON order_items(sku);
CREATE INDEX IF NOT EXISTS idx_imports_period_type ON imports(period_start,source_type,imported_at);

CREATE TABLE IF NOT EXISTS variant_mappings(
  source_variant_id INTEGER PRIMARY KEY,
  target_variant_id INTEGER NOT NULL,
  notes TEXT DEFAULT '',
  updated_at TEXT NOT NULL,
  FOREIGN KEY(source_variant_id) REFERENCES variants(id) ON DELETE CASCADE,
  FOREIGN KEY(target_variant_id) REFERENCES variants(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_variant_mappings_target ON variant_mappings(target_variant_id);

CREATE TABLE IF NOT EXISTS ad_drafts(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  makerworld_url TEXT DEFAULT '',
  source_title TEXT DEFAULT '',
  source_description TEXT DEFAULT '',
  source_creator TEXT DEFAULT '',
  source_license TEXT DEFAULT '',
  source_model_id TEXT DEFAULT '',
  source_profile_id TEXT DEFAULT '',
  source_tags TEXT DEFAULT '',
  product_name TEXT NOT NULL DEFAULT '',
  sku TEXT DEFAULT '',
  variant_id INTEGER,
  title TEXT DEFAULT '',
  description TEXT DEFAULT '',
  material TEXT DEFAULT 'PLA',
  product_height_cm REAL DEFAULT 0,
  category_id TEXT DEFAULT '',
  price REAL DEFAULT 0,
  stock INTEGER DEFAULT 1,
  weight_g REAL DEFAULT 0,
  print_hours REAL DEFAULT 0,
  length_cm REAL DEFAULT 0,
  width_cm REAL DEFAULT 0,
  height_cm REAL DEFAULT 0,
  preorder_days INTEGER DEFAULT 3,
  ncm TEXT DEFAULT '',
  cfop_same TEXT DEFAULT '',
  cfop_diff TEXT DEFAULT '',
  product_origin TEXT DEFAULT '',
  csosn TEXT DEFAULT '',
  cest TEXT DEFAULT '',
  measure_unit TEXT DEFAULT 'UN',
  print_file TEXT DEFAULT '',
  status TEXT DEFAULT 'RASCUNHO',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY(variant_id) REFERENCES variants(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS ad_images(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  draft_id INTEGER NOT NULL,
  position INTEGER NOT NULL,
  source_url TEXT DEFAULT '',
  original_path TEXT DEFAULT '',
  edited_path TEXT DEFAULT '',
  public_url TEXT DEFAULT '',
  selected INTEGER DEFAULT 1,
  UNIQUE(draft_id,position),
  FOREIGN KEY(draft_id) REFERENCES ad_drafts(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_ad_drafts_sku ON ad_drafts(sku);
CREATE INDEX IF NOT EXISTS idx_ad_images_draft ON ad_images(draft_id,position);
"""

DEFAULT_SETTINGS = {
 "filament_price_kg":"80.00",
 "energy_price_kwh":"1.40",
 "printer_power_w":"200",
 "machine_hour_cost":"1.00",
 "labor_cost":"5.00",
 "failure_rate_pct":"0.10",
 "default_packaging_cost":"0.30",
 "markup_pct":"190.00",
 "shopee_fee_pct":"30.12",
 "company_name":"Forgeon Studio",
 "shopee_default_stock":"10",
 "shopee_default_preorder_days":"3",
 "shopee_default_category":"",
 "shopee_ncm":"",
 "shopee_cfop_same":"",
 "shopee_cfop_diff":"",
 "shopee_origin":"0 - Nacional",
 "shopee_csosn":"",
 "shopee_cest":"",
 "shopee_measure_unit":"UN",
 "shopee_pis_cofins_cst":"",
 "shopee_tax_total_pct":"",
 "shopee_operation_type":"",
 "shopee_ex_tipi":"",
 "shopee_fci_num":"",
 "shopee_recopi_num":"",
 "shopee_additional_info":"",
 "shopee_xpress_cpf":"Ativado",
 "shopee_pickup":"Desativado",
 "cloudinary_cloud_name":"",
 "cloudinary_upload_preset":""
}

DEFAULT_COLORS = [
    "Preto","Branco","Azul","Vermelho","Amarelo","Verde","Roxo","Laranja",
    "Dourado","Rosa bebê","Cinza","Bege","Marrom","Prata",
    "Duo Preto/Azul","Duo Preto/Vermelho","Tri Dourado/Rosa/Laranja"
]

def connect():
    con=sqlite3.connect(DB_PATH, timeout=8)
    con.row_factory=sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    con.execute("PRAGMA synchronous=NORMAL")
    con.execute("PRAGMA temp_store=MEMORY")
    con.execute("PRAGMA busy_timeout=8000")
    return con

@contextmanager
def db():
    con=connect()
    try:
        yield con
        con.commit()
    except Exception:
        con.rollback()
        raise
    finally:
        con.close()

def _table_exists(con, table):
    return con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",(table,)).fetchone() is not None

def _column_exists(con, table, column):
    return any(r["name"] == column for r in con.execute(f"PRAGMA table_info({table})").fetchall())

def _variant_score(row):
    score=0
    for k in ("boneco_name","variation_name","listing_name","sku"):
        if str(row[k] or "").strip(): score+=1
    if float(row["weight_g"] or 0)>0: score+=4
    if float(row["print_hours"] or 0)>0: score+=4
    if float(row["manual_cost"] or 0)>0: score+=5
    if float(row["other_cost"] or 0)>0: score+=1
    if str(row["variant_key"] or "").startswith("SKU:"): score+=3
    return score

def _merge_exact_duplicate_skus(con):
    """
    Une apenas registros que tenham exatamente o MESMO SKU.
    Se Amy estiver em dois anúncios com SKUs diferentes, os dois continuam existindo
    para que as vendas sejam rastreadas corretamente. A cópia de custos/cores é feita pela interface.
    """
    dups=con.execute("""
        SELECT TRIM(sku) sku, COUNT(*) qtd
        FROM variants
        WHERE sku IS NOT NULL AND TRIM(sku)<>''
        GROUP BY TRIM(sku)
        HAVING COUNT(*)>1
    """).fetchall()

    for d in dups:
        sku=d["sku"]
        rows=con.execute("SELECT * FROM variants WHERE TRIM(sku)=? ORDER BY id",(sku,)).fetchall()
        if len(rows)<2: continue

        canonical=max(rows,key=_variant_score)
        canonical_id=canonical["id"]
        canonical_key=canonical["variant_key"]
        merged=dict(canonical)

        for r in rows:
            if r["id"]==canonical_id: continue
            for field in ("boneco_name","variation_name","listing_name","main_sku","notes"):
                if not str(merged.get(field) or "").strip() and str(r[field] or "").strip():
                    merged[field]=r[field]
            for field in ("weight_g","print_hours","manual_cost","other_cost"):
                if float(merged.get(field) or 0)<=0 and float(r[field] or 0)>0:
                    merged[field]=r[field]
            if float(merged.get("packaging_cost") or 0)<=0 and float(r["packaging_cost"] or 0)>0:
                merged["packaging_cost"]=r["packaging_cost"]

        con.execute("""UPDATE variants SET boneco_name=?,variation_name=?,listing_name=?,main_sku=?,notes=?,
                       weight_g=?,print_hours=?,manual_cost=?,packaging_cost=?,other_cost=? WHERE id=?""",
                    (merged.get("boneco_name"),merged.get("variation_name"),merged.get("listing_name"),
                     merged.get("main_sku"),merged.get("notes"),merged.get("weight_g"),merged.get("print_hours"),
                     merged.get("manual_cost"),merged.get("packaging_cost"),merged.get("other_cost"),canonical_id))

        # Traz as cores do duplicado se o registro principal ainda não as tiver.
        current=con.execute("SELECT slot,color_name,grams_per_unit FROM variant_colors WHERE variant_id=? ORDER BY slot",(canonical_id,)).fetchall()
        used_colors={str(x["color_name"]).strip().lower() for x in current}
        used_slots={int(x["slot"]) for x in current}
        free_slots=[s for s in range(1,9) if s not in used_slots]

        for r in rows:
            if r["id"]==canonical_id: continue
            colors=con.execute("SELECT color_name,grams_per_unit FROM variant_colors WHERE variant_id=? ORDER BY slot",(r["id"],)).fetchall()
            for c in colors:
                name=str(c["color_name"] or "").strip()
                if not name or name.lower() in used_colors or not free_slots: continue
                slot=free_slots.pop(0)
                con.execute("INSERT OR IGNORE INTO variant_colors(variant_id,slot,color_name,grams_per_unit) VALUES (?,?,?,?)",
                            (canonical_id,slot,name,float(c["grams_per_unit"] or 0)))
                used_colors.add(name.lower())

        # Pedidos antigos passam a apontar para a chave canônica.
        for r in rows:
            if r["id"]==canonical_id: continue
            con.execute("UPDATE order_items SET variant_key=? WHERE variant_key=?",(canonical_key,r["variant_key"]))
            con.execute("DELETE FROM variants WHERE id=?",(r["id"],))


def sync_variant_weight_from_colors(con, variant_id=None):
    """
    Se houver cores cadastradas, weight_g vira automaticamente a soma dos gramas.
    Sem cores, o peso manual existente é preservado.
    """
    now=datetime.now().isoformat(timespec="seconds")
    if variant_id is not None:
        row=con.execute(
            "SELECT COUNT(*) qtd,COALESCE(SUM(grams_per_unit),0) total FROM variant_colors WHERE variant_id=?",
            (variant_id,)
        ).fetchone()
        qtd=int(row["qtd"] or 0)
        total=float(row["total"] or 0)
        if qtd>0:
            con.execute("UPDATE variants SET weight_g=?,updated_at=? WHERE id=?",(total,now,variant_id))
            return total
        return None

    rows=con.execute(
        "SELECT variant_id,COUNT(*) qtd,COALESCE(SUM(grams_per_unit),0) total FROM variant_colors GROUP BY variant_id"
    ).fetchall()
    if rows:
        con.executemany(
            "UPDATE variants SET weight_g=?,updated_at=? WHERE id=?",
            [(float(r["total"] or 0),now,r["variant_id"]) for r in rows if int(r["qtd"] or 0)>0]
        )
    return len(rows)

def _migrate(con):
    if _table_exists(con,"sku_registry") and not _column_exists(con,"sku_registry","retired"):
        con.execute("ALTER TABLE sku_registry ADD COLUMN retired INTEGER NOT NULL DEFAULT 0")
    # Compatibilidade automática com bancos das versões anteriores.
    if not _column_exists(con, "variants", "boneco_name"):
        con.execute("ALTER TABLE variants ADD COLUMN boneco_name TEXT DEFAULT ''")

    con.execute("""
        UPDATE variants
        SET boneco_name = COALESCE(NULLIF(TRIM(boneco_name),''), NULLIF(TRIM(variation_name),''), listing_name)
        WHERE boneco_name IS NULL OR TRIM(boneco_name)=''
    """)

    # Compatibilidade com builds de teste da aba de anúncios.
    if _table_exists(con, "ad_drafts"):
        for col, ddl in [
            ("source_creator", "TEXT DEFAULT ''"),
            ("source_license", "TEXT DEFAULT ''"),
            ("source_model_id", "TEXT DEFAULT ''"),
            ("source_profile_id", "TEXT DEFAULT ''"),
            ("source_tags", "TEXT DEFAULT ''"),
            ("material", "TEXT DEFAULT 'PLA'"),
            ("product_height_cm", "REAL DEFAULT 0"),
        ]:
            if not _column_exists(con, "ad_drafts", col):
                con.execute(f"ALTER TABLE ad_drafts ADD COLUMN {col} {ddl}")

    # Um SKU nunca deve mapear para ele mesmo.
    if _table_exists(con, "variant_mappings"):
        con.execute("DELETE FROM variant_mappings WHERE source_variant_id=target_variant_id")

    # Duplicated codes remain visible for explicit user correction; never merge automatically.
    sync_variant_weight_from_colors(con)

def initialize_database():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    if DB_PATH.exists():
        with closing(sqlite3.connect(DB_PATH)) as previous:
            if previous.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='variants'").fetchone() and not previous.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='sku_registry'").fetchone():
                BACKUP_DIR.mkdir(parents=True,exist_ok=True)
                destination=BACKUP_DIR/f"antes_catalogo_sku_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}.db"
                with closing(sqlite3.connect(destination)) as backup:previous.backup(backup)
    with db() as con:
        con.execute("PRAGMA journal_mode=WAL")
        con.executescript(SCHEMA)
        _migrate(con)
        from services.sku_catalog import sync_existing
        sync_existing(con)
        from importers.shopee_catalog import ensure_stats_catalog
        ensure_stats_catalog(con)
        for k,v in DEFAULT_SETTINGS.items():
            con.execute("INSERT OR IGNORE INTO settings(key,value) VALUES (?,?)",(k,v))

def get_setting(key, default="0"):
    with db() as con:
        r=con.execute("SELECT value FROM settings WHERE key=?",(key,)).fetchone()
    return r["value"] if r else default

def set_setting(key,value):
    with db() as con:
        con.execute("INSERT INTO settings(key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(key,str(value)))

def all_settings():
    with db() as con:
        return {r["key"]:r["value"] for r in con.execute("SELECT key,value FROM settings").fetchall()}

def create_backup():
    initialize_database()
    stamp=datetime.now().strftime("%Y%m%d_%H%M%S")
    dest=BACKUP_DIR/f"forgeon_{stamp}.db"
    with closing(sqlite3.connect(DB_PATH)) as source,closing(sqlite3.connect(dest)) as target:source.backup(target)
    return dest
