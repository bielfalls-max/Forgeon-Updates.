"""Product registration independent of listings or image services."""
from datetime import datetime
from uuid import uuid4
from database import db

def create_product(values):
    name=str(values.get('boneco_name','')).strip()
    if not name:raise ValueError('Informe o nome do produto.')
    sku=str(values.get('sku','')).strip()
    numbers={key:float(values.get(key,0) or 0) for key in ('weight_g','print_hours','manual_cost','packaging_cost','other_cost')}
    import math
    if any(not math.isfinite(number) or number<0 for number in numbers.values()):raise ValueError('Custos, peso e horas devem ser números válidos e não negativos.')
    now=datetime.now().isoformat(timespec='seconds')
    with db() as con:
        from services.sku_catalog import check_available,attach,clean
        con.execute('BEGIN IMMEDIATE')
        if sku:
            sku=clean(sku);check_available(con,sku,bool(values.get('reserved_sku')))
        if sku and con.execute('SELECT 1 FROM variants WHERE sku=? OR variant_key=?',(sku,'SKU:'+sku)).fetchone():
            raise ValueError('SKU já cadastrado. Edite o produto existente para manter os vínculos.')
        cursor=con.execute('''INSERT INTO variants(variant_key,sku,main_sku,listing_name,variation_name,boneco_name,
            weight_g,print_hours,manual_cost,packaging_cost,other_cost,notes,active,created_at,updated_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,1,?,?)''',
            ('SKU:'+sku if sku else 'MANUAL:'+uuid4().hex,sku,str(values.get('main_sku','')).strip(),
             str(values.get('listing_name','')).strip() or name,str(values.get('variation_name','')).strip() or name,name,
             *numbers.values(),str(values.get('notes','')).strip(),now,now))
        attach(con,sku,cursor.lastrowid,name)
        return cursor.lastrowid
