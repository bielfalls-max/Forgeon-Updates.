from database import db, get_setting


def _settings_from_con(con):
    return {r["key"]: r["value"] for r in con.execute("SELECT key,value FROM settings").fetchall()}


def variant_unit_cost(r, settings=None):
    s = settings or {}
    if not s:
        with db() as con:
            s = _settings_from_con(con)
    manual = float(r["manual_cost"] or 0)
    if manual > 0:
        return manual
    weight = float(r["weight_g"] or 0)
    hours = float(r["print_hours"] or 0)
    if weight <= 0 or hours <= 0:
        return 0.0
    filament = weight * float(s.get("filament_price_kg", 0)) / 1000
    energy = hours * (float(s.get("printer_power_w", 0)) / 1000) * float(s.get("energy_price_kwh", 0))
    machine = hours * float(s.get("machine_hour_cost", 0))
    labor = float(s.get("labor_cost", 0))
    other = float(r["other_cost"] or 0)
    fail = float(s.get("failure_rate_pct", 0)) / 100
    return (filament + energy + machine + labor + other) * (1 + fail)


def detail_coverage(month_key, start, end, con=None):
    owns = con is None
    if owns:
        ctx = db(); con = ctx.__enter__()
    try:
        r = con.execute(
            """SELECT MIN(COALESCE(substr(paid_at,1,10),substr(created_at,1,10))) mn,
                      MAX(COALESCE(substr(paid_at,1,10),substr(created_at,1,10))) mx,
                      COUNT(*) n
               FROM orders WHERE month_key=?""", (month_key,)
        ).fetchone()
        if not r or not r["n"]:
            return False, None, None
        expected=con.execute('SELECT paid_orders FROM monthly_stats WHERE month_key=?',(month_key,)).fetchone()
        enough=not expected or r['n']>=float(expected['paid_orders'] or 0)
        return (r["mn"] <= start and r["mx"] >= end and enough), r["mn"], r["mx"]
    finally:
        if owns:
            ctx.__exit__(None, None, None)


def month_report(month_key):
    with db() as con:
        st = con.execute("SELECT * FROM monthly_stats WHERE month_key=?", (month_key,)).fetchone()
        if not st:
            return None
        settings = _settings_from_con(con)
        covered, mn, mx = detail_coverage(month_key, st["period_start"], st["period_end"], con)
        if covered:
            fees = con.execute(
                """SELECT COALESCE(SUM(total_platform_fee),0) v FROM orders
                   WHERE month_key=? AND status<>'Cancelado'
                   AND substr(COALESCE(paid_at,created_at),1,10) BETWEEN ? AND ?""",
                (month_key, st["period_start"], st["period_end"])
            ).fetchone()["v"]
        else:
            fees = float(st["paid_sales"] or 0) * float(settings.get("shopee_fee_pct", "30.12")) / 100

        rows = con.execute(
            """SELECT oi.variant_key,oi.quantity,oi.returned_quantity,
                      COALESCE(cv.id,v.id) id,
                      COALESCE(cv.manual_cost,v.manual_cost,0) manual_cost,
                      COALESCE(cv.weight_g,v.weight_g,0) weight_g,
                      COALESCE(cv.print_hours,v.print_hours,0) print_hours,
                      COALESCE(cv.other_cost,v.other_cost,0) other_cost,
                      COALESCE(cv.packaging_cost,v.packaging_cost,0) packaging_cost
               FROM order_items oi
               JOIN orders o ON o.order_id=oi.order_id
               LEFT JOIN variants v ON v.variant_key=oi.variant_key
               LEFT JOIN variant_mappings vm ON vm.source_variant_id=v.id
               LEFT JOIN variants cv ON cv.id=vm.target_variant_id
               WHERE o.month_key=? AND o.status<>'Cancelado'
               AND substr(COALESCE(o.paid_at,o.created_at),1,10) BETWEEN ? AND ?""",
            (month_key, st["period_start"], st["period_end"])
        ).fetchall()

        prod = pack = 0.0
        missing_variants = set()
        for r in rows:
            qty = max(0, float(r["quantity"] or 0) - float(r["returned_quantity"] or 0))
            prod += qty * variant_unit_cost(r, settings)
            pack += qty * float(r["packaging_cost"] or 0)
            if float(r["manual_cost"] or 0) <= 0 and (float(r["weight_g"] or 0) <= 0 or float(r["print_hours"] or 0) <= 0):
                missing_variants.add(r["variant_key"])

        net = float(st["paid_sales"] or 0) - float(fees or 0)
        operational = net - prod - pack
        filament = con.execute(
            "SELECT COALESCE(SUM(rolls*value_per_roll+freight_other),0) v FROM filament_purchases WHERE substr(purchase_date,1,7)=?",
            (month_key,)
        ).fetchone()["v"]
        exps = con.execute(
            "SELECT category,COALESCE(SUM(value),0) v FROM expenses WHERE substr(expense_date,1,7)=? GROUP BY category",
            (month_key,)
        ).fetchall()
        mei = sum(float(x["v"]) for x in exps if x["category"] == "MEI / DAS")
        other = sum(float(x["v"]) for x in exps if x["category"] != "MEI / DAS")
        after = operational - mei - other
        cash = net - float(filament or 0) - mei - other
        return {
            "stats": st, "fees": float(fees or 0), "fee_mode": "real" if covered else "estimada",
            "detail_min": mn, "detail_max": mx, "production": prod, "packaging": pack,
            "operational": operational, "filament": float(filament or 0), "mei": mei, "other": other,
            "after": after, "cash": cash, "missing_costs": len(missing_variants),
            "partial":not covered,
            "detail_orders":con.execute('SELECT COUNT(*) FROM orders WHERE month_key=?',(month_key,)).fetchone()[0],
            "catalog_gap_units":float(st['paid_units'] or 0)-float(con.execute('SELECT COALESCE(SUM(units),0) FROM monthly_stats_products WHERE month_key=?',(month_key,)).fetchone()[0])
        }


def month_reports(month_keys):
    return {m: month_report(m) for m in month_keys}


def top_bonecos(month_key, limit=8):
    with db() as con:
        summary=con.execute("SELECT product_name boneco,units,sales,shopee_item_id FROM monthly_stats_products WHERE month_key=? AND (units>0 OR sales>0) ORDER BY units DESC,sales DESC LIMIT ?",(month_key,limit)).fetchall()
        if summary:return [dict(row,skus=None,variacoes=None,source='resumo mensal') for row in summary]
        return con.execute("""SELECT COALESCE(NULLIF(TRIM(cv.boneco_name),''),NULLIF(TRIM(v.boneco_name),''),oi.variation_name,oi.listing_name) boneco,
            SUM(MAX(0,oi.quantity-oi.returned_quantity)) units,COUNT(DISTINCT oi.variant_key) skus,COUNT(DISTINCT oi.variant_key) variacoes,SUM(oi.subtotal) sales
            FROM order_items oi JOIN orders o ON o.order_id=oi.order_id LEFT JOIN variants v ON v.variant_key=oi.variant_key
            LEFT JOIN variant_mappings vm ON vm.source_variant_id=v.id LEFT JOIN variants cv ON cv.id=vm.target_variant_id
            WHERE o.month_key=? AND o.status<>'Cancelado' GROUP BY boneco ORDER BY units DESC,sales DESC LIMIT ?""",(month_key,limit)).fetchall()


def filament_usage_month_and_fortnight(month_key):
    with db() as con:
        r = con.execute(
            "SELECT MAX(substr(COALESCE(paid_at,created_at),1,10)) dt FROM orders WHERE month_key=? AND status<>'Cancelado'",
            (month_key,)
        ).fetchone()
        last = r["dt"] if r else None
        if not last:
            return {"last_date":None,"fortnight_label":"Sem pedidos","rows":[],"month_kg":0.0,"fortnight_kg":0.0}

        year, month, day = map(int, last.split("-"))
        month_start = f"{year:04d}-{month:02d}-01"
        month_end = f"{year:04d}-{month:02d}-31"
        if day <= 15:
            fort_start, fort_end, label = month_start, f"{year:04d}-{month:02d}-15", "1ª quinzena"
        else:
            fort_start, fort_end, label = f"{year:04d}-{month:02d}-16", month_end, "2ª quinzena"

        rows = con.execute(
            """SELECT vc.color_name,
                      SUM(CASE WHEN substr(COALESCE(o.paid_at,o.created_at),1,10) BETWEEN ? AND ?
                               THEN MAX(0,oi.quantity-oi.returned_quantity)*vc.grams_per_unit ELSE 0 END) month_g,
                      SUM(CASE WHEN substr(COALESCE(o.paid_at,o.created_at),1,10) BETWEEN ? AND ?
                               THEN MAX(0,oi.quantity-oi.returned_quantity)*vc.grams_per_unit ELSE 0 END) fort_g
               FROM order_items oi
               JOIN orders o ON o.order_id=oi.order_id
               JOIN variants v ON v.variant_key=oi.variant_key
               LEFT JOIN variant_mappings vm ON vm.source_variant_id=v.id
               JOIN variant_colors vc ON vc.variant_id=COALESCE(vm.target_variant_id,v.id)
               WHERE o.month_key=? AND o.status<>'Cancelado'
               GROUP BY vc.color_name
               HAVING month_g>0 OR fort_g>0
               ORDER BY month_g DESC""",
            (month_start, month_end, fort_start, fort_end, month_key)
        ).fetchall()

    out = [{
        "color": x["color_name"], "month_g": float(x["month_g"] or 0), "month_kg": float(x["month_g"] or 0)/1000,
        "fortnight_g": float(x["fort_g"] or 0), "fortnight_kg": float(x["fort_g"] or 0)/1000
    } for x in rows]
    return {
        "last_date": last, "fortnight_label": label, "rows": out,
        "month_kg": sum(x["month_g"] for x in out)/1000,
        "fortnight_kg": sum(x["fortnight_g"] for x in out)/1000,
    }


def variant_color_summary(variant_id):
    with db() as con:
        rows = con.execute(
            "SELECT color_name,grams_per_unit FROM variant_colors WHERE variant_id=? ORDER BY slot", (variant_id,)
        ).fetchall()
    return " • ".join(f'{r["color_name"]} {float(r["grams_per_unit"]):g}g' for r in rows)


def actual_orders_preview(month_key):
    with db() as con:
        r = con.execute(
            "SELECT COUNT(*) orders,COALESCE(SUM(order_value),0) value,COALESCE(SUM(total_platform_fee),0) fees FROM orders WHERE month_key=? AND status<>'Cancelado'",
            (month_key,)
        ).fetchone()
        units = con.execute(
            """SELECT COALESCE(SUM(oi.quantity-oi.returned_quantity),0) u FROM order_items oi
               JOIN orders o ON o.order_id=oi.order_id WHERE o.month_key=? AND o.status<>'Cancelado'""", (month_key,)
        ).fetchone()["u"]
    return {"orders":r["orders"],"value":float(r["value"] or 0),"fees":float(r["fees"] or 0),"units":float(units or 0)}
