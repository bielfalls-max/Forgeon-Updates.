"""Read-only ERP exports. XLSX files contain typed numbers and literal text."""
import os,tempfile
from pathlib import Path
from openpyxl import Workbook
from openpyxl.styles import Font,PatternFill
from openpyxl.utils import get_column_letter
from database import db,all_settings
from services.reporting import variant_unit_cost,month_report

KINDS={'products':'Produtos e custos','orders':'Pedidos e itens','finance':'Financeiro','reports':'Relatórios mensais','skus':'Catálogo de SKUs'}

def export_erp(path,kind,month=None):
    if kind not in KINDS:raise ValueError('Escolha um tipo de planilha válido.')
    if month:
        import re
        if not re.fullmatch(r'\d{4}-(0[1-9]|1[0-2])',month):raise ValueError('Mês inválido.')
    book=Workbook();book.remove(book.active)
    def sheet(title,headers,rows,money=(),decimal=()):
        tab=book.create_sheet(title);tab.append(headers)
        for record in rows:
            tab.append(record)
            for cell in tab[tab.max_row]:
                if isinstance(cell.value,str):cell.data_type='s'  # formula-looking SKUs/names remain plain text
                elif isinstance(cell.value,(int,float)):
                    cell.number_format='"R$" #,##0.00' if cell.column in money else '0.00' if cell.column in decimal else '0'
        tab.freeze_panes='A2';tab.auto_filter.ref=tab.dimensions
        for cell in tab[1]:cell.font=Font(bold=True,color='FFFFFF');cell.fill=PatternFill('solid',fgColor='7A1522')
        for index,header in enumerate(headers,1):tab.column_dimensions[get_column_letter(index)].width=min(45,max(16,len(header)+3))
    with db() as con:
        if kind=='products':
            settings=all_settings();rows=con.execute('SELECT * FROM variants WHERE active=1 ORDER BY boneco_name,id').fetchall();out=[]
            fee=float(settings.get('shopee_fee_pct',0))/100;markup=float(settings.get('markup_pct',0))/100
            if not 0<=fee<1:raise ValueError('A taxa da plataforma deve ser menor que 100% para exportar o preço sugerido.')
            for row in rows:
                cost=variant_unit_cost(row,settings);price=(cost+float(row['packaging_cost'] or 0))*(1+markup)/(1-fee)
                out.append([row['id'],row['boneco_name'],row['sku'],row['main_sku'],row['listing_name'],row['variation_name'],row['weight_g'],row['print_hours'],cost,row['packaging_cost'],row['other_cost'],price,row['notes']])
            sheet('Produtos',['ID ERP','Produto','SKU','SKU principal','Nome na origem','Variação','Peso (g)','Horas','Custo usado','Embalagem','Outros custos','Preço sugerido','Observações'],out,money=(9,10,11,12),decimal=(7,8))
            colors=con.execute('''SELECT c.variant_id,v.sku,c.slot,c.color_name,c.grams_per_unit FROM variant_colors c JOIN variants v ON v.id=c.variant_id WHERE v.active=1 ORDER BY c.variant_id,c.slot''').fetchall()
            sheet('Cores e gramas',['ID produto','SKU','Posição','Cor','Gramas por peça'],[list(row) for row in colors],decimal=(5,))
        elif kind=='skus':
            products=con.execute("SELECT id,sku,boneco_name,variation_name FROM variants WHERE active=1 OR (sku IS NOT NULL AND TRIM(sku)<>'') ORDER BY sku,id").fetchall()
            counts={}
            for row in products:
                code=str(row['sku'] or '').strip().casefold()
                if code:counts[code]=counts.get(code,0)+1
            rows=[[row['sku'] or '',row['boneco_name'],row['variation_name'],row['id'],'REPETIDO' if counts.get(str(row['sku'] or '').strip().casefold(),0)>1 else 'Em uso' if row['sku'] else 'Sem SKU'] for row in products]
            rows.extend([[row['sku'],row['product_name'],'',None,'Anterior - não reutilizar' if row['retired'] else 'Reservado'] for row in con.execute('SELECT * FROM sku_registry WHERE variant_id IS NULL ORDER BY sku')])
            sheet('Catálogo SKUs',['SKU','Personagem / produto','Variação','ID produto','Situação'],rows)
        elif kind=='orders':
            where=' WHERE month_key=?' if month else '';params=(month,) if month else ()
            rows=con.execute('SELECT order_id,month_key,status,created_at,paid_at,main_sku,listing_name,order_value,transaction_fee,commission_fee,service_fee,total_platform_fee FROM orders'+where+' ORDER BY month_key,order_id',params).fetchall()
            sheet('Pedidos',['Pedido','Mês','Status','Criado em','Pago em','SKU principal','Nome na origem','Valor pedido','Taxa transação','Comissão','Serviço','Taxas totais'],[list(row) for row in rows],money=(8,9,10,11,12))
            rows=con.execute('''SELECT oi.order_id,oi.line_index,oi.variant_key,oi.sku,oi.listing_name,oi.variation_name,oi.quantity,oi.returned_quantity,oi.original_price,oi.agreed_price,oi.subtotal FROM order_items oi JOIN orders o ON o.order_id=oi.order_id'''+(' WHERE o.month_key=?' if month else '')+' ORDER BY oi.order_id,oi.line_index',params).fetchall()
            sheet('Itens',['Pedido','Linha','Chave produto','SKU','Nome na origem','Variação','Quantidade','Devolvida','Preço original','Preço acordado','Subtotal'],[list(row) for row in rows],money=(9,10,11),decimal=(7,8))
        elif kind=='finance':
            params=(month,) if month else ()
            rows=con.execute('SELECT purchase_date,rolls,value_per_roll,freight_other,notes FROM filament_purchases'+(' WHERE substr(purchase_date,1,7)=?' if month else '')+' ORDER BY purchase_date,id',params).fetchall()
            sheet('Filamentos',['Data','Rolos','Valor por rolo','Frete e outros','Total','Observações'],[[r[0],r[1],r[2],r[3],r[1]*r[2]+r[3],r[4]] for r in rows],money=(3,4,5),decimal=(2,))
            rows=con.execute('SELECT expense_date,category,description,value,notes FROM expenses'+(' WHERE substr(expense_date,1,7)=?' if month else '')+' ORDER BY expense_date,id',params).fetchall()
            sheet('Despesas',['Data','Categoria','Descrição','Valor','Observações'],[list(row) for row in rows],money=(4,))
        else:
            months=[row[0] for row in con.execute('SELECT month_key FROM monthly_stats'+(' WHERE month_key=?' if month else '')+' ORDER BY month_key',(month,) if month else ())]
            rows=[]
            for key in months:
                report=month_report(key);stats=report['stats']
                rows.append([key,stats['period_start'],stats['period_end'],stats['paid_orders'],stats['paid_units'],stats['paid_sales'],report['fees'],report['production'],report['packaging'],report['after'],report['cash'],report['fee_mode'],report['missing_costs'],'PARCIAL - faltam pedidos detalhados' if report['partial'] else 'Conforme pedidos importados'])
            sheet('Resumo mensal',['Mês','Início','Fim','Pedidos pagos','Unidades pagas','Vendas pagas','Taxas','Produção','Embalagens','Resultado','Saldo caixa','Cobertura taxas','Produtos sem custo','Detalhamento dos custos'],rows,money=(6,7,8,9,10,11),decimal=(4,5))
    path=Path(path)
    if path.suffix.lower()!='.xlsx':raise ValueError('Salve com a extensão .xlsx.')
    handle,name=tempfile.mkstemp(prefix='.forgeon-export-',suffix='.xlsx',dir=path.parent);os.close(handle)
    try:book.save(name);os.replace(name,path)
    finally:
        book.close()
        if os.path.exists(name):os.unlink(name)
    return path
