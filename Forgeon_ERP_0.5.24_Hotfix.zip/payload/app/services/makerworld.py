from __future__ import annotations

from dataclasses import dataclass, field
from html import unescape
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urlparse
from urllib.request import Request, urlopen
import json
import re


class MakerWorldError(Exception):
    pass


@dataclass
class MakerWorldResult:
    url: str
    title: str = ""
    description: str = ""
    images: list[str] = field(default_factory=list)
    model_id: str = ""
    profile_id: str = ""
    creator: str = ""
    license: str = ""
    tags: list[str] = field(default_factory=list)


API_BASE = "https://api.bambulab.com/v1/design-service"
_CLIENT_HEADERS = {
    "User-Agent": "ForgeonERP/0.3.0 (+local desktop app)",
    "Accept": "application/json,text/plain,*/*",
    "Accept-Language": "pt-BR,pt;q=0.9,en;q=0.8",
    "Referer": "https://makerworld.com/",
}
_ALLOWED_IMAGE_HOST_SUFFIXES = (".bblmw.com",)
_MODEL_RE = re.compile(r"/models/(\d+)", re.I)
_PROFILE_RE = re.compile(r"profileId[-=](\d+)", re.I)


class _MetaParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.title = ""
        self._in_title = False
        self.metas: list[dict[str, str]] = []

    def handle_starttag(self, tag, attrs):
        if tag.lower() == "title":
            self._in_title = True
        elif tag.lower() == "meta":
            self.metas.append({str(k).lower(): str(v or "") for k, v in attrs})

    def handle_endtag(self, tag):
        if tag.lower() == "title":
            self._in_title = False

    def handle_data(self, data):
        if self._in_title:
            self.title += data


def _strip_html(value: str) -> str:
    text = unescape(value or "")
    text = re.sub(r"<br\s*/?>", "\n", text, flags=re.I)
    text = re.sub(r"</p\s*>", "\n", text, flags=re.I)
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"[ \t\r\f\v]+", " ", text)
    text = re.sub(r"\n\s*\n+", "\n\n", text)
    return text.strip()


def _clean_text(value: str) -> str:
    text = _strip_html(value)
    text = re.sub(r"\s*[-|]\s*MakerWorld(?:\s*[-|].*)?$", "", text, flags=re.I).strip()
    return text


def parse_makerworld_url(url: str) -> tuple[str, str]:
    raw = (url or "").strip()
    if not raw:
        raise MakerWorldError("Cole um link do MakerWorld.")
    if "://" not in raw:
        raw = "https://" + raw
    try:
        parsed = urlparse(raw)
    except Exception as e:
        raise MakerWorldError(f"Link inválido: {e}")
    host = (parsed.hostname or "").lower()
    if host != "makerworld.com" and not host.endswith(".makerworld.com"):
        raise MakerWorldError("O link informado não é do MakerWorld.")
    m = _MODEL_RE.search(parsed.path or "")
    if not m:
        raise MakerWorldError("Não encontrei o ID do modelo no link. Use um link /models/...")
    profile = ""
    pm = _PROFILE_RE.search(parsed.fragment or "") or _PROFILE_RE.search(parsed.query or "")
    if pm:
        profile = pm.group(1)
    return m.group(1), profile


def _request_json(url: str, timeout: int = 25) -> dict:
    req = Request(url, headers=_CLIENT_HEADERS)
    try:
        with urlopen(req, timeout=timeout) as resp:
            raw = resp.read()
    except Exception as e:
        raise MakerWorldError(f"Falha ao consultar os dados públicos do MakerWorld/Bambu Lab: {e}")
    try:
        payload = json.loads(raw.decode("utf-8", errors="replace"))
    except Exception as e:
        raise MakerWorldError(f"A API retornou uma resposta que não é JSON: {e}")
    if not isinstance(payload, dict):
        raise MakerWorldError("A API retornou um formato inesperado.")
    # Alguns endpoints/wrappers usam data/result. O design-service normalmente
    # retorna o objeto diretamente, então só desembrulhamos quando faz sentido.
    for key in ("data", "result"):
        inner = payload.get(key)
        if isinstance(inner, dict) and any(k in inner for k in ("title", "coverUrl", "modelId", "instances", "hits")):
            return inner
    return payload


def _is_image_url(value: str) -> bool:
    if not isinstance(value, str) or not value.startswith(("http://", "https://")):
        return False
    try:
        host = (urlparse(value).hostname or "").lower()
    except Exception:
        return False
    if not (host.endswith(".bblmw.com") or host in {"makerworld.bblmw.com", "public-cdn.bblmw.com"}):
        return False
    low = value.lower().split("#", 1)[0]
    return bool(re.search(r"\.(?:jpe?g|png|webp|gif)(?:\?|$)", low)) or "x-oss-process=" in low


def _extract_images(payload, preferred_profile: str = "") -> list[str]:
    """Design creator's media only. No review/comment media or plate screenshots.

    Design pictures are top-level; some designs also store creator photographs
    in print-profile pictures. Only use the latter when the instance creator
    has an explicitly matching account identity or creator ownership flag.
    """
    if not isinstance(payload, dict):
        return []
    found: list[str] = []
    seen: set[str] = set()

    def add(value):
        if isinstance(value, str):
            url = unescape(value).replace('\\/', '/').replace('\\u0026', '&').strip()
            if _is_image_url(url):
                identity = url.split('?', 1)[0].split('#', 1)[0]
                if identity not in seen:
                    seen.add(identity)
                    found.append(url)
        elif isinstance(value, list):
            for item in value:
                add(item)
        elif isinstance(value, dict):
            for key in ('url', 'imageUrl', 'imageURL', 'imgUrl', 'originUrl',
                        'originalUrl', 'pictureUrl', 'fileUrl', 'src', 'image',
                        'picture', 'coverUrl', 'cover'):
                if key in value:
                    add(value[key])
                    return
            # A gallery entry may nest variants, not unrelated gallery types.
            for key in ('file', 'resource', 'asset', 'original', 'media'):
                if isinstance(value.get(key), dict):
                    add(value[key])
                    return

    cover_keys = ('coverUrl', 'coverLandscape', 'coverPortrait', 'cover')
    gallery_keys = ('images', 'designPictures', 'modelPictures',
                    'creatorPictures', 'pictures', 'gallery', 'imageList',
                    'additionalImages', 'modelImages', 'auxiliaryPictures')

    for key in cover_keys:
        add(payload.get(key))
    for key in gallery_keys:
        add(payload.get(key))

    # Some API wrappers nest exactly the design record one level down.
    for key in ('design', 'model', 'designInfo'):
        design = payload.get(key)
        if isinstance(design, dict) and str(design.get('id') or '') == str(payload.get('id') or ''):
            for gallery_key in gallery_keys:
                add(design.get(gallery_key))

    creator = payload.get('designCreator') or payload.get('creator') or {}
    if isinstance(creator, dict):
        owner_id = str(creator.get('uid') or creator.get('userId') or '').strip()
        owner_handle = str(creator.get('handle') or creator.get('username') or '').strip().lower()
    else:
        owner_id = ''
        owner_handle = str(creator or '').strip().lower()

    def authored_by_design_owner(instance):
        if instance.get('isDesignCreator') is True or instance.get('isOriginalCreator') is True:
            return True
        by = instance.get('instanceCreator') or instance.get('creator') or instance.get('author') or {}
        if isinstance(by, dict):
            uid = str(by.get('uid') or by.get('userId') or '').strip()
            handle = str(by.get('handle') or by.get('username') or '').strip().lower()
        else:
            uid, handle = '', str(by or '').strip().lower()
        return bool((owner_id and uid and owner_id == uid) or
                    (owner_handle and handle and owner_handle == handle))

    instances = payload.get('instances') or []
    if isinstance(instances, dict):
        instances = instances.get('hits') or []
    if isinstance(instances, list):
        owner_instances = [i for i in instances if isinstance(i, dict) and authored_by_design_owner(i)]
        if preferred_profile:
            owner_instances.sort(key=lambda i: 0 if str(i.get('profileId') or i.get('id') or '') == str(preferred_profile) else 1)
        for instance in owner_instances:
            for key in ('pictures', 'images', 'gallery', 'imageList', 'auxiliaryPictures'):
                add(instance.get(key))
            # No instance 'plates' / 'plateImages' / comment pictures.

    return found[:32]


def _extract_creator(payload: dict) -> str:
    for key in ("designCreator", "creator", "user", "author"):
        d = payload.get(key)
        if isinstance(d, dict):
            for name_key in ("handle", "name", "nickname", "username"):
                val = d.get(name_key)
                if val:
                    return _clean_text(str(val))
        elif isinstance(d, str) and d.strip():
            return _clean_text(d)
    return ""


def _extract_tags(payload: dict) -> list[str]:
    raw = payload.get("tags") or payload.get("tagList") or []
    if isinstance(raw, str):
        return [x.strip() for x in re.split(r"[,;]", raw) if x.strip()][:20]
    out = []
    if isinstance(raw, list):
        for x in raw:
            if isinstance(x, str):
                val = x
            elif isinstance(x, dict):
                val = x.get("name") or x.get("title") or x.get("tagName") or ""
            else:
                val = ""
            val = _clean_text(str(val))
            if val and val not in out:
                out.append(val)
    return out[:20]


def _parse_api_payload(payload: dict, url: str, model_id: str, profile_id: str, extra_payload: dict | None = None) -> MakerWorldResult:
    merged = payload
    title = _clean_text(str(payload.get("title") or payload.get("name") or ""))
    desc = _clean_text(str(payload.get("summary") or payload.get("description") or payload.get("desc") or ""))
    creator = _extract_creator(payload)
    license_name = _clean_text(str(payload.get("license") or payload.get("licenseName") or payload.get("licenseType") or ""))
    tags = _extract_tags(payload)
    images = _extract_images(payload, profile_id)
    # Deliberately ignore instance/profile pictures and reviews. They are not
    # verified as the model author's primary gallery images.
    return MakerWorldResult(
        url=url,
        title=title,
        description=desc,
        images=images[:32],
        model_id=str(payload.get("id") or model_id),
        profile_id=profile_id,
        creator=creator,
        license=license_name,
        tags=tags,
    )


def parse_makerworld_html(html: str, url: str = "") -> MakerWorldResult:
    parser = _MetaParser()
    try:
        parser.feed(html)
    except Exception:
        pass
    meta = {}
    for m in parser.metas:
        key = (m.get("property") or m.get("name") or "").lower().strip()
        content = m.get("content", "")
        if key and content and key not in meta:
            meta[key] = content
    title = _clean_text(meta.get("og:title") or meta.get("twitter:title") or parser.title)
    description = _clean_text(meta.get("og:description") or meta.get("description") or meta.get("twitter:description"))
    candidates = [meta.get(k, "") for k in ("og:image", "og:image:url", "twitter:image", "twitter:image:src")]
    # HTML fallback deliberately uses only authored OpenGraph/Twitter media.
    # Scraping all embedded CDN URLs would reintroduce user reviews/screenshots.
    images = []
    for raw in candidates:
        u = unescape(raw or "").replace("\\/", "/").replace("\\u0026", "&")
        if _is_image_url(u) and u not in images:
            images.append(u)
    try:
        model_id, profile_id = parse_makerworld_url(url)
    except MakerWorldError:
        model_id, profile_id = "", ""
    return MakerWorldResult(url=url, title=title, description=description, images=images[:12], model_id=model_id, profile_id=profile_id)


def fetch_makerworld(url: str, timeout: int = 25) -> MakerWorldResult:
    model_id, profile_id = parse_makerworld_url(url)
    # Prefer the anonymous Bambu design-service endpoint. It is far more stable
    # than scraping the Cloudflare-protected MakerWorld page and returns the
    # public model metadata plus image CDN URLs.
    api_error = None
    try:
        design = _request_json(f"{API_BASE}/design/{model_id}", timeout)
        result = _parse_api_payload(design, url, model_id, profile_id)
        if result.title or result.images:
            return result
        api_error = "a API respondeu sem título/imagens"
    except MakerWorldError as e:
        api_error = str(e)

    # Fallback: some user networks may allow the regular page even when the API
    # is temporarily unavailable.
    req = Request(url, headers={
        "User-Agent": _CLIENT_HEADERS["User-Agent"],
        "Accept": "text/html,application/xhtml+xml,*/*;q=0.8",
        "Accept-Language": _CLIENT_HEADERS["Accept-Language"],
    })
    try:
        with urlopen(req, timeout=timeout) as resp:
            raw = resp.read()
            charset = resp.headers.get_content_charset() or "utf-8"
            html = raw.decode(charset, errors="replace")
        result = parse_makerworld_html(html, url)
        if result.title or result.images:
            return result
    except Exception as e:
        raise MakerWorldError(
            "Não consegui analisar o link automaticamente. "
            f"API: {api_error or 'indisponível'} | Página: {e}"
        )
    raise MakerWorldError(f"O MakerWorld não retornou dados utilizáveis. Detalhe: {api_error or 'sem dados'}")


def download_image(url: str, destination: str | Path, timeout: int = 30) -> Path:
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    try:
        host = (urlparse(url).hostname or "").lower()
    except Exception:
        host = ""
    if not (host.endswith(".bblmw.com") or host in {"makerworld.bblmw.com", "public-cdn.bblmw.com"}):
        raise MakerWorldError(f"Por segurança, o ERP recusou baixar imagem de um host inesperado: {host or 'desconhecido'}")
    req = Request(url, headers={
        "User-Agent": _CLIENT_HEADERS["User-Agent"],
        "Referer": "https://makerworld.com/",
        "Accept": "image/avif,image/webp,image/apng,image/*,*/*;q=0.8",
    })
    try:
        with urlopen(req, timeout=timeout) as resp:
            data = resp.read(20 * 1024 * 1024 + 1)
            content_type = (resp.headers.get("Content-Type") or "").lower()
    except Exception as e:
        raise MakerWorldError(f"Falha ao baixar imagem: {e}")
    if len(data) > 20 * 1024 * 1024:
        raise MakerWorldError("A imagem excede o limite de 20 MB.")
    if len(data) < 256:
        raise MakerWorldError("A imagem retornada está vazia ou inválida.")
    if not content_type.startswith("image/") and not _is_image_url(url):
        raise MakerWorldError("O endereço retornado não parece ser uma imagem.")
    destination.write_bytes(data)
    return destination
