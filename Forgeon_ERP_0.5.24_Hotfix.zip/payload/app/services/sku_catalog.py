"""Persistent SKU reservations and explicit corrections; no automatic merging."""
from datetime import datetime
import sqlite3
from database import db

def clean(code):
    code=str(code or '').strip()
    if not code or len(code)>64 or any(ord(ch)<32 for ch in code):raise ValueError('Informe um SKU de 1 a 64 caracteres válidos.')
    return code

def sync_existing(con):
    now=datetime.now().isoformat(timespec='seconds')
    for row in con.execute("SELECT id,sku,boneco_name,listing_name FROM variants WHERE sku IS NOT NULL AND TRIM(sku)<>'' ORDER BY id").fetchall():
        sku=row['sku'].strip();name=row['boneco_name'] or row['listing_name'] or ''
        con.execute('INSERT OR IGNORE INTO sku_registry(sku,product_name,variant_id,created_at) VALUES(?,?,?,?)',(sku,name,row['id'],now))
        current=con.execute('SELECT variant_id FROM sku_registry WHERE sku=?',(sku,)).fetchone()
        if current and (current['variant_id'] is None or not con.execute('SELECT 1 FROM variants WHERE id=? AND sku=? COLLATE NOCASE',(current['variant_id'],sku)).fetchone()):
            con.execute('UPDATE sku_registry SET variant_id=?,retired=0 WHERE sku=?',(row['id'],sku))

def check_available(con,sku,allow_reserved=False,exclude=None):
    row=con.execute('SELECT id FROM variants WHERE sku=? COLLATE NOCASE AND id<>?',(sku,exclude or -1)).fetchone()
    if row:raise ValueError('SKU já usado em outro produto. Escolha um código livre.')
    reserved=con.execute('SELECT * FROM sku_registry WHERE sku=?',(sku,)).fetchone()
    if reserved and (exclude is None or reserved['variant_id']!=exclude) and not(allow_reserved and reserved['variant_id'] is None and not reserved['retired']):raise ValueError('SKU já reservado. Use Escolher SKU reservado para utilizá-lo conscientemente.')

def reserve(code,name=''):
    code=clean(code)
    with db() as con:
        con.execute('BEGIN IMMEDIATE');sync_existing(con);check_available(con,code)
        con.execute('INSERT INTO sku_registry(sku,product_name,created_at) VALUES(?,?,?)',(code,str(name).strip(),datetime.now().isoformat(timespec='seconds')))
    return code

def reserve_next(name='',width=6):
    with db() as con:
        con.execute('BEGIN IMMEDIATE');sync_existing(con)
        numbers=[int(row[0]) for row in con.execute('SELECT sku FROM sku_registry') if str(row[0]).isdigit() and len(str(row[0]))<=15]
        number=max(numbers,default=0)+1;code=str(number).zfill(width)
        while con.execute('SELECT 1 FROM sku_registry WHERE sku=?',(code,)).fetchone():number+=1;code=str(number).zfill(width)
        con.execute('INSERT INTO sku_registry(sku,product_name,created_at) VALUES(?,?,?)',(code,str(name).strip(),datetime.now().isoformat(timespec='seconds')))
        return code

def reservations():
    with db() as con:
        sync_existing(con)
        return [dict(row) for row in con.execute('SELECT * FROM sku_registry WHERE variant_id IS NULL AND retired=0 ORDER BY sku')]

def attach(con,sku,vid,name):
    if not sku:return
    now=datetime.now().isoformat(timespec='seconds')
    con.execute('''INSERT INTO sku_registry(sku,product_name,variant_id,created_at) VALUES(?,?,?,?)
        ON CONFLICT(sku) DO UPDATE SET variant_id=excluded.variant_id,product_name=excluded.product_name,retired=0''',(sku,name,vid,now))

def correct(vid,new_sku):
    new_sku=clean(new_sku)
    with db() as con:
        con.execute('BEGIN IMMEDIATE');sync_existing(con)
        row=con.execute('SELECT * FROM variants WHERE id=?',(vid,)).fetchone()
        if row is None:raise ValueError('Selecione um produto existente.')
        if str(row['sku'] or '')==new_sku:return
        check_available(con,new_sku,allow_reserved=True,exclude=vid)
        key='SKU:'+new_sku
        if con.execute('SELECT 1 FROM variants WHERE variant_key=? AND id<>?',(key,vid)).fetchone():
            from uuid import uuid4
            key+='|CAD:'+uuid4().hex[:12]
        # Historical original SKU remains in order_items.sku for auditing.
        con.execute('UPDATE order_items SET variant_key=? WHERE variant_key=?',(key,row['variant_key']))
        con.execute('UPDATE variants SET sku=?,variant_key=?,updated_at=? WHERE id=?',(new_sku,key,datetime.now().isoformat(timespec='seconds'),vid))
        con.execute('UPDATE sku_registry SET variant_id=NULL,retired=1 WHERE variant_id=?',(vid,))
        attach(con,new_sku,vid,row['boneco_name'] or row['listing_name']);sync_existing(con)
