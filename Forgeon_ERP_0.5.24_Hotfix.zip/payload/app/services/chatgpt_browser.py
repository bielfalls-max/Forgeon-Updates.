"""Settings for a single, explicitly selected ChatGPT conversation."""
import json, os, re
from pathlib import Path
from urllib.parse import urlsplit

def conversation_url(value):
    url=urlsplit(value.strip())
    if (url.scheme!='https' or url.netloc!='chatgpt.com' or url.query or url.fragment
        or not re.fullmatch(r'/(?:c|local)/[A-Za-z0-9-]+/?',url.path)):
        raise ValueError('Abra a conversa Fotos no Opera GX e copie o endereco https://chatgpt.com/c/... ou https://chatgpt.com/local/... da barra. Links compartilhados ou a pagina inicial nao servem.')
    return 'https://chatgpt.com'+url.path.rstrip('/')

def load(root):
    path=Path(root)/'arquivos/chatgpt-browser/settings.json'
    return conversation_url(json.loads(path.read_text(encoding='utf-8'))['conversation_url'])

def save(root,url):
    url=conversation_url(url)
    path=Path(root)/'arquivos/chatgpt-browser/settings.json';path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_suffix('.tmp');temp.write_text(json.dumps({'conversation_url':url}),encoding='utf-8');os.replace(temp,path)
    return url

def save_executable(root,path):
    path=Path(path).resolve()
    if path.name.lower() not in ('launcher.exe','opera.exe') or not path.is_file():
        raise ValueError('Selecione launcher.exe ou opera.exe da instalacao do Opera GX.')
    target=Path(root)/'arquivos/chatgpt-browser/opera_path.json';target.parent.mkdir(parents=True,exist_ok=True)
    temp=target.with_suffix('.tmp');temp.write_text(json.dumps({'executable':str(path)}),encoding='utf-8');os.replace(temp,target)

def find_opera_gx(root,environ=None):
    """Only GX installations; never silently fall back to Chrome or regular Opera."""
    env=os.environ if environ is None else environ
    try:
        chosen=Path(json.loads((Path(root)/'arquivos/chatgpt-browser/opera_path.json').read_text(encoding='utf-8'))['executable'])
        if chosen.is_absolute() and chosen.name.lower() in ('launcher.exe','opera.exe') and chosen.is_file():return chosen
    except (OSError,ValueError,KeyError,TypeError):pass
    folders=[]
    if env.get('LOCALAPPDATA'):folders.append(Path(env['LOCALAPPDATA'])/'Programs/Opera GX')
    for key in ('PROGRAMFILES','PROGRAMFILES(X86)'):
        if env.get(key):folders.append(Path(env[key])/'Opera GX')
    for folder in folders:
        for name in ('launcher.exe','opera.exe'):
            if (folder/name).is_file():return folder/name
    return None
