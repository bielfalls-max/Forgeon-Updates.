"""Local bridge settings. Secrets are generated on the user's computer, never shipped."""
import hashlib,json,os,secrets
from pathlib import Path
from urllib.parse import urlsplit

def public_origin(value):
    u=urlsplit(str(value).strip())
    if u.scheme!='https' or not u.hostname or u.username or u.password or u.query or u.fragment or u.path not in ('','/') or u.port not in (None,443):
        raise ValueError('Use a origem HTTPS publica, por exemplo https://forgeon.seudominio.com, sem caminho ou senha.')
    if u.hostname in ('localhost','127.0.0.1','::1'):raise ValueError('O endereco publico nao pode ser localhost.')
    return 'https://'+u.hostname.encode('idna').decode('ascii').lower()

def save_settings(root,url):
    url=public_origin(url);folder=Path(root)/'arquivos/mcp';folder.mkdir(parents=True,exist_ok=True)
    secret=folder/'access.key'
    if not secret.exists():
        fd=os.open(secret,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(fd,'w',encoding='utf-8') as out:out.write(secrets.token_urlsafe(24))
    config={'public_url':url,'port':8765,'access_hash':hashlib.sha256(secret.read_bytes()).hexdigest()}
    path=folder/'bridge.json';tmp=folder/'bridge.json.tmp'
    tmp.write_text(json.dumps(config,indent=2),encoding='utf-8');os.replace(tmp,path)
    return config

def load_settings(root):
    config=json.loads((Path(root)/'arquivos/mcp/bridge.json').read_text(encoding='utf-8'))
    config['public_url']=public_origin(config['public_url'])
    if config.get('port')!=8765 or len(config.get('access_hash',''))!=64:raise ValueError('Configuracao da ponte invalida')
    return config
