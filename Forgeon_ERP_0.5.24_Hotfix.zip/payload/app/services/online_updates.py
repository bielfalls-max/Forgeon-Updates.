"""Updates from Forgeon's fixed GitHub channel; never writes user data."""
import hashlib
import json
import re
import shutil
import stat
import tempfile
import urllib.request
import urllib.error
import zipfile
from pathlib import Path, PurePosixPath

PREFIX = 'https://raw.githubusercontent.com/bielfalls-max/Forgeon-Updates./'
FEED = PREFIX + 'main/latest.json'
MAX_PACKAGE = 32 * 1024 * 1024


def version(value):
    if not isinstance(value, str) or not re.fullmatch(r'\d+\.\d+\.\d+', value):
        raise ValueError('Versão de atualização inválida.')
    return tuple(map(int, value.split('.')))


def download(url, limit):
    if not url.startswith(PREFIX) or '?' in url or '#' in url:
        raise ValueError('Origem da atualização inválida.')
    request = urllib.request.Request(url, headers={'User-Agent': 'Forgeon-Updater'})
    with urllib.request.urlopen(request, timeout=20) as response:
        if not response.url.startswith(PREFIX):
            raise ValueError('Redirecionamento de atualização inválido.')
        raw = response.read(limit + 1)
    if len(raw) > limit:
        raise ValueError('Atualização excede o tamanho permitido.')
    return raw


def check(current):
    try:
        info = json.loads(download(FEED, 65536))
    except urllib.error.HTTPError as exc:
        if exc.code == 404:
            raise ValueError('Canal de atualizações inacessível sem login. Repositórios privados exigem uma distribuição autorizada; baixar pelo navegador não libera o acesso do ERP.') from exc
        raise
    target = version(info['version'])
    if target <= version(current):
        return None
    if current not in info['from_versions']:
        raise ValueError('Esta versão precisa de atualização manual antes da atualização online.')
    if not re.fullmatch(r'[a-f0-9]{64}', info['sha256']):
        raise ValueError('Verificação de integridade inválida.')
    if not info['url'].startswith(PREFIX):
        raise ValueError('Origem da atualização inválida.')
    return info


def stage(info):
    raw = download(info['url'], MAX_PACKAGE)
    if hashlib.sha256(raw).hexdigest() != info['sha256']:
        raise ValueError('Download corrompido. Nenhum arquivo do ERP foi alterado.')
    root = Path(tempfile.mkdtemp(prefix='forgeon-update-'))
    try:
        archive = root / 'update.zip'
        archive.write_bytes(raw)
        package = root / 'package'
        package.mkdir()
        with zipfile.ZipFile(archive) as z:
            entries = z.infolist()
            names = [e.filename.casefold() for e in entries]
            if len(names) != len(set(names)) or sum(e.file_size for e in entries) > 128 * 1024 * 1024:
                raise ValueError('Pacote de atualização inválido.')
            for entry in entries:
                name = entry.filename
                p = PurePosixPath(name)
                if (p.is_absolute() or '..' in p.parts or '\\' in name or ':' in name
                        or stat.S_ISLNK(entry.external_attr >> 16)):
                    raise ValueError('Caminho inválido no pacote.')
            z.extractall(package)
        manifest = json.loads((package / 'manifest.json').read_text(encoding='utf-8'))
        if manifest['version'] != info['version'] or manifest['kind'] != 'hotfix':
            raise ValueError('Versão do pacote não corresponde ao canal.')
        if not (package / 'deploy.py').is_file():
            raise ValueError('Instalador ausente.')
        return package
    except BaseException:
        shutil.rmtree(root)
        raise
