"""Optional integrations. No background downloads, no hidden code execution."""
import json
import socket
import uuid
from urllib.request import Request, urlopen
from urllib.error import HTTPError

ARTCRAFT_BASE = 'https://api.storyteller.ai'

def vectorcraft_inspect(port=7979, timeout=3):
    port = int(port)
    if not 1 <= port <= 65535:
        raise ValueError('Porta inválida')
    request = {'id': 1, 'method': 'ui.inspect', 'params': {}}
    with socket.create_connection(('127.0.0.1', port), timeout=timeout) as conn:
        conn.settimeout(timeout)
        conn.sendall((json.dumps(request)+'\n').encode())
        data = bytearray()
        while len(data) < 2_000_000:
            chunk = conn.recv(8192)
            if not chunk: break
            data.extend(chunk)
            if b'\n' in chunk: break
    if not data:
        raise ConnectionError('VectorCraft não respondeu')
    return json.loads(bytes(data).split(b'\n',1)[0])

def artcraft_submit_video(api_key, prompt, image_url, model='seedance_2p0', duration=6):
    if not api_key.startswith('artcraft_api_'):
        raise ValueError('Chave ArtCraft inválida ou não informada')
    if not image_url.startswith('https://'):
        raise ValueError('A imagem precisa ter URL pública HTTPS')
    payload = {'model':model, 'prompt':prompt, 'duration_seconds':int(duration),
               'aspect_ratio':'square', 'idempotency_token':str(uuid.uuid4()),
               'start_frame_image_url':image_url}
    req = Request(ARTCRAFT_BASE+'/v1/omni_api/generate/video',
                  data=json.dumps(payload).encode(),
                  headers={'Authorization':'Bearer '+api_key,'Content-Type':'application/json'},method='POST')
    try:
        with urlopen(req, timeout=60) as resp:
            return json.loads(resp.read())
    except HTTPError as exc:
        raise RuntimeError('ArtCraft HTTP '+str(exc.code)+': '+exc.read(400).decode(errors='replace')) from exc

def artcraft_job_status(api_key, token):
    if not api_key.startswith('artcraft_api_') or not token.startswith('jinf_'):
        raise ValueError('Chave ou token inválido')
    req=Request(ARTCRAFT_BASE+'/v1/omni_api/job_status/job/'+token,
                headers={'Authorization':'Bearer '+api_key})
    with urlopen(req, timeout=30) as resp:
        return json.loads(resp.read())

# --- CS3: controle local seguro do VectorCraft ---

def vectorcraft_request(method, params=None, port=7979, timeout=15):
    """Envia uma operacao de controle local documentada, sem avaliar codigo remoto."""
    allowed = {'ui.inspect', 'app.open', 'app.export', 'document.inspect'}
    if method not in allowed:
        raise ValueError('Comando nao autorizado: '+str(method))
    port = int(port)
    if not 1 <= port <= 65535:
        raise ValueError('Porta fora do intervalo valido')
    request = {'id': 1, 'method': method, 'params': params or {}}
    data = bytearray()
    with socket.create_connection(('127.0.0.1', port), timeout=timeout) as conn:
        conn.settimeout(timeout)
        conn.sendall((json.dumps(request, ensure_ascii=False)+'\n').encode('utf-8'))
        while len(data) < 2_000_000:
            chunk = conn.recv(8192)
            if not chunk:
                break
            data.extend(chunk)
            if b'\n' in data:
                break
    if not data:
        raise ConnectionError('VectorCraft nao respondeu na porta '+str(port))
    if b'\n' not in data and len(data) >= 2_000_000:
        raise RuntimeError('Resposta do VectorCraft grande demais')
    reply = json.loads(bytes(data).split(b'\n', 1)[0].decode('utf-8'))
    if not isinstance(reply, dict) or reply.get('ok') is not True:
        raise RuntimeError('VectorCraft recusou a operacao: '+str(reply.get('error', reply)))
    return reply.get('result')


def vectorcraft_open(path, port=7979):
    from pathlib import Path
    p = Path(path).resolve(strict=True)
    if not p.is_file():
        raise ValueError('Arquivo inexistente')
    return vectorcraft_request('app.open', {'path':str(p)}, port, timeout=45)


def vectorcraft_export(path, fmt, port=7979):
    from pathlib import Path
    fmt = fmt.lower()
    if fmt not in {'png', 'svg'}:
        raise ValueError('Formato de exportacao nao permitido')
    p = Path(path).resolve()
    p.parent.mkdir(parents=True, exist_ok=True)
    if p.suffix.lower() != '.'+fmt:
        raise ValueError('Extensao nao corresponde ao formato')
    return vectorcraft_request('app.export', {'path':str(p), 'format':fmt}, port, timeout=60)
