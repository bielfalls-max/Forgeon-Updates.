"""Prepare user-edited images without segmentation or generative processing."""
from pathlib import Path
from io import BytesIO
from PIL import Image, ImageOps
import hashlib


def prepare_ready_photo(source, destination, max_bytes=1_900_000, canvas_size=1600):
    source,destination=Path(source),Path(destination)
    if max_bytes<=0 or canvas_size<=0:raise ValueError('Limites de imagem invalidos')
    with Image.open(source) as opened:
        opened.load()
        img=ImageOps.exif_transpose(opened).convert('RGBA')
    # Keep the entire frame, including GPT-generated scenery. Flatten only transparency.
    img.thumbnail((canvas_size,canvas_size),Image.Resampling.LANCZOS)
    canvas=Image.new('RGB',(canvas_size,canvas_size),'white')
    canvas.paste(img,((canvas_size-img.width)//2,(canvas_size-img.height)//2),img)
    encoded=None
    for quality in (94,90,86,82,78,74,68,60):
        buffer=BytesIO();canvas.save(buffer,'JPEG',quality=quality,optimize=True)
        if buffer.tell()<=max_bytes:
            encoded=buffer.getvalue();break
    if encoded is None:raise ValueError('A imagem excede o limite de tamanho configurado mesmo apos compressao.')
    destination.parent.mkdir(parents=True,exist_ok=True)
    destination.write_bytes(encoded)
    return {'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
            'status':'PRONTA','method':'importada/sem-recorte',
            'diagnostic':'Foto pronta importada: apenas orientacao, ajuste ao quadro e compressao. Sem IA ou remocao de fundo.'}
