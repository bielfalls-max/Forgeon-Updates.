"""Non-destructive product presentation: listings/SKUs remain independent."""
import re
import unicodedata

def identity(value):
    value=unicodedata.normalize('NFKD',str(value or '')).encode('ascii','ignore').decode().casefold()
    value=re.sub(r'\s*[-–—]\s*hedgehog\s*$', '',value)
    parts=[re.sub(r'[^a-z0-9]+',' ',p).strip() for p in value.split(',')]
    if len(set(parts))==1:return parts[0]
    return ' '.join(parts).strip()

def group_products(rows, colors):
    groups={}
    for raw in rows:
        r=dict(raw)
        # Names, never SKU alone: a wrongly reused SKU must not merge Sonic and Super Sonic.
        key=identity(r['boneco_name'] or r['variation_name'] or r['listing_name'])
        groups.setdefault(key or 'id:'+str(r['id']),[]).append(r)
    result=[]
    for key,members in groups.items():
        def score(r):
            return (bool(colors.get(r['id'])),float(r['manual_cost'] or 0)>0,
                    float(r['weight_g'] or 0)>0,float(r['print_hours'] or 0)>0,-r['id'])
        representative=max(members,key=score)
        result.append((representative,members))
    return result
