"""Loopback pairing/client for the extension in the user's existing browser."""
import json,os,secrets,subprocess,sys,time
from pathlib import Path
from urllib.request import Request,build_opener,ProxyHandler

def config(root,create=True):
    path=Path(root)/'arquivos/chatgpt-browser/extension.json'
    if not path.exists():
        if not create:raise FileNotFoundError(path)
        path.parent.mkdir(parents=True,exist_ok=True)
        data={'port':8766,'token':secrets.token_urlsafe(32)}
        try:
            fd=os.open(path,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
            with os.fdopen(fd,'w',encoding='utf-8') as file:json.dump(data,file)
        except FileExistsError:pass
    result=json.loads(path.read_text(encoding='utf-8'))
    if not 1024<=int(result['port'])<=65535 or len(result['token'])<32:raise ValueError('Configuracao local invalida')
    return result

def request(root,path,data=None,timeout=2):
    cfg=config(root);payload=json.dumps(data).encode() if data is not None else None
    req=Request(f"http://127.0.0.1:{cfg['port']}"+path,data=payload,headers={'Authorization':'Bearer '+cfg['token'],'Content-Type':'application/json'})
    with build_opener(ProxyHandler({})).open(req,timeout=timeout) as response:return json.load(response)

def ensure(root):
    cfg=config(root)
    try:
        result=request(root,'/health')
        if result.get('service')=='forgeon-photo-extension-2':return
        if result.get('service')=='forgeon-photo-extension-1':
            request(root,'/shutdown',{});time.sleep(.2)
    except (OSError,ValueError):pass
    script=Path(root)/'app/integrations/photo_extension_bridge.py'
    proc=subprocess.Popen([sys.executable,str(script),'--root',str(root)],cwd=str(root),stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    deadline=time.monotonic()+4
    while time.monotonic()<deadline:
        try:
            if request(root,'/health',timeout=.3).get('service')=='forgeon-photo-extension-2':return
        except (OSError,ValueError):pass
        if proc.poll() is not None:break
        time.sleep(.1)
    raise RuntimeError(f"Nao foi possivel iniciar a ponte local na porta {cfg['port']}. Nenhuma janela do navegador foi aberta.")

def pairing(root):
    ensure(root);cfg=config(root)
    return json.dumps({'url':f"http://127.0.0.1:{cfg['port']}",'token':cfg['token']})

def stop(root):
    try:
        config(root,False);request(root,'/shutdown',{},timeout=.5)
    except (OSError,ValueError):pass
