"""Local photo handoff shared by the desktop ERP and an optional MCP client.
Preparing a job NEVER sends a message or uploads files to ChatGPT.
"""
import base64,hashlib,json,os,uuid
from io import BytesIO
from pathlib import Path
from PIL import Image

PROMPT=Path(__file__).resolve().parents[1]/'prompts/photo_standard.md'
MAX_IMAGE_BYTES=1_900_000

class PhotoJobs:
    def __init__(self,root):
        self.root=Path(root).resolve();self.root.mkdir(parents=True,exist_ok=True)

    def folder(self,job_id):
        if not isinstance(job_id,str) or len(job_id)!=32 or any(c not in '0123456789abcdef' for c in job_id):raise ValueError('Identificador invalido')
        path=(self.root/job_id).resolve()
        if path.parent!=self.root:raise ValueError('Tarefa fora da pasta autorizada')
        return path

    def inside(self,folder,name):
        path=(folder/name).resolve()
        if not path.is_relative_to(folder):raise ValueError('Arquivo fora da tarefa')
        return path

    def create(self,paths,height_cm):
        paths=[Path(p) for p in paths]
        height=float(height_cm)
        if not 0<height<=1000:raise ValueError('Informe a altura total em centimetros')
        if not 1<=len(paths)<=9:raise ValueError('Selecione de 1 a 9 fotos')
        # Verify all sources before creating a job, preserving their bytes.
        sources=[]
        for path in paths:
            if path.stat().st_size>25_000_000:raise ValueError('Cada original deve ter ate 25 MB')
            data=path.read_bytes()
            with Image.open(BytesIO(data)) as im:
                fmt=im.format
                if fmt not in ('JPEG','PNG','WEBP'):raise ValueError('Use JPG, PNG ou WebP')
                im.verify()
            sources.append((data,{'JPEG':'.jpg','PNG':'.png','WEBP':'.webp'}[fmt]))
        job_id=uuid.uuid4().hex;folder=self.folder(job_id);(folder/'originais').mkdir(parents=True)
        manifest={'id':job_id,'height_cm':height,'input_count':len(paths),'output_count':min(9,len(paths)+3),'state':'AGUARDANDO_ENVIO','images':[]}
        for i,(data,extension) in enumerate(sources,1):
            name=f'originais/{i:02d}{extension}';(folder/name).write_bytes(data)
            manifest['images'].append({'slot':i,'file':name,'sha256':hashlib.sha256(data).hexdigest()})
        (folder/'prompt.txt').write_text(PROMPT.read_text(encoding='utf-8').replace('{height_cm}',f'{height:g}'),encoding='utf-8')
        (folder/'job.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
        return self.get(job_id)

    def get(self,job_id):
        folder=self.folder(job_id)
        data=json.loads((folder/'job.json').read_text(encoding='utf-8'))
        # Do not trust paths or IDs in a modified on-disk manifest.
        if data.get('id')!=job_id:raise ValueError('Identificador inconsistente')
        if not 1<=int(data['output_count'])<=9:raise ValueError('Quantidade invalida')
        data['results']=[i for i in range(1,data['output_count']+1) if self.inside(folder,f'resultados/{i:02d}.jpg').is_file()]
        data['state']='CONCLUIDO' if len(data['results'])==data['output_count'] else 'RESULTADO_PARCIAL' if data['results'] else 'AGUARDANDO_ENVIO'
        data['prompt']=self.inside(folder,'prompt.txt').read_text(encoding='utf-8')
        data['notice']='Tarefa local. Envio ao ChatGPT ainda nao confirmado. Geracao depende do ChatGPT; resultados precisam ser recebidos separadamente.'
        delivery=folder/'browser-send.json'
        if delivery.is_file():
            try:
                record=json.loads(delivery.read_text(encoding='utf-8'))
                data['browser_send']={key:str(record.get(key,''))[:1200] for key in ('state','message')}
                if record.get('state')=='ENVIADO':data['notice']='Prompt e fotos enviados ao ChatGPT. Edicao e recebimento dos resultados ainda dependem do ChatGPT.'
            except (OSError,ValueError):pass
        return data

    def list(self):
        jobs=[]
        for path in sorted(self.root.iterdir(),key=lambda p:p.stat().st_mtime,reverse=True):
            if path.is_dir() and (path/'job.json').exists():
                try:
                    job=self.get(path.name);jobs.append({k:job[k] for k in ('id','state','input_count','output_count','results')})
                except (ValueError,OSError,KeyError):continue
        return jobs[:100]

    def image(self,job_id,slot):
        job=self.get(job_id)
        entry=next((x for x in job['images'] if x['slot']==slot),None)
        if entry is None:raise ValueError('Foto nao encontrada')
        path=self.inside(self.folder(job_id),entry['file'])
        data=path.read_bytes()
        if hashlib.sha256(data).hexdigest()!=entry['sha256']:raise ValueError('Foto original alterada')
        if len(data)>1_900_000:raise ValueError('Original acima de 1,9 MB para retorno pelo MCP; reduza o arquivo antes de criar a tarefa ou use o envio manual.')
        return path

    def save_result(self,job_id,slot,encoded):
        job=self.get(job_id);slot=int(slot)
        if not 1<=slot<=job['output_count']:raise ValueError('Posicao fora da tarefa')
        if len(encoded)>2_540_000:raise ValueError('Resultado excede 1,9 MB')
        data=base64.b64decode(encoded,validate=True)
        if len(data)>MAX_IMAGE_BYTES:raise ValueError('Resultado excede 1,9 MB')
        with Image.open(BytesIO(data)) as im:
            if im.format!='JPEG' or im.width!=im.height:raise ValueError('Resultado deve ser JPG quadrado')
            im.verify()
        folder=self.folder(job_id);dest=self.inside(folder,f'resultados/{slot:02d}.jpg');dest.parent.mkdir(parents=True,exist_ok=True)
        if dest.exists():
            if dest.read_bytes()!=data:raise ValueError('Posicao ja tem resultado; nao sera sobrescrito')
        else:
            with dest.open('xb') as out:out.write(data)
        return self.get(job_id)
