"""Standalone helper copied outside the installation before ERP exits."""
import ctypes
import os
from pathlib import Path
import subprocess
import sys
import time


def wait_parent(pid):
    if os.name == 'nt':
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel.OpenProcess.restype = ctypes.c_void_p
        handle = kernel.OpenProcess(0x100000, False, pid)
        if handle:
            try:
                kernel.WaitForSingleObject.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
                if kernel.WaitForSingleObject(handle, 120000) != 0:
                    raise RuntimeError('ERP ainda aberto. Atualização cancelada.')
            finally:
                kernel.CloseHandle.argtypes = [ctypes.c_void_p]
                kernel.CloseHandle(handle)
        elif ctypes.get_last_error() != 87:
            raise RuntimeError('Não foi possível confirmar que o ERP fechou.')
    else:
        for _ in range(120):
            try:
                os.kill(pid, 0)
            except ProcessLookupError:
                return
            time.sleep(1)
        raise RuntimeError('ERP ainda aberto. Atualização cancelada.')


def main():
    pid, root, package = int(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
    log_dir = root / 'logs'
    log_dir.mkdir(exist_ok=True)
    with (log_dir / 'atualizacao.log').open('w', encoding='utf-8') as log:
        try:
            wait_parent(pid)
            subprocess.run([sys.executable, str(package / 'deploy.py'), '--package', str(package),
                            '--root', str(root)], stdout=log, stderr=log, check=True)
        except Exception as exc:
            log.write(str(exc) + '\n')
            log.flush()
            if os.name == 'nt':
                ctypes.windll.user32.MessageBoxW(None,
                    'Atualização não concluída. Consulte logs/atualizacao.log. Abra o ERP pelo atalho habitual.',
                    'Forgeon', 16)
            return 1
    python = root / '.venv' / ('Scripts/pythonw.exe' if os.name == 'nt' else 'bin/python')
    subprocess.Popen([str(python), str(root / 'run_erp.py')], cwd=root)
    return 0


if __name__ == '__main__':
    sys.exit(main())
