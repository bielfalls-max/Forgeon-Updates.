# Forgeon / Rudeus — conector MCP 0.5.12

## Atualização normal em qualquer PC com base conhecida

Use o HOTFIX CUMULATIVO 0.5.12. Ele aceita as bases conhecidas 0.5.8, 0.5.9, 0.5.10 e 0.5.11 diretamente. Não precisa instalar hotfixes intermediários. Feche o ERP, extraia o ZIP fora da instalação e selecione a pasta instalada (aquela com app e .venv). Banco, fotos, tarefas, configurações e o Python principal não são substituídos. Arquivos de programa modificados fora das bases conhecidas continuam protegidos por conferência de hashes.

## O que o botão faz e o que falta conectar

“Selecionar fotos e abrir ChatGPT” prepara a tarefa, copia o prompt e abre o navegador/pasta. Anexar fotos e enviar a mensagem continuam manuais. O servidor MCP dá ao cliente acesso às tarefas, fotos e resultados; não dispara sozinho a geração de imagens nem transforma a assinatura do ChatGPT em API.

A ponte HTTP autenticada está implementada. Um cliente MCP pode descobrir ferramentas, acessar fotos selecionadas e devolver JPGs. O cliente precisa oferecer edição de imagem para executar o processamento. Compatibilidade com a conta/cliente ChatGPT ainda precisa ser validada pelo usuário; a existência do endpoint não comprova essa compatibilidade.

## Teste com HTTPS sem domínio próprio — Windows

1. Abra Anúncio > Fotos > “Iniciar ponte HTTPS (teste)”. A janela explica o acesso remoto antes de iniciar.
2. Confirme para instalar componentes opcionais pela internet. O SDK fica em `.venv-mcp`, separado do Python principal. O iniciador tenta instalar Cloudflare Tunnel via winget, com verificação normal do pacote. Se não conseguir, a janela informa o comando necessário; reabra o ERP após instalar.
3. Aguarde a janela informar uma URL `https://....trycloudflare.com/mcp`. A criação de túnel depende da disponibilidade/limites do serviço e da rede local. Não requer um domínio próprio no fluxo de Quick Tunnel preparado aqui.
4. No ERP, clique “Copiar URL MCP”. Na área da sua conta/cliente que aceite conectores MCP personalizados, adicione essa URL com autenticação OAuth e registro dinâmico de cliente, se oferecidos. Os nomes e a disponibilidade dessas opções variam por conta. Não cole chaves de Gemini/OpenAI nem sua senha de ChatGPT.
5. O cliente deve abrir a página de autorização da sua ponte. Confira que você iniciou a conexão e que o domínio é o mesmo da URL copiada.
6. Clique “Copiar codigo de acesso” no ERP e cole o código SOMENTE nessa página de autorização. Não envie o código no chat. Ele é criado no seu computador e não faz parte do hotfix. A cópia é limpa após 60 segundos se você não trocar o clipboard.
7. Autorize a conexão. Crie uma tarefa no ERP e peça ao cliente para listar tarefas. A geração depende das ferramentas de edição disponíveis no cliente.
8. Resultados enviados por `save_edited_photo` aparecem quando você clica “Importar resultados MCP”. Downloads manuais continuam entrando por “Importar fotos prontas (GPT)”.

Mantenha a janela da ponte aberta durante o uso. CTRL+C encerra o servidor e o túnel desse iniciador. Ao reiniciar, o endereço muda e as sessões OAuth em memória são invalidadas; poderá ser necessário remover e cadastrar novamente o conector no cliente. O endereço temporário serve para teste, não é um endereço permanente nem atualização automática do ERP.

O servidor é stateless e retorna JSON por HTTP para as chamadas MCP; não depende de notificações SSE no túnel. Não abra a porta 8765 no roteador e não remova a autenticação. O processo vincula a porta somente a 127.0.0.1. O iniciador recusa uma porta já ocupada para não expor outro serviço por engano.

Apenas preparar arquivos no ERP não envia fotos à internet. Depois que a ponte e um cliente autorizado estiverem conectados, fotos das tarefas e os dados básicos consultados transitam pelo túnel até o cliente. O banco SQLite completo, cookies e chaves de provedores não são expostos pelas ferramentas implementadas.

## HTTPS permanente (opcional, futuro)

Com domínio/túnel ou proxy estável, configure o endereço público por:

```powershell
& '.\.venv-mcp\Scripts\python.exe' '.\app\integrations\configure_bridge.py' --public-url 'https://forgeon.seudominio.com'
& '.\.venv-mcp\Scripts\python.exe' '.\app\integrations\forgeon_mcp.py' --transport http
```

O proxy precisa encaminhar esse host HTTPS para `http://127.0.0.1:8765`, preservando o host. Configuração de proxy/túnel permanente e hospedagem não foram realizadas nesta entrega. Não exponha HTTP direto na internet.

## Cliente local MCP por stdio (continua disponível)

```powershell
& '.\.venv\Scripts\python.exe' -m venv '.venv-mcp'
& '.\.venv-mcp\Scripts\python.exe' -m pip install -r '.\app\integrations\requirements-mcp.txt'
& '.\.venv-mcp\Scripts\python.exe' '.\app\integrations\forgeon_mcp.py'
```

A última linha aguarda o protocolo no stdin. Um cliente MCP local normalmente inicia esse processo; isso não conecta automaticamente o ChatGPT no navegador.

## Ferramentas e limites

- `list_photo_jobs`: até 100 tarefas locais recentes.
- `get_photo_job(job_id)`: prompt, altura, quantidade e estado local dos resultados.
- `get_original_photo(job_id, slot)`: uma foto por vez, até 1,9 MB.
- `save_edited_photo(job_id, slot, jpeg_base64)`: JPG quadrado de até 1,9 MB, somente na tarefa; sem sobrescrever resultado diferente.
- `find_products(query, limit)`: dados básicos de até 25 produtos; SQLite somente leitura, sem configurações/chaves.
- Prompt `forgeon_photo_standard(job_id)`: padrão de edição preenchido com altura.

Originais para preparo manual podem ter até 25 MB cada; leitura pelo MCP é limitada a 1,9 MB por arquivo. Cliente e ChatGPT podem ter limites próprios. Máximo de 9 resultados. Dados locais ficam em `arquivos/chatgpt/<id>`. Estado AGUARDANDO_ENVIO não significa envio para o ChatGPT. CONCLUIDO significa resultados recebidos, não aprovação visual automática.

A autorização usa OAuth, PKCE, código de autorização de uso único, tokens com expiração e renovação/rotação. Reiniciar o servidor revoga as sessões em memória e requer reconectar. Cadastro de clientes, tarefas pendentes e tokens têm limites; reinicie a ponte se atingir o limite de cadastros. A credencial de aprovação é local, em `arquivos/mcp/access.key`; não a compartilhe. Configuração em `bridge.json` contém somente a origem pública e hash do código. Não há acesso a credenciais de login do ChatGPT.

## Evidência e limites desta entrega

Testado localmente: OAuth discovery/DCR/consentimento/PKCE, MCP HTTP, leitura de imagem/retorno de JPG, rotação/revogação, bloqueio de acesso sem token, CSRF/origem/PKCE incorretos, replay de código/token, host inválido e corpos grandes; MCP stdio; funções do ERP e hotfix cumulativo com preservação/restauração de dados.

NÃO validado neste ambiente: instalação PowerShell/winget no Windows, execução do túnel público, conectividade externa, tela de conectores da sua conta e edição de imagem acionada pelo cliente ChatGPT. Esses passos dependem do computador e da conta reais. Não foi publicado um endpoint neste ambiente.
