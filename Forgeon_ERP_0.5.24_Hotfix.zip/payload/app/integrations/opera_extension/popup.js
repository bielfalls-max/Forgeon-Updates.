const output=document.querySelector('#status');
document.querySelector('#save').onclick=async()=>{
 try{
  const data=JSON.parse(document.querySelector('#pairing').value);
  if(!/^http:\/\/127\.0\.0\.1:\d{4,5}$/.test(data.url)||!Number.isInteger(Number(data.url.split(':').at(-1)))||Number(data.url.split(':').at(-1))>65535||typeof data.token!=='string'||data.token.length<32)throw Error('Pareamento invalido. Copie novamente pelo ERP.');
  await chrome.storage.local.set({pairing:{url:data.url,token:data.token}});
  document.querySelector('#pairing').value='';
  const reply=await chrome.runtime.sendMessage({type:'poll'});output.textContent=reply?.message||'Pareamento salvo.';
 }catch(error){output.textContent=error.message;}
};
document.querySelector('#disconnect').onclick=async()=>{await chrome.storage.local.remove('pairing');output.textContent='Desconectada. Nenhum novo envio sera iniciado.';};
chrome.storage.local.get('lastStatus').then(value=>output.textContent=value.lastStatus||'Aguardando pareamento.');
