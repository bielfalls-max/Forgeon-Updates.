/* Operates only on the exact existing tab chosen by the ERP. Never opens tabs. */
const VERSION='0.5.20';let busy=false;
async function api(pair,path,data){
 const response=await fetch(pair.url+path,{method:data?'POST':'GET',headers:{'Authorization':'Bearer '+pair.token,'Content-Type':'application/json','X-Forgeon-Version':VERSION},body:data?JSON.stringify(data):undefined,cache:'no-store',signal:AbortSignal.timeout(15000)});
 const body=await response.json();if(!response.ok)throw Error(body.error||'Ponte local indisponivel');return body;
}
async function report(pair,job,state,message){await api(pair,'/status',{id:job.id,state,message});await chrome.storage.local.set({lastStatus:message});}
async function photoPage(action,job){
 const norm=value=>String(value||'').replace(/\s+/g,' ').trim();
 const marker='ERP-FOTOS-'+job.id,message=job.prompt+'\n\nReferencia da tarefa: '+marker;
 const editor=()=>document.querySelector('#prompt-textarea');
 const scope=()=>editor()?.closest('form')||editor()?.parentElement?.parentElement;
 const same=()=>{if(location.href.replace(/\/$/,'')!==job.url)throw Error('A aba mudou de conversa. Envio interrompido.');};
 const receipt=()=>[...document.querySelectorAll('[data-message-author-role="user"]')].find(node=>norm(node.innerText).includes(marker));
 const sendButton=()=>{
  const root=scope();if(!root)return null;
  const candidates=[...root.querySelectorAll('button')].filter(node=>node.dataset.testid==='send-button'||/^(send( prompt| message)?|enviar( prompt| mensagem)?)$/i.test(norm(node.getAttribute('aria-label')||node.getAttribute('title'))));
  if(candidates.length===1)return candidates[0];
  const submits=[...root.querySelectorAll('button[type="submit"]')];return submits.length===1?submits[0]:null;
 };
 const diagnostic=()=>({version:'0.5.20',pathKind:location.pathname.startsWith('/local/')?'local':'c',editor:editor()?{tag:editor().tagName,id:editor().id,editable:editor().isContentEditable}:null,
  editors:[...document.querySelectorAll('textarea,[contenteditable="true"],[role="textbox"]')].map(node=>({tag:node.tagName,id:node.id,role:node.getAttribute('role')||'',testid:node.dataset.testid||'',placeholder:(node.getAttribute('placeholder')||node.getAttribute('data-placeholder')||'').slice(0,80)})),
  inputs:[...document.querySelectorAll('input[type="file"]')].map(node=>({accept:node.accept,multiple:node.multiple,disabled:node.disabled,inComposer:!!scope()?.contains(node),fileCount:node.files.length})),
  buttons:[...(scope()?.querySelectorAll('button')||[])].map(node=>({label:(node.getAttribute('aria-label')||'').slice(0,80),title:(node.getAttribute('title')||'').slice(0,80),testid:(node.dataset.testid||'').slice(0,80),type:node.type,disabled:node.disabled})),
  previewImageCount:scope()?.querySelectorAll('img').length||0,progressCount:scope()?.querySelectorAll('[role="progressbar"],[aria-busy="true"]').length||0});
 if(action==='diagnostic')return {ok:true,diagnostic:diagnostic()};
 same();
 if(action==='cancel'){if(globalThis.forgeonPhotoTask)globalThis.forgeonPhotoTask.cancelled=true;return {ok:true};}
 const wait=async(test,ms,label)=>{const end=Date.now()+ms;while(Date.now()<end){same();if(globalThis.forgeonPhotoTask?.cancelled)throw Error('Espera cancelada pelo ERP.');if(test())return;await new Promise(resolve=>setTimeout(resolve,200));}throw Error(label);};
 const attached=()=>{
  const state=globalThis.forgeonPhotoTask,root=scope();if(!state||!root)return false;
  const images=[...root.querySelectorAll('img')].filter(img=>!state.initialImages.includes(img.currentSrc||img.src)&&img.complete&&img.naturalWidth>0);
  const remove=[...root.querySelectorAll('button[aria-label*="Remove"],button[aria-label*="Remover"]')];
  // Generic Remove controls alone are never evidence that a photo was uploaded.
  const named=job.images.every(file=>norm(root.innerText).includes(file.name));
  return (images.length===job.images.length&&remove.length>=job.images.length)||(named&&remove.length>=job.images.length);
 };
 if(action==='inspect'){
  if(!/\bfotos\b/i.test(document.title)&&![...document.querySelectorAll('h1,h2,[data-testid="conversation-title"]')].some(node=>/^fotos$/i.test(norm(node.textContent))))throw Error('Conversa Fotos nao confirmada.');
  if(!editor())throw Error('Campo de mensagem nao encontrado. Use Copiar diagnostico do envio.');
  if(receipt())throw Error('Tarefa ja aparece na conversa; nao sera reenviada.');
  if(norm(editor().innerText||editor().value))throw Error('Existe um rascunho. Envie ou limpe antes de tentar novamente.');
  if(scope()?.querySelector('[data-testid="attachment-preview"],button[aria-label*="Remove"],button[aria-label*="Remover"]'))throw Error('Existem anexos/controles de remocao no rascunho. Confira antes de enviar.');
  if(document.querySelector('[data-testid="stop-button"]'))throw Error('ChatGPT ainda esta respondendo.');
  const inputs=[...document.querySelectorAll('input[type="file"]')];
  let candidates=inputs.filter(input=>!input.disabled&&/image|\.png|\.jpe?g|\.webp/i.test(input.accept));
  if(!candidates.length)candidates=inputs.filter(input=>!input.disabled&&!input.accept);
  const local=candidates.filter(input=>scope()?.contains(input));if(local.length===1)candidates=local;
  if(candidates.length!==1)throw Error('Campo de anexos nao identificado com seguranca. Use Copiar diagnostico do envio.');
  candidates[0].setAttribute('data-forgeon-input',job.id);editor().setAttribute('data-forgeon-editor',job.id);
  globalThis.forgeonPhotoTask={id:job.id,cancelled:false,initialImages:[...(scope()?.querySelectorAll('img')||[])].map(img=>img.currentSrc||img.src)};
  return {ok:true};
 }
 const state=globalThis.forgeonPhotoTask;if(!state||state.id!==job.id||state.cancelled)throw Error('Tarefa cancelada ou pagina recarregada.');
 if(action==='uploaded'){
  await wait(attached,60000,'As fotos nao apareceram como anexos reconhecidos. O prompt nao foi preenchido. Use Copiar diagnostico do envio.');
  await wait(()=>!scope()?.querySelector('[role="progressbar"],[aria-busy="true"],[data-state="uploading"]'),60000,'Upload ainda pendente no ChatGPT. O prompt nao foi enviado.');
  return {ok:true};
 }
 if(action==='ready'){
  if(!attached())throw Error('Fotos nao confirmadas no rascunho. Nenhuma mensagem sera enviada.');
  await wait(()=>{const button=sendButton();return (!button||!button.disabled)&&!scope()?.querySelector('[role="progressbar"],[aria-busy="true"]');},30000,'Botao de enviar continua desabilitado.');
  if(norm(editor().innerText||editor().value)!==norm(message))throw Error('Prompt inserido diferente do preparado pelo ERP.');
  const button=sendButton();if(button)button.setAttribute('data-forgeon-send',job.id);
  return {ok:true,method:button?'click':'enter'};
 }
 if(action==='check'){
  if(!attached()||norm(editor().innerText||editor().value)!==norm(message))throw Error('Conversa, prompt ou anexos mudaram.');return {ok:true};
 }
 if(action==='confirm'){
  await wait(()=>receipt(),30000,'ChatGPT nao confirmou a mensagem. Confira o rascunho; nao havera reenvio automatico.');
  await wait(()=>{const turn=receipt();return norm(turn.innerText).startsWith(norm(message))&&turn.querySelectorAll('img,[data-testid="file-thumbnail"]').length===job.images.length&&!norm(editor()?.innerText||editor()?.value);},15000,'A mensagem nao confirmou todas as fotos. Confira a conversa; nao sera reenviada automaticamente.');
  delete globalThis.forgeonPhotoTask;return {ok:true};
 }
 throw Error('Acao desconhecida');
}
async function execute(tab,action,job){
 const results=await chrome.scripting.executeScript({target:{tabId:tab.id},func:photoPage,args:[action,job]});
 if(results.length!==1||!results[0].result?.ok)throw Error('A aba nao confirmou a operacao.');return results[0].result;
}
async function nativeNode(tab,selector){
 const doc=await chrome.debugger.sendCommand({tabId:tab.id},'DOM.getDocument',{depth:0});
 const result=await chrome.debugger.sendCommand({tabId:tab.id},'DOM.querySelector',{nodeId:doc.root.nodeId,selector});
 if(!result.nodeId)throw Error('Campo mudou durante a operacao.');return result.nodeId;
}
async function poll(){
 if(busy)return {message:'Envio em andamento; confira o status no ERP.'};busy=true;let pair,job,tab,clicked=false,debugging=false,stage='conexao';
 try{
  pair=(await chrome.storage.local.get('pairing')).pairing;if(!pair)return {message:'Copie o pareamento pelo ERP.'};
  if(!/^http:\/\/127\.0\.0\.1:\d{4,5}$/.test(pair.url)||typeof pair.token!=='string'||pair.token.length<32)throw Error('Pareamento local invalido.');
  const next=await api(pair,'/next');job=next.job;
  if(!job){const stored=await chrome.storage.local.get('lastStatus');return {message:'Conectada ao ERP. '+(stored.lastStatus||'Aguardando fotos.')};}
  if(!/^https:\/\/chatgpt\.com\/(c|local)\/[A-Za-z0-9-]+$/.test(job.url)||!/^[a-f0-9]{32}$/.test(job.id)||!Array.isArray(job.images)||job.images.length<1||job.images.length>9||job.images.some(image=>!image.path||!image.name))throw Error('Atualize ERP e recarregue a extensao 0.5.20.');
  stage='aba';const matches=(await chrome.tabs.query({url:'https://chatgpt.com/*'})).filter(item=>item.url?.replace(/\/$/,'')===job.url);
  tab=matches.length===1?matches[0]:matches.find(item=>item.active);
  if(!tab)throw Error(matches.length?'Deixe a aba Fotos correta ativa.':'Abra a aba Fotos configurada. Nenhuma aba nova foi aberta.');
  await execute(tab,'inspect',job);
  stage='permissao nativa';await chrome.debugger.attach({tabId:tab.id},'1.3');debugging=true;
  await report(pair,job,'ANEXANDO',`Anexando ${job.images.length} foto(s) pelo mecanismo nativo do navegador. Aguarde.`);
  stage='anexos';const input=await nativeNode(tab,`[data-forgeon-input="${job.id}"]`);
  await chrome.debugger.sendCommand({tabId:tab.id},'DOM.setFileInputFiles',{nodeId:input,files:job.images.map(image=>image.path)});
  await execute(tab,'uploaded',job);
  await report(pair,job,'ANEXANDO',`${job.images.length} foto(s) reconhecida(s). Preenchendo o prompt.`);
  stage='prompt';const editor=await nativeNode(tab,`[data-forgeon-editor="${job.id}"]`);
  await chrome.debugger.sendCommand({tabId:tab.id},'DOM.focus',{nodeId:editor});
  await chrome.debugger.sendCommand({tabId:tab.id},'Input.insertText',{text:job.prompt+'\n\nReferencia da tarefa: ERP-FOTOS-'+job.id});
  const ready=await execute(tab,'ready',job);
  stage='envio';await execute(tab,'check',job);await api(pair,'/submit-permit',{id:job.id});clicked=true;await execute(tab,'check',job);
  if(ready.method==='click'){
   const button=await nativeNode(tab,`[data-forgeon-send="${job.id}"]`);
   await chrome.debugger.sendCommand({tabId:tab.id},'DOM.scrollIntoViewIfNeeded',{nodeId:button});
   const box=await chrome.debugger.sendCommand({tabId:tab.id},'DOM.getBoxModel',{nodeId:button});
   const quad=box.model.content,x=(quad[0]+quad[4])/2,y=(quad[1]+quad[5])/2;
   await chrome.debugger.sendCommand({tabId:tab.id},'Input.dispatchMouseEvent',{type:'mousePressed',x,y,button:'left',clickCount:1});
   await chrome.debugger.sendCommand({tabId:tab.id},'Input.dispatchMouseEvent',{type:'mouseReleased',x,y,button:'left',clickCount:1});
  }else{
   await chrome.debugger.sendCommand({tabId:tab.id},'DOM.focus',{nodeId:editor});
   for(const type of ['keyDown','keyUp'])await chrome.debugger.sendCommand({tabId:tab.id},'Input.dispatchKeyEvent',{type,key:'Enter',code:'Enter',windowsVirtualKeyCode:13,nativeVirtualKeyCode:13,...(type==='keyDown'?{text:'\r'}:{})});
  }
  stage='confirmacao';await execute(tab,'confirm',job);
  const message=`Envio confirmado: prompt e ${job.images.length} foto(s) na mesma aba Fotos.`;
  await report(pair,job,'ENVIADO',message);return {message};
 }catch(error){
  if(job&&pair&&tab)try{const result=await execute(tab,'diagnostic',job);await api(pair,'/diagnostic',{id:job.id,stage,...result.diagnostic});}catch(_){}
  const message=(clicked?'Envio incerto. Confira a conversa Fotos. ':'Envio nao realizado. ')+`Etapa ${stage}: `+String(error.message).slice(0,700);
  if(job&&pair)try{await report(pair,job,clicked?'ENVIO_INCERTO':'ERRO',message);}catch(_){}
  await chrome.storage.local.set({lastStatus:message});return {message};
 }finally{
  if(debugging&&tab)try{await chrome.debugger.detach({tabId:tab.id});}catch(_){}
  busy=false;
 }
}
chrome.runtime.onMessage.addListener((message,sender,respond)=>{if(message.type==='poll'){poll().then(respond);return true;}});
chrome.alarms.create('forgeon-poll',{periodInMinutes:.5});chrome.alarms.onAlarm.addListener(alarm=>{if(alarm.name==='forgeon-poll')poll();});
setInterval(poll,2000);poll();
