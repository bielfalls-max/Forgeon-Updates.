"""Authenticated, loopback-only selected-photo bridge. No browser launching."""
import argparse,base64,hashlib,hmac,json,re,sys,threading,time
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from services.photo_extension import config
from services.chatgpt_browser import load
from services.photo_jobs import PhotoJobs

TERMINAL={'ENVIADO','ERRO','ENVIO_INCERTO'}
TRANSITIONS={'AGUARDANDO_EXTENSAO':{'RECEBIDA','ERRO'},'RECEBIDA':{'ANEXANDO','ERRO'},'ANEXANDO':{'CLICANDO_ENVIAR','ERRO'},'CLICANDO_ENVIAR':{'ENVIADO','ENVIO_INCERTO'}}

def atomic(path,data):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(data,ensure_ascii=False),encoding='utf-8');tmp.replace(path)

class Bridge(ThreadingHTTPServer):
    daemon_threads=True
    def __init__(self,root,port=None):
        self.root=Path(root);self.cfg=config(root);self.store=PhotoJobs(self.root/'arquivos/chatgpt');self.lock=threading.RLock();self.last_erp=time.monotonic();self.last_extension=0
        self.extension_version='';self.queue=self.root/'arquivos/chatgpt-browser/extension-queue.json'
        super().__init__(('127.0.0.1',self.cfg['port'] if port is None else port),Handler)
        # A previous process may have died after submitting. Never resume blindly.
        if self.queue.exists():
            old=json.loads(self.queue.read_text())
            self.expire(old,force=True)
    def current(self):return json.loads(self.queue.read_text()) if self.queue.exists() else None
    def record(self,job):return self.store.folder(job['id'])/'browser-send.json'
    def state(self,job):return json.loads(self.record(job).read_text())['state']
    def update(self,job,state,message):
        atomic(self.record(job),{'state':state,'message':message})
    def expire(self,job,force=False):
        if job and (force or time.time()-job['created']>300) and self.state(job) not in TERMINAL:
            state='ENVIO_INCERTO' if self.state(job)=='CLICANDO_ENVIAR' else 'ERRO'
            self.update(job,state,'Envio interrompido ou tempo de espera encerrado. Confira a conversa Fotos antes de tentar novamente.')

class Handler(BaseHTTPRequestHandler):
    server_version='ForgeonLocal';sys_version=''
    def log_message(self,*args):pass
    def response(self,status,data):
        body=json.dumps(data,ensure_ascii=False).encode();self.send_response(status)
        self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(body)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(body)
    def do_OPTIONS(self):self.response(403,{'error':'Cross-origin website requests are disabled'})
    def do_GET(self):self.handle_api()
    def do_POST(self):self.handle_api()
    def handle_api(self):
        if self.headers.get('Host')!=f'127.0.0.1:{self.server.server_port}':return self.response(403,{'error':'Host invalido'})
        origin=self.headers.get('Origin','')
        if origin and not re.fullmatch(r'chrome-extension://[a-p]{32}',origin):return self.response(403,{'error':'Origem invalida'})
        if not hmac.compare_digest(self.headers.get('Authorization',''),'Bearer '+self.server.cfg['token']):return self.response(401,{'error':'Pareamento necessario'})
        try:
            length=int(self.headers.get('Content-Length','0'))
            if not 0<=length<=65536:return self.response(413,{'error':'Corpo muito grande'})
            data=json.loads(self.rfile.read(length) or b'{}') if self.command=='POST' else None
            with self.server.lock:
                job=self.server.current();self.server.expire(job)
                if self.command=='GET' and self.path=='/health':
                    self.server.last_erp=time.monotonic()
                    return self.response(200,{'service':'forgeon-photo-extension-2','extension_connected':time.monotonic()-self.server.last_extension<60,'extension_version':self.server.extension_version})
                if self.command=='POST' and self.path=='/shutdown':
                    self.server.expire(job,force=True);self.response(200,{'ok':True});threading.Thread(target=self.server.shutdown,daemon=True).start();return
                if self.command=='POST' and self.path=='/enqueue':
                    if job and self.server.state(job) not in TERMINAL:return self.response(409,{'error':'Outro envio esta em andamento'})
                    selected=self.server.store.get(data['id']);url=load(self.server.root)
                    if self.server.record(selected).exists():return self.response(409,{'error':'Esta tarefa ja teve envio preparado; nao sera reenviada automaticamente'})
                    job={'id':selected['id'],'url':url,'created':time.time()};atomic(self.server.queue,job)
                    self.server.update(job,'AGUARDANDO_EXTENSAO','Aguardando a extensao na aba Fotos ja aberta. Nao sera aberta outra janela. Instale/pareie a extensao se ainda nao fez isso.')
                    return self.response(200,{'ok':True})
                if self.command=='GET' and self.path=='/next':
                    self.server.last_extension=time.monotonic();self.server.extension_version=self.headers.get('X-Forgeon-Version','anterior')[:20]
                    if self.server.extension_version!='0.5.20':
                        if job and self.server.state(job)=='AGUARDANDO_EXTENSAO':self.server.update(job,'AGUARDANDO_EXTENSAO','Extensao antiga detectada. Em opera://extensions, clique Recarregar na extensao Forgeon 0.5.20 e aceite a permissao de depuracao da aba.')
                        return self.response(409,{'error':'Recarregue a extensao Forgeon 0.5.20 em opera://extensions.'})
                    if not job or self.server.state(job)!='AGUARDANDO_EXTENSAO':return self.response(200,{'job':None})
                    selected=self.server.store.get(job['id']);images=[]
                    for entry in selected['images']:
                        path=self.server.store.inside(self.server.store.folder(job['id']),entry['file']);raw=path.read_bytes()
                        if len(raw)>25_000_000 or hashlib.sha256(raw).hexdigest()!=entry['sha256']:raise ValueError('Original alterado')
                        images.append({'slot':entry['slot'],'name':path.name,'path':str(path)})
                    self.server.update(job,'RECEBIDA','Extensao 0.5.20 recebeu a tarefa. Verificando a aba existente.')
                    return self.response(200,{'job':{'id':job['id'],'url':job['url'],'prompt':selected['prompt'],'images':images}})
                if self.command=='POST' and self.path=='/submit-permit':
                    if not job or data.get('id')!=job['id'] or self.server.state(job)!='ANEXANDO':return self.response(409,{'error':'Envio cancelado, expirado ou ja autorizado'})
                    self.server.update(job,'CLICANDO_ENVIAR','Fotos e prompt reconhecidos. Acionando envio nativo e aguardando confirmacao.')
                    return self.response(200,{'ok':True})
                if self.command=='POST' and self.path=='/cancel':
                    if job and data.get('id')==job['id'] and self.server.state(job) not in TERMINAL:
                        state='ENVIO_INCERTO' if self.server.state(job)=='CLICANDO_ENVIAR' else 'ERRO'
                        self.server.update(job,state,'Espera cancelada. Confira a conversa Fotos; anexos ou rascunho podem permanecer. Nao ha reenvio automatico.')
                    return self.response(200,{'ok':True})
                if self.command=='POST' and self.path=='/diagnostic':
                    if not job or data.get('id')!=job['id']:return self.response(409,{'error':'Tarefa inativa'})
                    # Structural metadata only: never store chat text, prompt,
                    # screenshots, cookies, pairing token or local file paths.
                    safe={'version':str(data.get('version',''))[:20],'stage':str(data.get('stage',''))[:40],
                          'pathKind':str(data.get('pathKind',''))[:10],
                          'previewImageCount':int(data.get('previewImageCount',0)),'progressCount':int(data.get('progressCount',0))}
                    for name,keys in [('editors',('tag','id','role','testid','placeholder')),('inputs',('accept','multiple','disabled','inComposer','fileCount')),('buttons',('label','title','testid','type','disabled'))]:
                        safe[name]=[{key:(str(value[key])[:80] if isinstance(value.get(key),str) else value.get(key)) for key in keys} for value in data.get(name,[])[:40] if isinstance(value,dict)]
                    safe['editor']={key:data['editor'].get(key) for key in ('tag','id','editable')} if isinstance(data.get('editor'),dict) else None
                    atomic(self.server.store.folder(job['id'])/'browser-diagnostic.json',safe)
                    return self.response(200,{'ok':True})
                if self.command=='POST' and self.path=='/status':
                    if not job or data.get('id')!=job['id']:return self.response(409,{'error':'Tarefa inativa'})
                    state=data['state'];old=self.server.state(job)
                    if state=='CLICANDO_ENVIAR' or not (state==old=='ANEXANDO' or state in TRANSITIONS.get(old,set())):return self.response(409,{'error':'Transicao de envio invalida'})
                    self.server.update(job,state,str(data['message'])[:1000]);return self.response(200,{'ok':True})
                match=re.fullmatch(r'/image/([a-f0-9]{32})/([1-9])',self.path)
                if self.command=='GET' and match:
                    if not job or match[1]!=job['id'] or self.server.state(job) not in ('RECEBIDA','ANEXANDO'):return self.response(403,{'error':'Foto fora da tarefa ativa'})
                    selected=self.server.store.get(job['id']);entry=next(x for x in selected['images'] if x['slot']==int(match[2]))
                    path=self.server.store.inside(self.server.store.folder(job['id']),entry['file']);raw=path.read_bytes()
                    if len(raw)>25_000_000 or hashlib.sha256(raw).hexdigest()!=entry['sha256']:raise ValueError('Original alterado ou muito grande')
                    mime={'.png':'image/png','.jpg':'image/jpeg','.webp':'image/webp'}[path.suffix]
                    return self.response(200,{'name':path.name,'mime':mime,'base64':base64.b64encode(raw).decode()})
                return self.response(404,{'error':'Rota inexistente'})
        except (ValueError,KeyError,OSError,StopIteration,TypeError):return self.response(400,{'error':'Requisicao invalida; confira a tarefa no ERP'})

def main(root):
    server=Bridge(root)
    def idle():
        while True:
            time.sleep(5)
            if time.monotonic()-server.last_erp>360:
                with server.lock:server.expire(server.current(),force=True)
                server.shutdown();return
    threading.Thread(target=idle,daemon=True).start()
    try:server.serve_forever()
    finally:server.server_close()
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--root',type=Path,required=True);args=parser.parse_args();main(args.root.resolve())
