"""Single-owner OAuth/PKCE consent for a local MCP behind an HTTPS reverse proxy.
Codes, registered clients and grants are in memory; stopping the bridge revokes all sessions.
"""
import hashlib,hmac,html,secrets,time,re,ipaddress
from urllib.parse import urlencode,urlsplit
from mcp.server.auth.provider import AuthorizationCode,AccessToken,RefreshToken,TokenError,AuthorizeError,RegistrationError
from mcp.shared.auth import OAuthToken
from starlette.responses import HTMLResponse,RedirectResponse,PlainTextResponse

SCOPE='forgeon:use'
HEADERS={'Cache-Control':'no-store','Pragma':'no-cache','X-Frame-Options':'DENY','Content-Security-Policy':"default-src 'none'; form-action 'self'; frame-ancestors 'none'"}

class OwnerOAuth:
    def __init__(self,origin,access_hash):
        self.origin=origin;self.resource=origin+'/mcp';self.access_hash=access_hash
        self.clients={};self.pending={};self.codes={};self.access={};self.refresh={};self.families={};self.failures=[];self.recent={}

    def prune(self):
        now=time.time()
        for key,item in list(self.pending.items()):
            if item['expires']<now:
                self.pending.pop(key,None);self.remember(key,'expired')
        for mapping in (self.codes,self.access,self.refresh):
            for key,item in list(mapping.items()):
                if item.expires_at and item.expires_at<now:mapping.pop(key,None)
        for family,pair in list(self.families.items()):
            if pair[0] not in self.access and pair[1] not in self.refresh:self.families.pop(family,None)
        self.failures=[x for x in self.failures if x>now-60]
        for key,item in list(self.recent.items()):
            if item[1]<now:self.recent.pop(key,None)

    def remember(self,handle,reason):
        self.recent[handle]=(reason,time.time()+300)
        while len(self.recent)>256:self.recent.pop(next(iter(self.recent)))

    @staticmethod
    def callback_origin(uri):
        parsed=urlsplit(str(uri));host=parsed.hostname or ''
        if parsed.scheme not in ('http','https') or not host or parsed.username or parsed.password or parsed.fragment:
            raise ValueError('Callback invalido')
        try:
            address=ipaddress.ip_address(host)
            host='['+str(address)+']' if address.version==6 else str(address)
        except ValueError:
            host=host.encode('idna').decode('ascii').lower()
            if not re.fullmatch(r'[a-z0-9.-]+',host):raise ValueError('Host de callback invalido')
        port=parsed.port
        return parsed.scheme+'://'+host+(':'+str(port) if port is not None else '')

    def consent_headers(self,params):
        # Chrome applies form-action to the redirect chain as well as the POST.
        # Authorize only the validated client's callback origin, never a wildcard.
        origin=self.callback_origin(params.redirect_uri)
        return {**HEADERS,'Content-Security-Policy':
            "default-src 'none'; form-action 'self' "+origin+"; frame-ancestors 'none'"}

    async def get_client(self,client_id):return self.clients.get(client_id)

    async def register_client(self,client_info):
        if len(self.clients)>=128:raise RegistrationError('invalid_client_metadata','Limite de clientes. Reinicie a ponte para limpar cadastros.')
        for uri in client_info.redirect_uris or []:
            u=urlsplit(str(uri))
            if u.scheme!='https' and not (u.scheme=='http' and u.hostname in ('127.0.0.1','localhost')):
                raise RegistrationError('invalid_redirect_uri','Use callback HTTPS ou loopback local.')
            try:self.callback_origin(uri)
            except (ValueError,UnicodeError):raise RegistrationError('invalid_redirect_uri','Callback invalido')
        self.clients[client_info.client_id]=client_info

    async def authorize(self,client,params):
        self.prune()
        if len(self.pending)>=128:raise AuthorizeError('temporarily_unavailable','Tente novamente depois')
        if params.resource not in (None,self.resource):raise AuthorizeError('invalid_request','Recurso incorreto')
        if set(params.scopes or [SCOPE])!={SCOPE}:raise AuthorizeError('invalid_scope','Escopo invalido')
        handle=secrets.token_urlsafe(32)
        self.pending[handle]={'client':client,'params':params,'expires':time.time()+300,'csrf':secrets.token_urlsafe(32)}
        return self.origin+'/consent?request='+handle

    async def consent(self,request):
        self.prune()
        if request.method=='POST':
            if request.headers.get('origin') not in (None,self.origin):return PlainTextResponse('Origem invalida',403,headers=HEADERS)
            fields=await request.form();handle=str(fields.get('request',''))
        else:fields={};handle=request.query_params.get('request','')
        if not handle:
            return PlainTextResponse('Formulario de autorizacao incompleto. Inicie uma nova conexao pelo cliente MCP.',400,headers=HEADERS)
        pending=self.pending.get(handle)
        if not pending:
            reason=self.recent.get(handle,('unknown',0))[0]
            message={'used':'Esta autorizacao ja foi concluida ou recusada. Volte ao cliente MCP; se nao conectou, inicie uma nova solicitacao.',
                     'expired':'Autorizacao expirada. Inicie a conexao novamente.',
                     'unknown':'Solicitacao nao encontrada. A ponte pode ter reiniciado ou o link e antigo. Inicie uma nova conexao com a URL MCP atual.'}[reason]
            return PlainTextResponse(message,400,headers=HEADERS)
        headers=self.consent_headers(pending['params'])
        if request.method=='GET':
            client=html.escape(pending['client'].client_name or 'Cliente MCP')
            callback=html.escape(str(pending['params'].redirect_uri))
            page=f'''<!doctype html><html lang="pt-BR"><meta charset="utf-8"><title>Autorizar Forgeon</title>
<h1>Conectar ao seu ERP</h1><p>Cliente solicitante (nome informado pelo cliente): <strong>{client}</strong></p>
<p>Callback registrado: {callback}</p><p>Permite consultar tarefas e fotos selecionadas, salvar resultados JPG e consultar dados basicos de produtos. Nao fornece edicao de imagens.</p>
<p>Autorize somente uma conexao que voce iniciou. Copie o codigo de acesso no ERP; nao informe sua senha do ChatGPT.</p>
<form method="post" action="/consent"><input type="hidden" name="request" value="{handle}"><input type="hidden" name="csrf" value="{pending['csrf']}">
<label>Codigo de acesso local <input type="password" name="access_code" required maxlength="128" autocomplete="off"></label>
<button name="decision" value="allow">Autorizar conexao</button><button name="decision" value="deny" formnovalidate>Recusar</button></form></html>'''
            return HTMLResponse(page,headers=headers)
        if not hmac.compare_digest(str(fields.get('csrf','')),pending['csrf']):return PlainTextResponse('Formulario invalido',403,headers=HEADERS)
        params=pending['params']
        if fields.get('decision')=='deny':
            self.pending.pop(handle,None);self.remember(handle,'used')
            return self.redirect(params,{'error':'access_denied'})
        if len(self.failures)>=10:return PlainTextResponse('Aguarde um minuto e tente novamente.',429,headers={**HEADERS,'Retry-After':'60'})
        provided=hashlib.sha256(str(fields.get('access_code','')).encode()).hexdigest()
        if not hmac.compare_digest(provided,self.access_hash):
            self.failures.append(time.time());return PlainTextResponse('Codigo incorreto. Volte e tente novamente.',403,headers=HEADERS)
        if self.pending.pop(handle,None) is None:return PlainTextResponse('Autorizacao ja usada',400,headers=HEADERS)
        self.remember(handle,'used')
        code=secrets.token_urlsafe(32)
        self.codes[code]=AuthorizationCode(code=code,client_id=pending['client'].client_id,scopes=[SCOPE],expires_at=time.time()+120,code_challenge=params.code_challenge,redirect_uri=params.redirect_uri,redirect_uri_provided_explicitly=params.redirect_uri_provided_explicitly,resource=self.resource,subject='owner')
        return self.redirect(params,{'code':code})

    def redirect(self,params,values):
        if params.state is not None:values['state']=params.state
        uri=str(params.redirect_uri)
        return RedirectResponse(uri+('&' if '?' in uri else '?')+urlencode(values),status_code=303,headers=self.consent_headers(params))

    async def load_authorization_code(self,client,authorization_code):
        self.prune();code=self.codes.get(authorization_code)
        return code if code and code.client_id==client.client_id else None

    def issue(self,client_id):
        self.prune()
        if len(self.refresh)>=256:raise TokenError('invalid_grant','Limite de sessoes; reconecte apos reiniciar a ponte')
        now=int(time.time());a=secrets.token_urlsafe(32);r=secrets.token_urlsafe(32)
        self.access[a]=AccessToken(token=a,client_id=client_id,scopes=[SCOPE],expires_at=now+3600,resource=self.resource,subject='owner')
        self.refresh[r]=RefreshToken(token=r,client_id=client_id,scopes=[SCOPE],expires_at=now+86400,resource=self.resource,subject='owner')
        self.families[r]=(a,r)
        return OAuthToken(access_token=a,refresh_token=r,expires_in=3600,scope=SCOPE)

    async def exchange_authorization_code(self,client,authorization_code):
        if self.codes.pop(authorization_code.code,None) is None:raise TokenError('invalid_grant','Codigo ja utilizado')
        return self.issue(client.client_id)

    async def load_refresh_token(self,client,refresh_token):
        self.prune();token=self.refresh.get(refresh_token)
        return token if token and token.client_id==client.client_id else None

    async def exchange_refresh_token(self,client,refresh_token,scopes):
        if set(scopes or [SCOPE])!={SCOPE}:raise TokenError('invalid_scope','Escopo invalido')
        if refresh_token.token not in self.refresh:raise TokenError('invalid_grant','Token ja utilizado')
        await self.revoke_token(refresh_token)
        return self.issue(client.client_id)

    async def load_access_token(self,token):
        self.prune();return self.access.get(token)

    async def revoke_token(self,token):
        for family,pair in list(self.families.items()):
            if token.token in pair:
                self.access.pop(pair[0],None);self.refresh.pop(pair[1],None);self.families.pop(family,None)
