"""Configure a public origin without displaying the locally generated access code."""
import argparse,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from services.mcp_settings import save_settings
parser=argparse.ArgumentParser();parser.add_argument('--public-url',required=True);parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[2]);args=parser.parse_args()
save_settings(args.root,args.public_url)
print('Endereco HTTPS configurado. Codigo de acesso disponivel somente no ERP local.')
