﻿$ErrorActionPreference = 'Stop'
$root = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
$python = Join-Path $root '.venv-mcp\Scripts\python.exe'
$appPython = Join-Path $root '.venv\Scripts\python.exe'
if (-not (Test-Path -LiteralPath $appPython)) { throw 'Ambiente Python do ERP nao encontrado.' }
$runtime = Join-Path $root 'arquivos\mcp'
New-Item -ItemType Directory -Force -Path $runtime | Out-Null
Write-Host 'Preparando componentes opcionais da ponte. Isso nao altera o Python do ERP.'
if (-not (Test-Path -LiteralPath $python)) {
    & $appPython -m venv (Join-Path $root '.venv-mcp')
    if ($LASTEXITCODE -ne 0) { throw 'Falha ao criar ambiente da ponte.' }
}
& $python -m pip install -r (Join-Path $PSScriptRoot 'requirements-mcp.txt')
if ($LASTEXITCODE -ne 0) { throw 'Falha na instalacao do SDK MCP.' }
$tunnelCommand = Get-Command cloudflared.exe -ErrorAction SilentlyContinue
if (-not $tunnelCommand -and (Get-Command winget -ErrorAction SilentlyContinue)) {
    Write-Host 'Instalando Cloudflare Tunnel pelo catalogo winget, com verificacao normal de integridade.'
    & winget install --exact --id Cloudflare.cloudflared --source winget --accept-package-agreements --accept-source-agreements --disable-interactivity
    if ($LASTEXITCODE -eq 0) {
        $tunnelCommand = Get-Command cloudflared.exe -ErrorAction SilentlyContinue
        if (-not $tunnelCommand) {
            $candidates = @((Join-Path $env:LOCALAPPDATA 'Microsoft\WinGet\Links\cloudflared.exe'))
            if (${env:ProgramFiles(x86)}) { $candidates += Join-Path ${env:ProgramFiles(x86)} 'cloudflared\cloudflared.exe' }
            if ($env:ProgramFiles) { $candidates += Join-Path $env:ProgramFiles 'cloudflared\cloudflared.exe' }
            foreach ($candidate in $candidates) {
                if (Test-Path -LiteralPath $candidate) { $tunnelCommand = [PSCustomObject]@{Source=$candidate}; break }
            }
        }
    }
}
if (-not $tunnelCommand) {
    Write-Host 'Cloudflare Tunnel nao localizado. Instale pelo comando abaixo e reabra o ERP:'
    Write-Host 'winget install --exact --id Cloudflare.cloudflared --source winget'
    Read-Host 'Pressione Enter para sair'
    exit 1
}
# Do not expose an unrelated existing service on this port.
$probe = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback,8765)
try { $probe.Start() } catch { throw 'Porta 8765 ocupada. Encerre a outra ponte antes de iniciar uma nova.' } finally { $probe.Stop() }
# Quick Tunnel does not require a private token or domain. Its URL changes each run.
$stamp = [Guid]::NewGuid().ToString('N')
$stderr = Join-Path $runtime ('tunnel_' + $stamp + '.log')
$stdout = Join-Path $runtime ('tunnel_' + $stamp + '.out')
$tunnel = $null
try {
    Write-Host 'Criando HTTPS temporario. Nao feche esta janela enquanto usar a ponte.'
    $tunnel = Start-Process -FilePath $tunnelCommand.Source -ArgumentList @('tunnel','--no-autoupdate','--url','http://127.0.0.1:8765') -RedirectStandardError $stderr -RedirectStandardOutput $stdout -PassThru -WindowStyle Hidden
    $url = $null
    for ($i=0; $i -lt 60; $i++) {
        if ($tunnel.HasExited) { throw ('Tunnel encerrado. Consulte ' + $stderr) }
        if (Test-Path -LiteralPath $stderr) {
            $log = Get-Content -LiteralPath $stderr -Raw -ErrorAction SilentlyContinue
            if ($log -match 'https://[a-z0-9-]+\.trycloudflare\.com') { $url = $Matches[0]; break }
        }
        Start-Sleep -Milliseconds 500
    }
    if (-not $url) { throw ('Nao foi possivel obter o HTTPS temporario. Consulte ' + $stderr) }
    & $python (Join-Path $PSScriptRoot 'configure_bridge.py') --root $root --public-url $url
    if ($LASTEXITCODE -ne 0) { throw 'Falha ao configurar a origem HTTPS.' }
    Write-Host ('Endereco MCP: ' + $url + '/mcp')
    Write-Host 'No ERP, use Copiar URL MCP e Copiar codigo de acesso. Nao envie o codigo no chat.'
    Write-Host 'Se sua conta oferecer conectores MCP personalizados, configure OAuth usando o endereco acima.'
    Write-Host 'Apenas tarefas/fotos selecionadas e dados basicos de produtos ficam disponiveis a clientes autorizados.'
    Write-Host 'CTRL+C encerra esta ponte. Ao reiniciar, reconecte o cliente com o novo endereco.'
    & $python (Join-Path $PSScriptRoot 'forgeon_mcp.py') --root $root --transport http
    if ($LASTEXITCODE -ne 0) { throw 'Servidor MCP encerrado com falha.' }
} finally {
    if ($tunnel -and -not $tunnel.HasExited) { Stop-Process -Id $tunnel.Id -ErrorAction SilentlyContinue }
}
