"""Local MCP via stdio or authenticated HTTP behind an HTTPS proxy."""
import argparse,sys,sqlite3
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from mcp.server.fastmcp import FastMCP,Image
from mcp.types import ToolAnnotations
from services.photo_jobs import PhotoJobs

def register_tools(mcp,root):
    jobs=PhotoJobs(root/'arquivos/chatgpt')
    readonly=ToolAnnotations(readOnlyHint=True,destructiveHint=False,openWorldHint=False)
    
    @mcp.tool(annotations=readonly)
    def list_photo_jobs() -> list[dict]:
        """List local photo jobs explicitly created by the ERP user. No external submission occurs."""
        return jobs.list()
    
    @mcp.tool(annotations=readonly)
    def get_photo_job(job_id:str) -> dict:
        """Read the user's photo instructions, expected output count and current local results."""
        return jobs.get(job_id)
    
    @mcp.tool(annotations=readonly)
    def get_original_photo(job_id:str,slot:int) -> Image:
        """Return ONE user-selected original, at most 1.9 MB. Does not perform image generation."""
        return Image(path=str(jobs.image(job_id,slot)))
    
    @mcp.tool(annotations=ToolAnnotations(readOnlyHint=False,destructiveHint=False,openWorldHint=False))
    def save_edited_photo(job_id:str,slot:int,jpeg_base64:str) -> dict:
        """Save one square JPEG <=1.9 MB to this job only. Existing different results cannot be overwritten.
        Image editing must be provided separately by the client, local editor, or authorized API.
        """
        return jobs.save_result(job_id,slot,jpeg_base64)
    
    @mcp.tool(annotations=readonly)
    def find_products(query:str='',limit:int=10) -> dict:
        """Search basic product data in the existing ERP database, read only. No settings or credentials."""
        limit=max(1,min(int(limit),25));db=root/'data/forgeon.db'
        if not db.exists():return {'products':[],'notice':'Banco ainda nao criado'}
        with sqlite3.connect(db.as_uri()+'?mode=ro',uri=True) as con:
            con.row_factory=sqlite3.Row
            rows=con.execute('SELECT id,boneco_name,variation_name,sku,weight_g,print_hours FROM variants WHERE active=1 AND (boneco_name LIKE ? OR sku LIKE ?) ORDER BY id LIMIT ?',('%'+query+'%','%'+query+'%',limit)).fetchall()
            return {'products':[dict(row) for row in rows]}
    
    @mcp.prompt()
    def forgeon_photo_standard(job_id:str) -> str:
        """Use the saved Forgeon photo standard for an existing job. Requires a client with image-editing tools."""
        return jobs.get(job_id)['prompt']
    

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[2])
    parser.add_argument('--transport',choices=['stdio','http'],default='stdio')
    args=parser.parse_args();root=args.root.resolve()
    if args.transport=='stdio':
        mcp=FastMCP('Forgeon Rudeus — conector local');register_tools(mcp,root);mcp.run(transport='stdio')
    else:
        from integrations.remote_http import make_http
        import uvicorn
        app,_=make_http(root,register_tools)
        uvicorn.run(app,host='127.0.0.1',port=8765,access_log=False,log_level='warning')

if __name__=='__main__':main()
