"""Authenticated HTTP factory. Bind only to loopback; HTTPS is supplied by a reverse proxy/tunnel."""
from urllib.parse import urlsplit,parse_qsl
from mcp.server.fastmcp import FastMCP
from mcp.server.auth.settings import AuthSettings,ClientRegistrationOptions,RevocationOptions
from mcp.server.transport_security import TransportSecuritySettings
from starlette.responses import PlainTextResponse
from starlette.middleware.trustedhost import TrustedHostMiddleware
from services.mcp_settings import load_settings
from integrations.remote_auth import OwnerOAuth,SCOPE

class BodyLimit:
    def __init__(self,app):self.app=app
    async def __call__(self,scope,receive,send):
        if scope['type']!='http' or scope['method'] not in ('POST','PUT','PATCH'):
            return await self.app(scope,receive,send)
        limit=4_194_304 if scope['path']=='/mcp' else 16384
        chunks=[];size=0
        while True:
            message=await receive()
            if message['type']=='http.disconnect':return
            data=message.get('body',b'');size+=len(data)
            if size>limit:return await PlainTextResponse('Requisicao muito grande',413)(scope,receive,send)
            chunks.append(data)
            if not message.get('more_body'):break
        body=b''.join(chunks)
        # SDK 1.30 models client_secret as a required nullable field on /revoke.
        # Public OAuth clients legitimately omit it. Supplying an empty form field
        # preserves the SDK's authentication checks while restoring that case.
        if scope['path']=='/revoke':
            content_type=dict(scope.get('headers',[])).get(b'content-type',b'').split(b';')[0]
            if content_type==b'application/x-www-form-urlencoded':
                try:fields=parse_qsl(body.decode('utf-8'),keep_blank_values=True,max_num_fields=32)
                except (ValueError,UnicodeDecodeError):return await PlainTextResponse('Formulario invalido',400)(scope,receive,send)
                if not any(key=='client_secret' for key,_ in fields):body+=b'&client_secret='
        delivered=False
        async def replay():
            nonlocal delivered
            if not delivered:
                delivered=True;return {'type':'http.request','body':body,'more_body':False}
            return await receive()
        await self.app(scope,replay,send)

def make_http(root,register_tools):
    config=load_settings(root);origin=config['public_url'];host=urlsplit(origin).hostname
    provider=OwnerOAuth(origin,config['access_hash'])
    mcp=FastMCP('Forgeon Rudeus — ponte autenticada',host='127.0.0.1',port=8765,stateless_http=True,json_response=True,
        auth_server_provider=provider,
        auth=AuthSettings(issuer_url=origin,resource_server_url=origin+'/mcp',validate_token_resource=True,required_scopes=[SCOPE],
            client_registration_options=ClientRegistrationOptions(enabled=True,valid_scopes=[SCOPE],default_scopes=[SCOPE]),revocation_options=RevocationOptions(enabled=True)),
        transport_security=TransportSecuritySettings(enable_dns_rebinding_protection=True,allowed_hosts=[host,'127.0.0.1:*','localhost:*'],allowed_origins=[origin]))
    register_tools(mcp,root)
    mcp.custom_route('/consent',methods=['GET','POST'])(provider.consent)
    @mcp.custom_route('/health',methods=['GET'])
    async def health(request):return PlainTextResponse('Forgeon bridge running. Public reachability is not verified.')
    app=mcp.streamable_http_app()
    app.add_middleware(TrustedHostMiddleware,allowed_hosts=[host,'127.0.0.1','localhost'])
    app.add_middleware(BodyLimit)
    return app,provider
