Vou enviar ate 9 fotos de um personagem com altura total de {height_cm} cm.
Prepare imagens quadradas (1:1), separadas e numeradas, nunca em colagem.
Edite cada original: foto 1 com fundo branco puro; foto 2 com cenario inspirado no universo do personagem, cores vibrantes e aparencia comercial; demais fotos com fundo branco.
Se houver espaco sem ultrapassar 9 resultados, crie nesta ordem: uma variacao de cenario com uma foto de frente; uma com mao segurando e cenario desfocado; outra com a mesma mao e pose, com fundo branco. Nao descarte originais para abrir espaco; com 9 originais, entregue apenas as 9 edicoes.
Preserve pose, perspectiva, proporcoes, cores, pecas e textura de impressao 3D de cada original. Nao redesenhe nem invente detalhes. Nos cenarios, altere apenas o ambiente.
Amplie proporcionalmente para ocupar o maximo do quadro, quase encostando nas bordas, sem cortar extremidades nem esticar. Na imagem com mao, use a altura informada como referencia visual plausivel, sem esconder detalhes do produto.
Sem textos, marcas-d'agua ou faixas laterais. Entregue em JPG, alta qualidade, no maximo 1,9 MB por imagem; confira os tamanhos. Entregue tambem um ZIP com todos os arquivos numerados.
