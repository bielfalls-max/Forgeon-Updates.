from __future__ import annotations
from PySide6.QtWidgets import QTabWidget,QInputDialog

import logging
import tempfile
import subprocess,sys
import hashlib
import shutil
import re
import json
import unicodedata
from datetime import datetime
from pathlib import Path

from PIL import Image, ImageChops
import hashlib
from uuid import uuid4
from services.ready_photos import prepare_ready_photo
from services.photo_jobs import PhotoJobs
from config import APP_ROOT
from PySide6.QtCore import QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import QApplication

from PySide6.QtCore import Qt, QObject, QThread, Signal, QTimer, QEvent
from PySide6.QtGui import QPixmap,QKeySequence
from PySide6.QtWidgets import (
    QAbstractItemView, QAbstractSpinBox, QPlainTextEdit, QCheckBox, QComboBox, QDialog, QDoubleSpinBox, QFileDialog,
    QFormLayout, QFrame, QGridLayout, QHBoxLayout, QHeaderView, QLabel, QLineEdit, QMessageBox,
    QPushButton, QScrollArea, QSpinBox, QTableWidget, QTableWidgetItem, QTextEdit, QVBoxLayout, QWidget,
)

from config import PHOTO_DIR, TEMPLATES_DIR, EXPORT_DIR, SHOPEE_MAX_IMAGE_BYTES, AI_PROVIDER_CONFIG_PATH
from database import db, all_settings, sync_variant_weight_from_colors
from importers.bambu_3mf import parse_print_file, ThreeMFError, ThreeMFNotSlicedError, aggregate_plate_filaments
from services.reporting import variant_unit_cost
from services.makerworld import fetch_makerworld, download_image, MakerWorldError
from services.photo_processor import process_marketplace_image, process_marketplace_image_diagnostic, MARKETPLACE_WHITE_PRESET
from services.photo_host import upload_cloudinary_unsigned, PhotoHostError
from services.ad_copy import clean_model_name, generate_seo_title, generate_description, infer_marketplace_name, suggest_shopee_category
from services.shopee_export import export_shopee_template, ShopeeExportError
from services.ai_photo_plan import build_standard_plan
from services.ai_router import ensure_provider_config, enrich_jobs, router_summary
from services.ai_listing_text import generate_listing_with_ai, classify_marketplace_source_photo
from services.ai_image_provider import process_marketplace_image_external_first, external_image_edit, last_image_status
from services.forgeon_local_editor import process_local, render_mask, image_dhash, hash_distance, compare_local_models
from services.ad_copy import generate_seo_title, generate_description, suggest_shopee_category


def _brl(v):
    s=f"{float(v or 0):,.2f}".replace(",","X").replace(".",",").replace("X",".")
    return "R$ "+s


def _norm(text: str) -> str:
    s=unicodedata.normalize("NFKD",str(text or "")).encode("ascii","ignore").decode("ascii").lower()
    s=re.sub(r"[^a-z0-9]+"," ",s)
    return re.sub(r"\s+"," ",s).strip()




_CHARACTER_HINTS = [
    ("rouge", "Rouge the Bat"),
    ("metal sonic", "Metal Sonic"),
    ("shadow", "Shadow the Hedgehog"),
    ("knuckles", "Knuckles the Echidna"),
    ("tails", "Tails"),
    ("amy", "Amy Rose"),
    ("silver", "Silver the Hedgehog"),
    ("werehog", "Sonic Werehog"),
    ("sonic", "Sonic the Hedgehog"),
]


def _best_ptbr_name(result) -> str:
    if result is None:
        return "Personagem"
    title = getattr(result, "title", "") or ""
    tags = list(getattr(result, "tags", []) or [])
    desc = getattr(result, "description", "") or ""
    name = infer_marketplace_name(title, tags, desc)
    return clean_model_name(name) or "Personagem"


def _variation_block(text: str) -> str:
    raw = str(text or "").strip()
    if not raw:
        return ""
    lines = [ln.strip(" •-	") for ln in raw.replace(";", "\n").splitlines() if ln.strip()]
    if not lines:
        return ""
    return "\n\nVariações disponíveis:\n" + "\n".join(f"• {ln}" for ln in lines)

def _pricing(weight_g: float, hours: float, packaging: float, other: float, settings: dict):
    filament=weight_g*float(settings.get("filament_price_kg",0) or 0)/1000
    energy=hours*(float(settings.get("printer_power_w",0) or 0)/1000)*float(settings.get("energy_price_kwh",0) or 0)
    machine=hours*float(settings.get("machine_hour_cost",0) or 0)
    labor=float(settings.get("labor_cost",0) or 0)
    subtotal=filament+energy+machine+labor+other
    failure=subtotal*(float(settings.get("failure_rate_pct",0) or 0)/100)
    total=subtotal+failure+packaging
    pre_fee=total*(1+float(settings.get("markup_pct",0) or 0)/100)
    fee=float(settings.get("shopee_fee_pct",0) or 0)/100
    suggested=pre_fee/(1-fee) if 0<=fee<1 else 0
    profit=suggested-(suggested*fee)-total
    return {"filament":filament,"energy":energy,"machine":machine,"labor":labor,"failure":failure,
            "total":total,"suggested":suggested,"profit":profit}


def _is_gallery_product_photo(path: Path, source_url: str = "") -> tuple[bool, str]:
    raw = f"{path.name} {source_url}".lower()
    blocked_terms = (
        "plate", "parts", "part_", "exploded", "assembly", "sprue",
        "alpha", "mask", "component", "pieces", "pecas", "peca", "filament"
    )
    if any(term in raw for term in blocked_terms):
        return False, "arquivo/URL parece peca solta ou imagem tecnica"
    try:
        img = Image.open(path)
        img.load()
    except Exception as e:
        return False, f"nao consegui validar a imagem: {e}"
    if min(img.size) < 500:
        return False, "imagem muito pequena; parece miniatura"
    try:
        rgba = img.convert('RGBA')
        alpha = rgba.getchannel('A')
        if alpha.getextrema() != (255, 255):
            return False, "imagem com transparencia/alpha; parece asset de peca e nao foto principal"
    except Exception:
        pass
    return True, "ok"



def _tight_nonwhite_crop(path: Path, mask_path: str | Path | None = None) -> Image.Image:
    img = Image.open(path).convert('RGB')
    bbox = None
    if mask_path and Path(str(mask_path)).exists():
        try:
            alpha = Image.open(mask_path).convert('L').point(lambda p: 255 if p >= 18 else 0)
            if alpha.size == img.size:
                bbox = alpha.getbbox()
        except Exception:
            bbox = None
    if not bbox:
        bg = Image.new('RGB', img.size, (255, 255, 255))
        diff = ImageChops.difference(img, bg).convert('L').point(lambda p: 255 if p > 8 else 0)
        bbox = diff.getbbox()
    if bbox:
        left, top, right, bottom = bbox
        box_w = max(1, right-left); box_h = max(1, bottom-top)
        pad_x = max(16, int(box_w * 0.04))
        pad_top = max(18, int(box_h * 0.05))
        pad_bottom = max(28, int(box_h * 0.07))
        left = max(0, left - pad_x)
        top = max(0, top - pad_top)
        right = min(img.width, right + pad_x)
        bottom = min(img.height, bottom + pad_bottom)
        img = img.crop((left, top, right, bottom))
    return img


def _save_shopee_jpg(img: Image.Image, destination: Path):
    destination.parent.mkdir(parents=True, exist_ok=True)
    for quality in (93, 90, 88, 86, 84, 82, 80, 78, 75):
        img.save(destination, 'JPEG', quality=quality, optimize=True, progressive=True)
        try:
            if destination.stat().st_size <= SHOPEE_MAX_IMAGE_BYTES:
                break
        except OSError:
            break


def _compose_single_white_from_file(source_path: str | Path, destination: Path, canvas_size: int = 1600, fill: float = 0.95, mask_path: str | Path | None = None):
    img = _tight_nonwhite_crop(Path(source_path), mask_path)
    canvas = Image.new('RGB', (canvas_size, canvas_size), (255, 255, 255))
    max_w = int(canvas_size * fill)
    max_h = int(canvas_size * fill)
    scale = min(max_w / max(1, img.width), max_h / max(1, img.height))
    img = img.resize((max(1, int(img.width * scale)), max(1, int(img.height * scale))), Image.Resampling.LANCZOS)
    x = (canvas_size - img.width) // 2
    y = max(10, (canvas_size - img.height) // 2 - int(canvas_size * 0.02))
    canvas.paste(img, (x, y))
    _save_shopee_jpg(canvas, destination)


def _compose_dual_white_from_files(source_paths: list[str], destination: Path, canvas_size: int = 1600, fill: float = 0.95, mask_paths: list[str] | None = None):
    mask_paths = list(mask_paths or [])
    imgs = []
    for i, pth in enumerate(source_paths[:2]):
        if str(pth).strip():
            mp = mask_paths[i] if i < len(mask_paths) else None
            imgs.append(_tight_nonwhite_crop(Path(pth), mp))
    if not imgs:
        raise ValueError('sem imagens para capa dupla')
    if len(imgs) == 1:
        return _compose_single_white_from_file(source_paths[0], destination, canvas_size, fill)
    canvas = Image.new('RGB', (canvas_size, canvas_size), (255, 255, 255))
    primary, secondary = imgs[0], imgs[1]
    p_h = int(canvas_size * 0.92); s_h = int(canvas_size * 0.76)
    p_scale = p_h / max(1, primary.height); s_scale = s_h / max(1, secondary.height)
    primary = primary.resize((max(1,int(primary.width*p_scale)), max(1,int(primary.height*p_scale))), Image.Resampling.LANCZOS)
    secondary = secondary.resize((max(1,int(secondary.width*s_scale)), max(1,int(secondary.height*s_scale))), Image.Resampling.LANCZOS)
    gap = max(8, int(canvas_size*0.010))
    max_total = int(canvas_size*0.97)
    current = primary.width + secondary.width + gap
    if current > max_total:
        shrink = max_total / current
        primary = primary.resize((max(1,int(primary.width*shrink)), max(1,int(primary.height*shrink))), Image.Resampling.LANCZOS)
        secondary = secondary.resize((max(1,int(secondary.width*shrink)), max(1,int(secondary.height*shrink))), Image.Resampling.LANCZOS)
    total = primary.width + secondary.width + gap
    x = max(4,(canvas_size-total)//2); baseline=int(canvas_size*0.965)
    canvas.paste(primary,(x,max(4,baseline-primary.height)))
    x += primary.width + gap
    canvas.paste(secondary,(x,max(4,baseline-secondary.height)))
    _save_shopee_jpg(canvas,destination)


def _creator_background_is_white(path: Path) -> tuple[bool, str]:
    """Conservative, cheap detection; unknown backgrounds still use segmentation.

    Uses the perimeter and corner colors, not character colors. A photo can
    legitimately contain multiple characters (e.g. different colors) already.
    """
    try:
        from PIL import ImageOps
        im = ImageOps.exif_transpose(Image.open(path)).convert('RGB')
        im.thumbnail((180, 180), Image.Resampling.BILINEAR)
        w, h = im.size
        if w < 30 or h < 30:
            return False, 'imagem pequena'
        px = im.load()
        white = lambda c: min(c) >= 236 and max(c) - min(c) <= 22
        stripe = max(2, int(min(w, h) * .045))
        samples=[]
        corners=[]
        for y in range(h):
            for x in range(w):
                if x < stripe or y < stripe or x >= w-stripe or y >= h-stripe:
                    samples.append(white(px[x,y]))
                if (x < stripe or x >= w-stripe) and (y < stripe or y >= h-stripe):
                    corners.append(white(px[x,y]))
        edge_ratio = sum(samples)/max(1,len(samples))
        corner_ratio = sum(corners)/max(1,len(corners))
        ok = edge_ratio >= .91 and corner_ratio >= .93
        return ok, f'fundo branco: bordas {edge_ratio:.0%}, cantos {corner_ratio:.0%}'
    except Exception as exc:
        return False, f'nao foi possivel aferir fundo branco ({type(exc).__name__})'


def _preserve_creator_white_photo(original: Path, dest: Path, canvas_size: int = 1600) -> dict:
    """Place the UNMODIFIED creator picture into Shopee's square canvas.

    No rembg, no invented second pose, no saturation/hue/shadow changes and no
    destructive crop. Multi-character source photos remain multi-character.
    """
    from PIL import ImageOps
    im=ImageOps.exif_transpose(Image.open(original)).convert('RGB')
    max_size=int(canvas_size*.95)
    fitted=ImageOps.contain(im, (max_size,max_size), method=Image.Resampling.LANCZOS)
    canvas=Image.new('RGB',(canvas_size,canvas_size),(255,255,255))
    canvas.paste(fitted,((canvas_size-fitted.width)//2,(canvas_size-fitted.height)//2))
    _save_shopee_jpg(canvas,dest)
    return {'success':True,'status':'ORIGINAL OK','method':'makerworld/creator-white-no-ai',
            'message':'Foto original da galeria do criador preservada. Sem recorte, sem dupla artificial e sem IA.',
            'output_path':str(dest),'mask_path':'','metrics':{},'traceback':''}


def _creator_images_similar(path: Path, fingerprints: list) -> bool:
    """Reject only true duplicates from the creator gallery.

    IMPORTANT: do not collapse different poses, angles or color variants just
    because they look visually similar on a white background. The previous
    heuristic was too aggressive for plush/flexi products and could leave only
    one approved photo. Here we only block exact or near-exact file duplicates.
    """
    try:
        raw = path.read_bytes()
        digest = hashlib.sha1(raw).hexdigest()
        if digest in fingerprints:
            return True
        fingerprints.append(digest)
    except Exception:
        return False
    return False


def _build_local_marketplace_set(source_items: list[dict], edited_dir: Path) -> list[dict]:
    """One real creator photo per slot. NEVER auto-combine multiple sources."""
    valid=[]
    seen=set()
    for item in source_items:
        p=Path(str(item.get('edited_path') or ''))
        if not p.is_file() or str(item.get('status') or '').upper() in {'FALHOU','ERRO','REJEITADA','EXTERNA FALHOU'}:
            continue
        key=str(item.get('original_path') or '').lower()
        if key and key not in seen:
            seen.add(key);valid.append(dict(item))
    if not valid:
        return source_items

    outputs=[]
    # Prefer an already APPROVED source photo for the cover. Still expose
    # suspicious originals in the table for manual correction, unselected.
    approved=[x for x in valid if 'REVISAR' not in str(x.get('status') or '').upper()]
    rejected=[x for x in valid if 'REVISAR' in str(x.get('status') or '').upper()]
    ordered=approved+rejected
    # A real creator photo may already show multiple characters. Never add
    # another artificial duo or resize different color variants together.
    for item in ordered[:6]:
        row=dict(item)
        position=len(outputs)+1
        if position==1:
            cover=edited_dir/'foto_01_marketplace.jpg'
            src=Path(str(item.get('edited_path') or ''))
            if src.resolve()!=cover.resolve():
                shutil.copy2(src,cover)
            row.update(edited_path=str(cover),method=str(item.get('method') or 'original')+' /capa-original',
                       diagnostic=(str(item.get('diagnostic') or '')+' | Capa = melhor foto ORIGINAL do criador. Nenhuma dupla adicional.'),
                       composed=False)
        row.update(position=position,selected=0 if 'REVISAR' in str(row.get('status') or '').upper() else 1)
        outputs.append(row)

    # Special images 7-9 are optional. Do not clutter the photo table with
    # empty placeholders and never fabricate duplicates to fill nine slots.
    return outputs


class _AdMediaWorker(QObject):
    finished=Signal(object)
    error=Signal(str)
    progress=Signal(str)

    def __init__(self,url,base_dir,mode="local_isnet"):
        super().__init__();self.url=url;self.base_dir=Path(base_dir);self.mode=mode

    def run(self):
        try:
            self.progress.emit("Consultando dados públicos do MakerWorld...")
            result=fetch_makerworld(self.url)
            product_name=_best_ptbr_name(result)
            originals=self.base_dir/"originais";edited=self.base_dir/"editadas"
            originals.mkdir(parents=True,exist_ok=True);edited.mkdir(parents=True,exist_ok=True)
            source_items=[];failures=[];seen_photos=[]
            approved=0
            total_candidates=max(1,len(result.images))
            for raw_index,url in enumerate(result.images,1):
                if approved>=6:
                    break
                self.progress.emit(f"Avaliando foto candidata {raw_index}/{total_candidates} do MakerWorld...")
                try:
                    low=url.lower().split("?",1)[0]
                    ext=Path(low).suffix if Path(low).suffix in {".jpg",".jpeg",".png",".webp"} else ".img"
                    temp_orig=originals/f"candidata_{raw_index:02d}{ext}"
                    download_image(url,temp_orig)
                    ok_src,reason=_is_gallery_product_photo(temp_orig,url)
                    if not ok_src:
                        failures.append(f"Candidata {raw_index} ignorada: {reason}")
                        try:
                            temp_orig.unlink(missing_ok=True)
                        except Exception:
                            pass
                        continue
                    already_white,white_evidence=_creator_background_is_white(temp_orig)
                    if self.mode == 'external_api' and not already_white:
                        self.progress.emit(f"Validando fonte {raw_index} com IA externa (pode cobrar)...")
                        vision=classify_marketplace_source_photo(str(temp_orig), product_name)
                        if not vision.get('accepted'):
                            failures.append(f"Candidata {raw_index} rejeitada: {vision.get('reason') or 'visão externa indisponível'}")
                            continue
                    else:
                        # Preserve different COLOR variations, even if their
                        # grayscale poses would have the same perceptual hash.
                        if _creator_images_similar(temp_orig, seen_photos):
                            failures.append(f'Candidata {raw_index}: arquivo praticamente identico ignorado')
                            continue
                    approved += 1
                    orig=originals/f"foto_{approved:02d}{ext}"
                    out=edited/f"fonte_{approved:02d}_marketplace.jpg"
                    try:
                        temp_orig.replace(orig)
                    except Exception:
                        shutil.copy2(temp_orig,orig)
                        try:
                            temp_orig.unlink(missing_ok=True)
                        except Exception:
                            pass
                    is_white, white_info=_creator_background_is_white(orig)
                    if is_white:
                        self.progress.emit(f"Foto {approved}/6 ja tem fundo branco. Preservando foto do criador sem IA...")
                        diag=_preserve_creator_white_photo(orig,out)
                        diag['message']+=' '+white_info
                    elif self.mode == 'external_api':
                        self.progress.emit(f"Foto {approved}/6: edição EXTERNA (pode cobrar)...")
                        diag=process_marketplace_image_external_first(orig,out,1600,0.95,product_name=product_name,allow_local_fallback=False)
                    else:
                        self.progress.emit(f"Foto {approved}/6: segmentação LOCAL gratuita ({self.mode})...")
                        diag=process_local(orig,out,self.mode)
                    item={"position":approved,"source_url":url,"original_path":str(orig),"edited_path":str(out) if diag.get("success") else "","public_url":"","selected":1 if diag.get("success") and not diag.get("metrics",{}).get("review") else 0,
                          "status":diag.get("status","FALHOU"),"method":diag.get("method","—"),"diagnostic":diag.get("message","") or "","traceback":diag.get("traceback","") or "","mask_path":diag.get("mask_path","")}
                    source_items.append(item)
                    if not diag.get("success"):
                        failures.append(f"Foto base {approved}: {diag.get('message') or 'recorte por IA falhou'}")
                except Exception as e:
                    failures.append(f"Candidata {raw_index}: {e}")
            images=_build_local_marketplace_set(source_items, edited)
            # Transparent provenance log for diagnosis. No tokens, billing data,
            # private keys or user reviews are included.
            manifest={"version":"0.5.6","model_id":result.model_id,
                      "profile_id":result.profile_id,"title":result.title,
                      "creator":result.creator,"gallery_only":True,
                      "creator_gallery_urls":list(result.images),"available_creator_images":len(result.images),
                      "photos":[{key:item.get(key,"") for key in
                                 ("position","source_url","original_path","edited_path","method","status","diagnostic")}
                                for item in source_items],
                      "warnings":failures}
            try:
                (self.base_dir/'galeria_criador_v056.json').write_text(
                    json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
            except Exception:
                logging.exception('could not write creator gallery manifest')
            # Photos 7–9 are optional, and never spend API credits in the free mode.
            if self.mode == 'external_api' and source_items:
                special = [(7, "hand", 0), (8, "hand", 1 if len(source_items)>1 else 0), (9, "scene", 1 if len(source_items)>1 else 0)]
                for slot,style,src_index in special:
                    src_item=source_items[min(src_index,len(source_items)-1)]
                    src_path=Path(str(src_item.get("original_path") or ""))
                    out=edited/f"foto_{slot:02d}_marketplace.jpg"
                    if not src_path.exists():
                        continue
                    self.progress.emit(f"Gerando foto {slot}/9 com IA externa ({'mão' if style=='hand' else 'cenário'})...")
                    ext=external_image_edit(src_path,out,style=style,product_name=product_name)
                    target=next((x for x in images if int(x.get('position') or 0)==slot),None)
                    if target is None:
                        target={'position':slot,'selected':0,'edited_path':'','original_path':str(src_path),'status':'PENDENTE'}
                        images.append(target)
                    if ext.get("success"):
                        target.update({
                            "edited_path":str(out),"status":ext.get("status","EXTERNA OK"),"method":ext.get("method","external"),
                            "diagnostic":ext.get("message","") or "","traceback":ext.get("traceback","") or "","mask_path":"","selected":1,"public_url":"",
                            "original_path":str(src_path),"source_url":str(src_item.get("source_url") or "")
                        })
                    else:
                        details=" | ".join(ext.get("attempts") or [])[-1200:]
                        failures.append(f"Foto {slot}: IA externa falhou ({ext.get('message') or 'sem detalhe'}) {details}")
                        if target is not None:
                            target.update({
                                "edited_path":"","status":"EXTERNA FALHOU","method":"external/failed",
                                "diagnostic":ext.get("message","") or "IA externa falhou",
                                "traceback":"\n".join(ext.get("attempts") or []),"mask_path":"","selected":0,"public_url":"",
                                "original_path":str(src_path),"source_url":str(src_item.get("source_url") or "")
                            })
            self.finished.emit({"result":result,"images":images,"failures":failures,"base_dir":str(self.base_dir)})
        except Exception as e:
            logging.exception("makerworld/ad media worker")
            self.error.emit(str(e))


class _LocalCompareWorker(QObject):
    finished=Signal(object)
    error=Signal(str)

    def __init__(self, source:Path, compare_dir:Path):
        super().__init__()
        self.source=Path(source)
        self.compare_dir=Path(compare_dir)

    def run(self):
        try:
            self.finished.emit(compare_local_models(self.source,self.compare_dir))
        except Exception as exc:
            logging.exception('Forgeon A/B compare')
            self.error.emit(f'{type(exc).__name__}: {exc}')


class _AdReprocessWorker(QObject):
    finished = Signal(object)
    progress = Signal(str)
    error = Signal(str)

    def __init__(self, jobs, mode, product_name):
        super().__init__()
        self.jobs = [dict(job) for job in jobs]
        self.mode = mode
        self.product_name = product_name

    def run(self):
        results=[]
        for job in self.jobs:
            row=job['row']
            orig=Path(str(job.get('original_path') or ''))
            out=Path(job['output_path'])
            self.progress.emit(f'Reprocessando foto {row+1} de {len(self.jobs)} selecionada(s)...')
            if not orig.is_file():
                results.append({'row': row, 'success': False, 'message': 'Foto original nao encontrada'})
                continue
            try:
                out.parent.mkdir(parents=True, exist_ok=True)
                white, _ = _creator_background_is_white(orig)
                if white and job['slot'] not in (7,8,9):
                    diag=_preserve_creator_white_photo(orig,out)
                elif self.mode != 'external_api':
                    diag=process_local(orig,out,self.mode)
                elif job['slot'] in (7,8):
                    diag=external_image_edit(orig,out,style='hand',product_name=self.product_name)
                elif job['slot']==9:
                    diag=external_image_edit(orig,out,style='scene',product_name=self.product_name)
                else:
                    diag=process_marketplace_image_external_first(orig,out,1600,0.95,product_name=self.product_name,allow_local_fallback=False)
                results.append({'row':row,'out':str(out), **diag})
            except Exception as exc:
                results.append({'row':row, 'success':False,'message':f'{type(exc).__name__}: {exc}'})
        self.finished.emit(results)

class _AdAiImageTestWorker(QObject):
    finished = Signal(object)
    def __init__(self, source, destination, product_name):
        super().__init__()
        self.source=Path(source);self.destination=Path(destination);self.product_name=product_name
    def run(self):
        try:
            result=external_image_edit(self.source,self.destination,style='white',product_name=self.product_name)
            self.finished.emit({'result':result,'out':str(self.destination)})
        except Exception as exc:
            self.finished.emit({'result':{'success':False,'message':f'{type(exc).__name__}: {exc}'},'out':str(self.destination)})

class _AdSeoExternalWorker(QObject):
    finished = Signal(object)
    def __init__(self, args):
        super().__init__()
        self.args=dict(args)
    def run(self):
        try:
            self.finished.emit(generate_listing_with_ai(**self.args))
        except Exception as exc:
            self.finished.emit({'provider_used':'','provider_status':'failed','error':str(exc)})

class _AdUploadWorker(QObject):
    updated=Signal(object)
    finished=Signal(object)
    error=Signal(str)
    progress=Signal(str)

    def __init__(self,images,cloud_name,preset):
        super().__init__();self.images=[dict(x) for x in images];self.cloud_name=cloud_name;self.preset=preset

    def run(self):
        try:
            out=[];selected=[x for x in self.images if x.get("selected",1)];total=max(1,len(selected));done=0
            for index,item in enumerate(self.images):
                data=dict(item)
                if not data.get("selected",1):
                    out.append(data);continue
                done+=1
                if not str(data.get("public_url") or "").strip():
                    path=str(data.get("edited_path") or "").strip()
                    if not path:
                        raise PhotoHostError(f"Foto {done} não tem arquivo editado.")
                    self.progress.emit(f"Enviando foto {done}/{total} para hospedagem...")
                    data["public_url"]=upload_cloudinary_unsigned(path,self.cloud_name,self.preset)
                    self.images[index]=data
                    self.updated.emit([dict(x) for x in self.images])
                out.append(data)
            self.finished.emit(out)
        except Exception as e:
            logging.exception("photo upload worker")
            self.error.emit(str(e))


class _PhotoClipboardFilter(QObject):
    """Intercept paste only on the visible photo page, outside text editors."""
    def __init__(self,window,page,callback):
        super().__init__(window);self.window=window;self.page=page;self.callback=callback

    def eventFilter(self,watched,event):
        if event.type() not in (QEvent.ShortcutOverride,QEvent.KeyPress):return False
        if not event.matches(QKeySequence.StandardKey.Paste):return False
        if not self.page.isVisible() or not self.page.isEnabled():return False
        if QApplication.activeModalWidget() or QApplication.activePopupWidget():return False
        focus=QApplication.focusWidget()
        if focus is None or not (focus is self.window or self.window.isAncestorOf(focus)):return False
        node=focus
        while node is not None and node is not self.window:
            if isinstance(node,(QLineEdit,QTextEdit,QPlainTextEdit,QAbstractSpinBox,QComboBox)):return False
            node=node.parentWidget()
        mime=QApplication.clipboard().mimeData()
        if mime is None:return False
        local_files=mime.hasUrls() and any(url.isLocalFile() and url.host() in ('','localhost') for url in mime.urls())
        if not mime.hasImage() and not local_files:return False
        event.accept()
        if event.type()==QEvent.KeyPress and not event.isAutoRepeat():self.callback()
        return True


class AdToolsMixin:
    # ----------------------------- CRIAÇÃO DE ANÚNCIO -----------------------------
    def make_ad_creator(self):
        w,l=self.shell(
            "Criação de anúncio",
            "Preencha o produto, revise as fotos e exporte seu anúncio."
        )
        page_layout=l
        self.ad_steps=QTabWidget();self.ad_steps.setDocumentMode(True);page_layout.addWidget(self.ad_steps,1)
        step_layouts=[]
        for title in ("1. Produto e preço","2. Fotos","3. Texto e exportação"):
            scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setFrameShape(QFrame.NoFrame)
            body=QWidget();layout=QVBoxLayout(body);layout.setContentsMargins(12,16,12,16);layout.setSpacing(16)
            scroll.setWidget(body);self.ad_steps.addTab(scroll,title);step_layouts.append(layout)
        product_layout,photo_layout,text_layout=step_layouts
        l=product_layout

        handoff=QFrame();handoff.setObjectName("Panel");handoff_layout=QVBoxLayout(handoff)
        heading=QLabel("Fotos no ChatGPT");heading.setObjectName("SectionTitle");handoff_layout.addWidget(heading)
        hint=QLabel("Instale e pareie a extensao no seu Opera GX uma vez. Deixe a conversa Fotos aberta e configure o link dela. O envio usa essa aba existente e seu login atual; nao abre outra janela.");hint.setWordWrap(True);hint.setObjectName("Hint");handoff_layout.addWidget(hint)
        bar=QHBoxLayout()
        for index,(text,callback) in enumerate([("Configurar conversa Fotos",self._ad_configure_photo_chat),("Pasta da extensao",self._ad_open_photo_extension),("Copiar pareamento da extensao",self._ad_copy_photo_extension_pairing),("Selecionar fotos e enviar",self._ad_prepare_chatgpt),("Enviar fotos da galeria",self._ad_prepare_gallery_chatgpt),("Copiar prompt",self._ad_copy_photo_prompt),("Cancelar espera",self._ad_cancel_photo_send),("Copiar diagnostico do envio",self._ad_copy_photo_diagnostic),("Abrir pasta da tarefa",self._ad_open_photo_job),("Importar resultados MCP",self._ad_import_mcp_results)]):
            if index in (3,6,9):handoff_layout.addLayout(bar);bar=QHBoxLayout()
            button=QPushButton(text);button.setObjectName("Secondary");button.clicked.connect(callback);bar.addWidget(button)
        handoff_layout.addLayout(bar)
        self.ad_chatgpt_status=QLabel("Nenhuma tarefa preparada. Nenhuma mensagem enviada.");self.ad_chatgpt_status.setWordWrap(True);self.ad_chatgpt_status.setObjectName("Hint");handoff_layout.addWidget(self.ad_chatgpt_status)
        remote=QHBoxLayout()
        for text,callback in [("Iniciar ponte HTTPS (teste)",self._ad_start_remote_bridge),("Copiar URL MCP",self._ad_copy_remote_url),("Copiar codigo de acesso",self._ad_copy_bridge_code)]:
            button=QPushButton(text);button.setObjectName("Secondary");button.clicked.connect(callback);remote.addWidget(button)
        handoff_layout.addLayout(remote)
        bridge_hint=QLabel("A extensao local funciona separada da ponte MCP. Usa a aba ja aberta da conversa configurada, sem criar abas. A edicao depende da sua conta ChatGPT; nesta versao baixe os resultados e use Importar fotos prontas (GPT).");bridge_hint.setWordWrap(True);bridge_hint.setObjectName("Hint");handoff_layout.addWidget(bridge_hint)
        photo_layout.addWidget(handoff)
        self.ad_active_photo_job=None
        self.ad_upload_then_export=False
        source=QFrame();source.setObjectName("Panel");sv=QVBoxLayout(source);sv.setContentsMargins(14,12,14,12)
        sg=QGridLayout()
        self.ad_mw_url=QLineEdit();self.ad_mw_url.setPlaceholderText("https://makerworld.com/.../models/...")
        self.ad_analyze_btn=QPushButton("IMPORTAR FOTOS DO CRIADOR");self.ad_analyze_btn.clicked.connect(self._ad_analyze_link)
        self.ad_add_photos_btn=QPushButton("Importar fotos prontas (GPT)");self.ad_add_photos_btn.setObjectName("Secondary");self.ad_add_photos_btn.clicked.connect(self._ad_import_ready_photos)
        self.ad_source_status=QLabel("Aguardando link do MakerWorld.");self.ad_source_status.setObjectName("Hint");self.ad_source_status.setWordWrap(True)
        sg.addWidget(QLabel("Link MakerWorld"),0,0);sg.addWidget(self.ad_mw_url,0,1,1,4);sg.addWidget(self.ad_analyze_btn,0,5);sg.addWidget(self.ad_add_photos_btn,0,6)
        sg.addWidget(self.ad_source_status,1,1,1,6)
        self.ad_photo_mode=QComboBox()
        self.ad_photo_mode.addItem('LOCAL GRATIS - ISNet (sem API)', 'local_isnet')
        self.ad_photo_mode.addItem('LOCAL QUALIDADE - BiRefNet Lite (download 1x)', 'local_birefnet_lite')
        self.ad_photo_mode.addItem('EXTERNA PAGA - Gemini/OpenAI', 'external_api')
        self.ad_photo_mode.setToolTip('Modos locais nao enviam imagem para Gemini/OpenAI. BiRefNet baixa o modelo uma vez. EXTERNA pode ter custos.')
        sg.addWidget(QLabel('Modo de fotos'),2,0)
        sg.addWidget(self.ad_photo_mode,2,1,1,3)
        sg.addWidget(QLabel('No modo local, 7-9 são opcionais e ficam pendentes (sem fotos inventadas).'),2,4,1,3)
        self.ad_paste_photo_btn=QPushButton("Colar imagem (Ctrl+V)");self.ad_paste_photo_btn.setObjectName("Secondary");self.ad_paste_photo_btn.clicked.connect(self._ad_paste_photo)
        sg.addWidget(self.ad_paste_photo_btn,3,0,1,2)
        paste_hint=QLabel("Copie a imagem no navegador ou com a captura de tela e cole aqui. Arquivos de imagem copiados no Explorador tambem sao aceitos. Sem novo recorte.");paste_hint.setObjectName("Hint");paste_hint.setWordWrap(True);sg.addWidget(paste_hint,3,2,1,5)
        self.ad_photo_paste_filter=_PhotoClipboardFilter(self,self.ad_steps.widget(1),self._ad_paste_photo)
        QApplication.instance().installEventFilter(self.ad_photo_paste_filter)
        sv.addLayout(sg);photo_layout.addWidget(source)

        middle=QGridLayout()
        prod=QFrame();prod.setObjectName("Panel");pf=QFormLayout(prod);pf.setContentsMargins(14,12,14,12)
        self.ad_product_combo=QComboBox();self.ad_product_combo.setMinimumWidth(390);self.ad_product_combo.currentIndexChanged.connect(self._ad_product_changed)
        self.ad_product_name=QLineEdit();self.ad_sku=QLineEdit();self.ad_material=QComboBox();self.ad_material.addItems(["PLA","PETG","ABS","ASA","TPU"])
        self.ad_product_height=QDoubleSpinBox();self.ad_product_height.setRange(0,1000);self.ad_product_height.setDecimals(1);self.ad_product_height.setSuffix(" cm")
        self.ad_print_path=QLineEdit();self.ad_print_path.setReadOnly(True);self.ad_print_path.setPlaceholderText("3MF fatiado, .gcode.3mf ou G-code")
        pick=QPushButton("CARREGAR 3MF / G-CODE");pick.clicked.connect(self._ad_pick_print_file)
        file_row=QWidget();fh=QHBoxLayout(file_row);fh.setContentsMargins(0,0,0,0);fh.addWidget(self.ad_print_path,1);fh.addWidget(pick)
        self.ad_apply_product=QCheckBox("Atualizar peso, horas e cores do produto");self.ad_apply_product.setChecked(True)
        self.ad_create_product=QCheckBox("Cadastrar produto se ainda não existir");self.ad_create_product.setChecked(True)
        pf.addRow("Produto base no ERP",self.ad_product_combo);pf.addRow("Nome do produto",self.ad_product_name);pf.addRow("SKU do anúncio",self.ad_sku);pf.addRow("Material",self.ad_material);pf.addRow("Altura do boneco",self.ad_product_height);pf.addRow("Arquivo de impressão",file_row);pf.addRow("",self.ad_apply_product);pf.addRow("",self.ad_create_product)
        middle.addWidget(prod,0,0)

        price=QFrame();price.setObjectName("Panel");pg=QGridLayout(price);pg.setContentsMargins(14,12,14,12)
        self.ad_weight=QDoubleSpinBox();self.ad_weight.setRange(0,100000);self.ad_weight.setDecimals(2);self.ad_weight.setSuffix(" g")
        self.ad_hours=QDoubleSpinBox();self.ad_hours.setRange(0,10000);self.ad_hours.setDecimals(2);self.ad_hours.setSuffix(" h")
        self.ad_price=QDoubleSpinBox();self.ad_price.setRange(0,1000000);self.ad_price.setDecimals(2);self.ad_price.setPrefix("R$ ")
        self.ad_stock=QSpinBox();self.ad_stock.setRange(0,10000000)
        self.ad_length=QDoubleSpinBox();self.ad_width=QDoubleSpinBox();self.ad_height=QDoubleSpinBox()
        for sp in (self.ad_length,self.ad_width,self.ad_height):sp.setRange(0,100000);sp.setDecimals(2);sp.setSuffix(" cm")
        self.ad_cost_summary=QLabel("Carregue o arquivo de impressão para calcular o preço.");self.ad_cost_summary.setObjectName("Hint");self.ad_cost_summary.setWordWrap(True)
        labels=[("Peso",self.ad_weight),("Horas",self.ad_hours),("Preço Shopee",self.ad_price),("Estoque",self.ad_stock),("Comprimento",self.ad_length),("Largura",self.ad_width),("Altura do pacote",self.ad_height)]
        for i,(lab,sp) in enumerate(labels):pg.addWidget(QLabel(lab),i,0);pg.addWidget(sp,i,1)
        pg.addWidget(self.ad_cost_summary,7,0,1,2);pg.setColumnStretch(1,1)
        for sp in (self.ad_weight,self.ad_hours):sp.valueChanged.connect(self._ad_recalculate)
        middle.addWidget(price,0,1);middle.setColumnStretch(0,1);middle.setColumnStretch(1,1);l.addLayout(middle)

        content=QFrame();content.setObjectName("Panel");cg=QGridLayout(content);cg.setContentsMargins(14,12,14,12)
        self.ad_title=QLineEdit();self.ad_title.setMaxLength(120)
        self.ad_description=QTextEdit();self.ad_description.setMinimumHeight(115)
        self.ad_variations=QTextEdit();self.ad_variations.setMinimumHeight(68);self.ad_variations.setPlaceholderText("Ex.: Metal Sonic; Kit com 2 bonecos; Versão clássica")
        self.ad_category=QLineEdit();self.ad_category.setPlaceholderText("Categoria Shopee sugerida / ID opcional")
        seo=QPushButton("GERAR / ATUALIZAR SEO + CATEGORIA");seo.setObjectName("Secondary");seo.clicked.connect(self._ad_generate_seo)
        self.ad_source_meta=QLabel("Fonte ainda não analisada.");self.ad_source_meta.setObjectName("Hint");self.ad_source_meta.setWordWrap(True)
        cg.addWidget(QLabel("Título SEO"),0,0);cg.addWidget(self.ad_title,0,1,1,3);cg.addWidget(seo,0,4)
        cg.addWidget(QLabel("Descrição"),1,0);cg.addWidget(self.ad_description,1,1,1,4)
        cg.addWidget(QLabel("Variações / Kit"),2,0);cg.addWidget(self.ad_variations,2,1,1,4)
        cg.addWidget(QLabel("Categoria"),3,0);cg.addWidget(self.ad_category,3,1);cg.addWidget(self.ad_source_meta,3,2,1,3)
        text_layout.addWidget(content)

        colors=QFrame();colors.setObjectName("Panel");cv=QVBoxLayout(colors);cv.setContentsMargins(14,10,14,10)
        cr=QHBoxLayout();ct=QLabel("CORES / GRAMAS DO ARQUIVO");ct.setStyleSheet("font-weight:800;color:#ff7a00");cr.addWidget(ct);cr.addStretch();cv.addLayout(cr)
        self.ad_colors_table=self.table(["Cor","Material","Gramas"],0);self.ad_colors_table.setMaximumHeight(145);cv.addWidget(self.ad_colors_table);l.addWidget(colors)

        imgs=QFrame();imgs.setObjectName("Panel");iv=QVBoxLayout(imgs);iv.setContentsMargins(14,10,14,10)
        ir=QHBoxLayout();it=QLabel("FOTOS PARA A SHOPEE");it.setStyleSheet("font-weight:800;color:#ff7a00");ir.addWidget(it);ir.addStretch();self.ad_image_hint=QLabel("Revise e aprove as fotos antes de exportar.");self.ad_image_hint.setObjectName("Hint");ir.addWidget(self.ad_image_hint);iv.addLayout(ir)
        advanced=QWidget();advanced_layout=QVBoxLayout(advanced);advanced_layout.setContentsMargins(0,0,0,0)
        self.ad_seo_ai_btn=QPushButton("SEO com IA externa (pode cobrar)");self.ad_seo_ai_btn.setObjectName("Secondary");self.ad_seo_ai_btn.clicked.connect(self._ad_generate_seo_external);advanced_layout.addWidget(self.ad_seo_ai_btn)
        auto_import=QPushButton("Importar originais e recortar");auto_import.setObjectName("Secondary");auto_import.clicked.connect(self._ad_add_local_photos);advanced_layout.addWidget(auto_import)
        tools=QHBoxLayout();self.ad_reprocess_btn=QPushButton("REPROCESSAR (MODO ESCOLHIDO)");self.ad_reprocess_btn.setObjectName("Secondary");self.ad_reprocess_btn.clicked.connect(self._ad_reprocess_images);tools.addWidget(self.ad_reprocess_btn);self.ad_view_btn=QPushButton("VER FOTO");self.ad_view_btn.setObjectName("Secondary");self.ad_view_btn.clicked.connect(self._ad_show_image);tools.addWidget(self.ad_view_btn);self.ad_mask_btn=QPushButton("VER MÁSCARA");self.ad_mask_btn.setObjectName("Secondary");self.ad_mask_btn.clicked.connect(self._ad_show_mask);tools.addWidget(self.ad_mask_btn);self.ad_diag_btn=QPushButton("VER DIAGNÓSTICO");self.ad_diag_btn.setObjectName("Secondary");self.ad_diag_btn.clicked.connect(self._ad_show_diagnostic);advanced_layout.addWidget(self.ad_diag_btn);self.ad_test_ai_btn=QPushButton("TESTAR IA EXTERNA");self.ad_test_ai_btn.setObjectName("Secondary");self.ad_test_ai_btn.clicked.connect(self._ad_test_external_ai);advanced_layout.addWidget(self.ad_test_ai_btn)
        tools.addStretch();iv.addLayout(tools)
        tools=QHBoxLayout()
        self.ad_fix_mask_btn=QPushButton('CORRIGIR MASCARA (GRATIS)');self.ad_fix_mask_btn.setObjectName('Secondary');self.ad_fix_mask_btn.clicked.connect(self._ad_fix_mask);tools.addWidget(self.ad_fix_mask_btn)
        self.ad_gallery_btn=QPushButton('GALERIA GRANDE');self.ad_gallery_btn.setObjectName('Secondary');self.ad_gallery_btn.clicked.connect(self._ad_show_gallery);tools.addWidget(self.ad_gallery_btn)
        self.ad_compare_btn=QPushButton('COMPARAR ISNET x BIREFNET');self.ad_compare_btn.setObjectName('Secondary');self.ad_compare_btn.clicked.connect(self._ad_compare_models);advanced_layout.addWidget(self.ad_compare_btn)
        self.ad_approve_btn=QPushButton('APROVAR FOTO REVISADA');self.ad_approve_btn.setObjectName('Secondary');self.ad_approve_btn.clicked.connect(self._ad_approve_review);tools.addWidget(self.ad_approve_btn)
        self.ad_rebuild_cover_btn=QPushButton('REFORMAR CAPA ORIGINAL');self.ad_rebuild_cover_btn.setObjectName('Secondary');self.ad_rebuild_cover_btn.clicked.connect(self._ad_rebuild_cover);tools.addWidget(self.ad_rebuild_cover_btn)
        tools.addStretch();iv.addLayout(tools)
        self.ad_view_hint=QLabel("Dica: compare ISNet x BiRefNet na mesma FOTO BASE; corrija a máscara, confira o recorte ampliado e aprove manualmente se aparecer LOCAL REVISAR. Capa dupla não é máscara editável.");self.ad_view_hint.setObjectName("Hint");self.ad_view_hint.setWordWrap(True);advanced_layout.addWidget(self.ad_view_hint)
        self.ad_plan_hint=QLabel(f"Galeria: só fotos realmente processadas. Slots 7-9 especiais ficam pendentes no modo grátis. Limite: {SHOPEE_MAX_IMAGE_BYTES/1_000_000:.1f} MB por imagem.");self.ad_plan_hint.setObjectName("Hint");self.ad_plan_hint.setWordWrap(True);advanced_layout.addWidget(self.ad_plan_hint)
        self.ad_ai_status=QLabel("IA: configurando integração...");self.ad_ai_status.setObjectName("Hint");self.ad_ai_status.setWordWrap(True);advanced_layout.addWidget(self.ad_ai_status);iv.addWidget(self.disclosure("Ferramentas avançadas e diagnóstico",advanced))
        manage=QHBoxLayout()
        for text,callback in [("Definir capa",lambda:self._ad_move_ready_photo(0)),("Subir",lambda:self._ad_move_ready_photo(-1)),("Descer",lambda:self._ad_move_ready_photo(1)),("Remover da galeria",self._ad_remove_ready_photos),("Hospedar fotos selecionadas",lambda:self._ad_start_photo_upload(False))]:
            button=QPushButton(text);button.setObjectName("Secondary");button.clicked.connect(callback);manage.addWidget(button)
        iv.addLayout(manage)
        flow=QLabel("Selecione ate 9 fotos prontas. A primeira selecionada sera a capa. Hospede para gerar URLs publicas; depois exporte a planilha. As imagens prontas nao passam por recorte automatico.");flow.setObjectName("Hint");flow.setWordWrap(True);iv.addWidget(flow)
        self.ad_images_table=QTableWidget(0,7);self.ad_images_table.setHorizontalHeaderLabels(["#","Prévia","Arquivo editado","Método","Status","URL pública","Usar"]);self.ad_images_table.verticalHeader().setVisible(False);self.ad_images_table.setAlternatingRowColors(True);self.ad_images_table.setSelectionBehavior(QAbstractItemView.SelectRows);self.ad_images_table.setEditTriggers(QAbstractItemView.DoubleClicked|QAbstractItemView.SelectedClicked);self.ad_images_table.horizontalHeader().setStretchLastSection(False);
        for c in (0,1,3,4,6):self.ad_images_table.horizontalHeader().setSectionResizeMode(c,QHeaderView.ResizeMode.ResizeToContents)
        self.ad_images_table.horizontalHeader().setSectionResizeMode(2,QHeaderView.ResizeMode.Stretch);self.ad_images_table.horizontalHeader().setSectionResizeMode(5,QHeaderView.ResizeMode.Stretch);self.ad_images_table.setMinimumHeight(420);self.ad_images_table.cellDoubleClicked.connect(lambda *_: self._ad_show_image());iv.addWidget(self.ad_images_table);photo_layout.addWidget(imgs,1)

        actions=QHBoxLayout();self.ad_state=QLabel("Pronto");self.ad_state.setObjectName("Hint");actions.addWidget(self.ad_state);actions.addStretch()
        save=QPushButton("SALVAR RASCUNHO");save.setObjectName("Secondary");save.clicked.connect(lambda:self._ad_save_draft(True));actions.addWidget(save)
        export=QPushButton("ENVIAR FOTOS + EXPORTAR PLANILHA SHOPEE");export.clicked.connect(self._ad_export_shopee);actions.addWidget(export);text_layout.addLayout(actions)
        product_layout.addStretch()
        self._ad_refresh_ai_status();return w

    def refresh_ad_creator(self):
        if not hasattr(self,"ad_product_combo"):return
        current=self.ad_product_combo.currentData();settings=all_settings()
        with db() as con:
            rows=con.execute("SELECT id,boneco_name,variation_name,sku,listing_name FROM variants WHERE active=1 ORDER BY boneco_name,variation_name,sku").fetchall()
        self.ad_product_combo.blockSignals(True);self.ad_product_combo.clear();self.ad_product_combo.addItem("Novo / não vinculado",None)
        for r in rows:
            name=r["boneco_name"] or r["variation_name"] or r["listing_name"] or "Produto"
            self.ad_product_combo.addItem(f'{name} • {r["variation_name"] or "sem variação"} • SKU {r["sku"] or "—"}',r["id"])
        ix=self.ad_product_combo.findData(current)
        if ix>=0:self.ad_product_combo.setCurrentIndex(ix)
        self.ad_product_combo.blockSignals(False)
        if self.ad_stock.value()==0:self.ad_stock.setValue(int(float(settings.get("shopee_default_stock",10) or 10)))
        if not self.ad_category.text().strip():self.ad_category.setText(str(settings.get("shopee_default_category","") or "Brinquedos > Bonecos e Figuras de Ação"))
        self._ad_recalculate()

    def _ad_product_changed(self):
        if not hasattr(self,"ad_product_combo"):return
        vid=self.ad_product_combo.currentData()
        if not vid:return
        with db() as con:
            r=con.execute("SELECT * FROM variants WHERE id=?",(vid,)).fetchone()
            colors=con.execute("SELECT color_name,grams_per_unit FROM variant_colors WHERE variant_id=? ORDER BY slot",(vid,)).fetchall()
        if not r:return
        self.ad_product_name.setText(r["boneco_name"] or r["variation_name"] or r["listing_name"] or "")
        if not self.ad_sku.text().strip():self.ad_sku.setText(r["sku"] or "")
        if not self.ad_print_path.text().strip():
            self.ad_weight.setValue(float(r["weight_g"] or 0));self.ad_hours.setValue(float(r["print_hours"] or 0))
            if colors:self._ad_fill_colors([(x["color_name"],"",float(x["grams_per_unit"] or 0)) for x in colors])
        self._ad_recalculate(force_price=(self.ad_price.value()<=0))
        if not self.ad_title.text().strip():self._ad_generate_seo()

    def _ad_auto_match_product(self,title):
        if not hasattr(self,"ad_product_combo") or self.ad_product_combo.currentData():return
        stop={"the","a","an","of","and","articulated","figure","print","model","no","ams","3d","hedgehog","boneco"}
        source=[x for x in _norm(title).split() if x not in stop]
        if not source:return
        best=(-1,None)
        for i in range(1,self.ad_product_combo.count()):
            text=self.ad_product_combo.itemText(i).split(" • ",1)[0]
            target=[x for x in _norm(text).split() if x not in stop]
            if not target:continue
            inter=len(set(source)&set(target));score=inter/max(1,len(set(target)))
            if _norm(text)==_norm(title):score+=2
            if score>best[0]:best=(score,i)
        if best[1] is not None and best[0]>=0.72:self.ad_product_combo.setCurrentIndex(best[1])

    def _ad_analyze_link(self):
        url=self.ad_mw_url.text().strip()
        if not url:
            QMessageBox.information(self,"Criação de anúncio","Cole o link do MakerWorld primeiro.");return
        if getattr(self,"ad_thread",None):
            QMessageBox.information(self,"Criação de anúncio","Já existe uma análise de link em andamento.");return
        model_match=re.search(r"/models/(\d+)",url);key=model_match.group(1) if model_match else datetime.now().strftime("%Y%m%d%H%M%S")
        base=PHOTO_DIR/f"makerworld_{key}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        self.ad_analyze_btn.setEnabled(False);self.ad_state.setText("Analisando MakerWorld no modo: " + self.ad_photo_mode.currentText())
        self.ad_thread=QThread(self);self.ad_worker=_AdMediaWorker(url,base,self.ad_photo_mode.currentData());self.ad_worker.moveToThread(self.ad_thread)
        self.ad_thread.started.connect(self.ad_worker.run);self.ad_worker.progress.connect(self._ad_media_progress);self.ad_worker.finished.connect(self._ad_media_done);self.ad_worker.error.connect(self._ad_media_error)
        self.ad_worker.finished.connect(self.ad_thread.quit);self.ad_worker.error.connect(self.ad_thread.quit);self.ad_thread.finished.connect(self._ad_media_cleanup);self.ad_thread.start()

    def _ad_media_progress(self,text):
        self.ad_state.setText(text)

    def _ad_media_done(self,payload):
        result=payload["result"];self.ad_current_result=result;self.ad_current_images=payload["images"]
        source_name=_best_ptbr_name(result)
        original_title=result.title or "Modelo sem título"
        self.ad_source_status.setText(f'{source_name} • {sum(bool(x.get("edited_path")) for x in self.ad_current_images)} foto(s) DO CRIADOR (sem avaliações, sem colagem automática)')
        meta=[]
        if original_title and clean_model_name(original_title) != source_name:meta.append(f"Título original: {original_title}")
        if result.creator:meta.append(f"Criador: {result.creator}")
        if result.license:meta.append(f"Licença: {result.license}")
        if result.model_id:meta.append(f"Modelo: {result.model_id}")
        if result.profile_id:meta.append(f"Perfil: {result.profile_id}")
        if result.tags:meta.append("Tags: "+", ".join(result.tags[:6]))
        self.ad_source_meta.setText(" • ".join(meta) or "Dados públicos carregados do MakerWorld.")
        self._ad_auto_match_product(source_name)
        self.ad_product_name.setText(source_name)
        self._ad_generate_seo()
        self._ad_refresh_images_table()
        self._ad_update_plan_hint();self._ad_refresh_ai_status();self._ad_write_ai_plan()
        failures=payload.get("failures") or []
        suffix=f" • {len(failures)} foto(s) falharam" if failures else ""
        ok=sum(1 for x in self.ad_current_images if self._ad_image_is_valid(x) and x.get('selected'));self.ad_state.setText(f"Galeria do criador: {ok} foto(s) selecionadas de {len(result.images)} URL(s) encontradas + {len(failures)} aviso(s). Somente galeria do criador. Sem avaliações e sem juntar fotos automaticamente. Confira licença do modelo antes de vender.")
        self.ad_analyze_btn.setEnabled(True)

    def _ad_media_error(self,text):
        self.ad_analyze_btn.setEnabled(True);self.ad_state.setText("Falha ao analisar link")
        QMessageBox.critical(self,"MakerWorld",text)

    def _ad_media_cleanup(self):
        if getattr(self,"ad_worker",None):self.ad_worker.deleteLater()
        if getattr(self,"ad_thread",None):self.ad_thread.deleteLater()
        self.ad_worker=None;self.ad_thread=None

    def _ad_start_remote_bridge(self):
        if sys.platform!='win32':
            QMessageBox.information(self,"Ponte HTTPS","O iniciador automatico desta entrega e para Windows. Consulte app/integrations/LEIA-ME-MCP.md para outros sistemas.");return
        current=getattr(self,'ad_bridge_launcher',None)
        if current is not None and current.poll() is None:
            QMessageBox.information(self,"Ponte HTTPS","A janela da ponte ja esta aberta.");return
        answer=QMessageBox.question(self,"Iniciar ponte autenticada","Iniciar uma ponte HTTPS temporaria para permitir acesso remoto autenticado as tarefas/fotos selecionadas e consulta basica de produtos? Os componentes opcionais usam a internet. A geracao de imagens depende do cliente MCP.",QMessageBox.Yes|QMessageBox.No,QMessageBox.No)
        if answer!=QMessageBox.Yes:return
        script=Path(__file__).resolve().parents[1]/'integrations/INICIAR_PONTE_TEMPORARIA.ps1'
        try:
            self.ad_bridge_launcher=subprocess.Popen(['powershell.exe','-NoProfile','-ExecutionPolicy','Bypass','-File',str(script)],creationflags=subprocess.CREATE_NEW_CONSOLE)
            self.ad_chatgpt_status.setText('Iniciador da ponte aberto. Acompanhe o resultado na janela; isto ainda nao confirma conexao com o ChatGPT.')
        except Exception as exc:QMessageBox.warning(self,"Ponte HTTPS",str(exc))

    def _ad_copy_remote_url(self):
        from services.mcp_settings import load_settings
        try:
            config=load_settings(APP_ROOT);QApplication.clipboard().setText(config['public_url']+'/mcp')
            self.ad_chatgpt_status.setText('URL configurada copiada. Confira se a janela da ponte continua aberta; conectividade publica ainda depende do tunnel e do cliente.')
        except Exception:QMessageBox.information(self,"URL MCP","Inicie primeiro a ponte e aguarde a janela informar o endereco HTTPS.")

    def _ad_copy_bridge_code(self):
        try:
            code=(APP_ROOT/'arquivos/mcp/access.key').read_text(encoding='utf-8')
            QApplication.clipboard().setText(code)
            self.ad_chatgpt_status.setText('Codigo local copiado. Cole apenas na pagina de autorizacao da sua ponte; nao envie no chat. Copia sera limpa em 60 segundos se nao mudar.')
            QTimer.singleShot(60000,lambda:QApplication.clipboard().clear() if QApplication.clipboard().text()==code else None)
        except OSError:QMessageBox.information(self,"Codigo","Inicie primeiro a ponte para gerar o codigo de acesso local.")

    def _ad_photo_jobs(self):
        return PhotoJobs(APP_ROOT/'arquivos/chatgpt')

    def _ad_prepare_chatgpt(self):
        paths,_=QFileDialog.getOpenFileNames(self,"Selecionar ate 9 fotos para o ChatGPT",str(Path.home()),"Imagens (*.jpg *.jpeg *.png *.webp)")
        if not paths:return
        self._ad_prepare_chatgpt_paths(paths)

    def _ad_prepare_gallery_chatgpt(self):
        if any(getattr(self,name,None) for name in ('ad_upload_thread','ad_reprocess_thread','ad_thread')):
            QMessageBox.information(self,"Fotos","Aguarde a operacao de fotos terminar.");return
        self._ad_sync_images_table()
        paths=[]
        for item in self.ad_current_images:
            if not item.get('selected') or not self._ad_image_is_valid(item):continue
            path=Path(str(item.get('original_path') or item.get('edited_path') or ''))
            if path.is_file():paths.append(str(path))
        if not paths:
            QMessageBox.information(self,"Fotos da galeria","Cole ou importe as fotos e marque quais deseja usar no ChatGPT.");return
        self._ad_prepare_chatgpt_paths(paths)

    def _ad_open_photo_extension(self):
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(APP_ROOT/'app/integrations/opera_extension')))
        QMessageBox.information(self,"Instalar extensao no Opera GX","No seu Opera GX, abra opera://extensions, ative Modo do desenvolvedor, clique em Carregar sem compactacao e selecione a pasta que acabou de abrir. Depois clique em Copiar pareamento da extensao no ERP e cole no icone da extensao. Nao compartilhe o pareamento no chat.")

    def _ad_copy_photo_extension_pairing(self):
        from services.photo_extension import pairing
        try:
            value=pairing(APP_ROOT);QApplication.clipboard().setText(value)
            QTimer.singleShot(60000,lambda:QApplication.clipboard().clear() if QApplication.clipboard().text()==value else None)
            self.ad_chatgpt_status.setText('Pareamento copiado. Cole somente no icone da extensao Forgeon no seu Opera GX e clique Conectar ao ERP. Nao envie no chat.')
        except Exception as exc:QMessageBox.warning(self,"Extensao",str(exc))

    def _ad_configure_photo_chat(self):
        from services.chatgpt_browser import load,save
        if getattr(self,'ad_extension_active',False):
            QMessageBox.information(self,"Envio em andamento","Aguarde terminar antes de alterar a conversa.");return False
        try:current=load(APP_ROOT)
        except (OSError,ValueError,KeyError):current=''
        value,ok=QInputDialog.getText(self,"Conversa Fotos","No Opera GX, abra a conversa Fotos existente e copie o link completo da barra (https://chatgpt.com/c/... ou /local/...). O envio usara essa aba ja aberta, com seu login atual:",text=current)
        if not ok:return False
        try:
            save(APP_ROOT,value);self.ad_chatgpt_status.setText('Conversa Fotos salva. Cole ou selecione as fotos e clique em Enviar fotos da galeria.');return True
        except (ValueError,OSError) as exc:
            QMessageBox.warning(self,"Conversa Fotos",str(exc));return False

    def _ad_prepare_chatgpt_paths(self,paths):
        if getattr(self,'ad_extension_active',False):
            QMessageBox.information(self,"Envio em andamento","Aguarde a confirmacao do envio atual. Nao sera aberta outra aba.");return
        if len(paths)>9:
            QMessageBox.warning(self,"Fotos","Selecione no maximo 9 fotos por tarefa.");return
        from services.chatgpt_browser import load
        try:load(APP_ROOT)
        except (OSError,ValueError,KeyError):
            if not self._ad_configure_photo_chat():return
        height=self.ad_product_height.value()
        if height<=0:
            height,accepted=QInputDialog.getDouble(self,"Altura do personagem","Altura total em centimetros:",12,0.1,1000,1)
            if not accepted:return
        self.ad_product_height.setValue(height)
        try:
            job=self._ad_photo_jobs().create(paths,height);self.ad_active_photo_job=job['id']
            from services.photo_extension import ensure,request
            ensure(APP_ROOT);request(APP_ROOT,'/enqueue',{'id':job['id']})
            self.ad_extension_active=True;self.ad_extension_started=datetime.now().timestamp()
            self.ad_chatgpt_status.setText('Aguardando a extensao na aba Fotos existente. Nao sera aberta outra janela. Se necessario, instale e pareie a extensao pelos botoes acima.')
            if not getattr(self,'ad_browser_timer',None):
                self.ad_browser_timer=QTimer(self);self.ad_browser_timer.timeout.connect(self._ad_poll_browser_send)
            self.ad_browser_timer.start(1000)
        except Exception as exc:
            QMessageBox.warning(self,"Enviar ao ChatGPT",str(exc))

    def _ad_poll_browser_send(self):
        try:
            from services.photo_extension import request
            health=request(APP_ROOT,'/health',timeout=.3)
            folder=self._ad_photo_jobs().folder(self.ad_active_photo_job)
            result=json.loads((folder/'browser-send.json').read_text(encoding='utf-8'))
            message=result['message']
            if result['state']=='AGUARDANDO_EXTENSAO' and not health.get('extension_connected') and datetime.now().timestamp()-getattr(self,'ad_extension_started',0)>10:
                message='A extensao ainda nao se conectou ao ERP. Carregue a pasta app/integrations/opera_extension em opera://extensions e faca o pareamento pelo icone Forgeon. Nenhuma mensagem enviada. Use Cancelar espera para liberar.'
            self.ad_chatgpt_status.setText(message)
            if result['state'] in ('ENVIADO','ERRO','ENVIO_INCERTO'):
                self.ad_extension_active=False;self.ad_browser_timer.stop()
        except OSError:
            self.ad_chatgpt_status.setText('Ponte local da extensao indisponivel. Confira a conversa Fotos antes de repetir o envio.')
            self.ad_extension_active=False;self.ad_browser_timer.stop()
        except (ValueError,KeyError):pass

    def _ad_cancel_photo_send(self):
        from services.photo_extension import request
        try:
            if self.ad_active_photo_job:request(APP_ROOT,'/cancel',{'id':self.ad_active_photo_job})
            self.ad_extension_active=False
            if getattr(self,'ad_browser_timer',None):self.ad_browser_timer.stop()
            self.ad_chatgpt_status.setText('Espera cancelada. Confira a conversa Fotos e seus anexos/rascunho antes de iniciar outra tarefa. Nenhum reenvio automatico.')
        except Exception as exc:QMessageBox.warning(self,"Cancelar",str(exc))

    def _ad_copy_photo_diagnostic(self):
        if not self.ad_active_photo_job:
            QMessageBox.information(self,"Diagnostico","Prepare uma tarefa primeiro.");return
        folder=self._ad_photo_jobs().folder(self.ad_active_photo_job)
        result={'erp_version':'0.5.20'}
        for name,key in [('browser-send.json','status'),('browser-diagnostic.json','page')]:
            try:result[key]=json.loads((folder/name).read_text(encoding='utf-8'))
            except (OSError,ValueError):pass
        try:
            from services.photo_extension import request
            result['connection']=request(APP_ROOT,'/health',timeout=.5)
        except Exception:result['connection']={'connected':False}
        QApplication.clipboard().setText(json.dumps(result,ensure_ascii=False,indent=2))
        self.ad_chatgpt_status.setText('Diagnostico copiado: estado, versao da extensao e estrutura dos controles; sem fotos, prompt, cookies ou pareamento.')

    def _ad_copy_photo_prompt(self):
        if not self.ad_active_photo_job:
            QMessageBox.information(self,"Prompt","Selecione as fotos e informe a altura para preparar o prompt.");return
        try:
            QApplication.clipboard().setText(self._ad_photo_jobs().get(self.ad_active_photo_job)['prompt'])
            self.ad_chatgpt_status.setText('Prompt copiado. Nenhuma mensagem enviada automaticamente.')
        except Exception as exc:QMessageBox.warning(self,"Prompt",str(exc))

    def _ad_open_photo_job(self):
        if self.ad_active_photo_job:
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(self._ad_photo_jobs().folder(self.ad_active_photo_job))))
        else:QDesktopServices.openUrl(QUrl.fromLocalFile(str(self._ad_photo_jobs().root)))

    def _ad_import_mcp_results(self):
        try:
            store=self._ad_photo_jobs()
            if not self.ad_active_photo_job:
                tasks=store.list()
                if not tasks:
                    QMessageBox.information(self,"Resultados","Nenhuma tarefa local encontrada.");return
                ids=[x['id'] for x in tasks]
                chosen,accepted=QInputDialog.getItem(self,"Tarefa MCP","Selecione a tarefa:",ids,0,False)
                if not accepted:return
                self.ad_active_photo_job=chosen
            job=store.get(self.ad_active_photo_job);folder=store.folder(job['id'])
            paths=[str(store.inside(folder,f'resultados/{slot:02d}.jpg')) for slot in job['results']]
            if not paths:
                QMessageBox.information(self,"Resultados","Nenhum resultado foi devolvido pelo conector. Fotos baixadas manualmente do ChatGPT podem ser adicionadas com Importar fotos prontas (GPT).");return
            self._ad_import_ready_paths(paths)
            self.ad_chatgpt_status.setText(f"Tarefa {job['id'][:8]}: {len(paths)} resultado(s) disponivel(is). Confira a galeria e os arquivos selecionados.")
        except Exception as exc:QMessageBox.warning(self,"Resultados MCP",str(exc))

    def _ad_paste_photo(self):
        if any(getattr(self,name,None) for name in ('ad_upload_thread','ad_reprocess_thread','ad_thread')):
            QMessageBox.information(self,"Colar imagem","Aguarde a operacao de fotos terminar antes de colar.");return
        if len(self.ad_current_images)>=9:
            QMessageBox.information(self,"Galeria cheia","A galeria aceita ate 9 fotos. Remova uma foto antes de colar outra.");return
        clipboard=QApplication.clipboard();mime=clipboard.mimeData()
        if mime is None:
            QMessageBox.information(self,"Colar imagem","Copie uma imagem ou arquivo JPG/PNG/WebP primeiro.");return
        try:
            if mime.hasImage():
                image=clipboard.image()
                if image.isNull():raise ValueError('Nao foi possivel ler a imagem copiada.')
                if image.width()*image.height()>24_000_000:raise ValueError('Imagem muito grande. Reduza para ate 24 megapixels antes de colar.')
                with tempfile.TemporaryDirectory(prefix='forgeon-clipboard-') as temp:
                    source=Path(temp)/'imagem-colada.png'
                    if not image.save(str(source),'PNG'):raise ValueError('Nao foi possivel preparar a imagem copiada.')
                    self._ad_import_ready_paths([str(source)])
                return
            paths=[]
            if mime.hasUrls():
                for url in mime.urls():
                    if not url.isLocalFile() or url.host() not in ('','localhost'):continue
                    path=Path(url.toLocalFile())
                    if path.is_file() and path.suffix.lower() in ('.jpg','.jpeg','.png','.webp'):paths.append(str(path))
            if paths:
                self._ad_import_ready_paths(paths);return
            QMessageBox.information(self,"Colar imagem","A area de transferencia nao tem uma imagem compativel. No navegador use Copiar imagem, nao Copiar endereco da imagem. Tambem pode copiar arquivos JPG, PNG ou WebP do Explorador.")
        except Exception as exc:QMessageBox.warning(self,"Colar imagem",str(exc))

    def _ad_import_ready_photos(self):
        paths,_=QFileDialog.getOpenFileNames(self,"Importar fotos prontas do GPT",str(Path.home()),"Imagens (*.jpg *.jpeg *.png *.webp)")
        if not paths:return
        self._ad_import_ready_paths(paths)

    def _ad_import_ready_paths(self,paths):
        self._ad_sync_images_table()
        remaining=max(0,9-len(self.ad_current_images))
        if not remaining:
            QMessageBox.information(self,"Galeria cheia","A galeria aceita ate 9 fotos. Remova uma foto para adicionar outra.");return
        base=PHOTO_DIR/("prontas_"+uuid4().hex)
        errors=[];added=0;duplicates=0;overflow=0
        known={x.get('source_sha256') for x in self.ad_current_images if x.get('source_sha256')}
        for source in paths:
            try:
                digest=hashlib.sha256(Path(source).read_bytes()).hexdigest()
                if digest in known:duplicates+=1;continue
                if added>=remaining:overflow+=1;continue
                original=base/'originais'/(uuid4().hex+Path(source).suffix.lower())
                output=base/'editadas'/(uuid4().hex+'.jpg')
                info=prepare_ready_photo(source,output,SHOPEE_MAX_IMAGE_BYTES)
                original.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,original)
                self.ad_current_images.append(dict(info,position=len(self.ad_current_images)+1,
                    source_url='',original_path=str(original),edited_path=str(output),public_url='',selected=1,mask_path=''))
                known.add(digest);added+=1
            except Exception as exc:errors.append(Path(source).name+': '+str(exc))
        self._ad_refresh_images_table()
        self.ad_state.setText(f"{added} foto(s) pronta(s) importada(s), sem recorte. {duplicates} duplicada(s) ignorada(s); {overflow} excedente(s).")
        if errors:QMessageBox.warning(self,"Importacao das fotos","Alguns arquivos nao foram importados:\n"+"\n".join(errors[:8]))

    def _ad_move_ready_photo(self,direction):
        self._ad_sync_images_table();rows=sorted({x.row() for x in self.ad_images_table.selectedIndexes()})
        if len(rows)!=1:
            QMessageBox.information(self,"Ordenar fotos","Selecione uma foto da galeria.");return
        old=rows[0];new=0 if direction==0 else min(max(0,old+direction),len(self.ad_current_images)-1)
        self.ad_current_images.insert(new,self.ad_current_images.pop(old))
        for i,item in enumerate(self.ad_current_images,1):item['position']=i
        self._ad_refresh_images_table();self.ad_images_table.selectRow(new)

    def _ad_remove_ready_photos(self):
        self._ad_sync_images_table();rows={x.row() for x in self.ad_images_table.selectedIndexes()}
        self.ad_current_images=[x for i,x in enumerate(self.ad_current_images) if i not in rows]
        for i,item in enumerate(self.ad_current_images,1):item['position']=i
        self._ad_refresh_images_table()
        self.ad_state.setText('Fotos removidas da galeria. Os arquivos originais foram preservados.')

    def _ad_add_local_photos(self):
        paths,_=QFileDialog.getOpenFileNames(self,"Selecionar fotos do produto",str(Path.home()),"Imagens (*.jpg *.jpeg *.png *.webp)")
        if not paths:return
        if not hasattr(self,"ad_current_images"):self.ad_current_images=[]
        remain=max(0,9-len(self.ad_current_images))
        if remain<=0:
            QMessageBox.information(self,"Fotos","O template aceita capa + 8 fotos. Remova alguma foto antes de adicionar outra.");return
        base=PHOTO_DIR/f"locais_{datetime.now().strftime('%Y%m%d_%H%M%S')}";origdir=base/"originais";editdir=base/"editadas";origdir.mkdir(parents=True,exist_ok=True);editdir.mkdir(parents=True,exist_ok=True)
        errors=[]
        for src in paths[:remain]:
            try:
                pos=len(self.ad_current_images)+1;sp=Path(src);orig=origdir/f"foto_{pos:02d}{sp.suffix.lower()}";shutil.copy2(sp,orig);out=editdir/f"foto_{pos:02d}_marketplace.jpg"
                result=getattr(self,"ad_current_result",None)
                product_name=self.ad_product_name.text().strip() or _best_ptbr_name(result)
                mode=self.ad_photo_mode.currentData()
                ready_white,white_info=_creator_background_is_white(orig)
                diag=(_preserve_creator_white_photo(orig,out) if ready_white else
                      process_marketplace_image_external_first(orig,out,1600,0.95,product_name=product_name,allow_local_fallback=False)
                      if mode=='external_api' else process_local(orig,out,mode))
                self.ad_current_images.append({"position":pos,"source_url":"","original_path":str(orig),"edited_path":str(out) if diag.get("success") else "","public_url":"","selected":1 if diag.get("success") and not diag.get('metrics',{}).get('review') else 0,"status":diag.get("status","FALHOU"),"method":diag.get("method","—"),"diagnostic":diag.get("message","") or "","traceback":diag.get("traceback","") or "","mask_path":diag.get("mask_path","")})
                if not diag.get("success"):errors.append(f"{Path(src).name}: {diag.get('message') or 'recorte por IA falhou'}")
            except Exception as e:errors.append(f"{Path(src).name}: {e}")
        self._ad_refresh_images_table();self._ad_update_plan_hint();self._ad_refresh_ai_status();self._ad_write_ai_plan();ok=sum(1 for x in self.ad_current_images if self._ad_image_is_valid(x));self.ad_state.setText(f"{ok} foto(s) aprovada(s) pela IA.")
        if errors:QMessageBox.warning(self,"Fotos","Algumas fotos não foram processadas:\n\n"+"\n".join(errors[:5]))

    def _ad_refresh_images_table(self):
        if not hasattr(self,"ad_images_table"):return
        t=self.ad_images_table;t.setUpdatesEnabled(False);t.setRowCount(len(getattr(self,"ad_current_images",[])))
        try:
            for r,item in enumerate(self.ad_current_images):
                pos=QTableWidgetItem(str(item.get("position") or r+1));pos.setFlags(pos.flags()&~Qt.ItemIsEditable);t.setItem(r,0,pos)
                prev=QLabel();prev.setAlignment(Qt.AlignCenter)
                edited=Path(str(item.get("edited_path") or ""));original=Path(str(item.get("original_path") or ""));preview=edited if edited.exists() else original
                if preview.exists():prev.setPixmap(QPixmap(str(preview)).scaled(92,92,Qt.KeepAspectRatio,Qt.SmoothTransformation))
                t.setCellWidget(r,1,prev);t.setRowHeight(r,100)
                name=QTableWidgetItem(edited.name if edited.name else "—");name.setFlags(name.flags()&~Qt.ItemIsEditable);t.setItem(r,2,name)
                method=QTableWidgetItem(str(item.get("method") or "—"));method.setFlags(method.flags()&~Qt.ItemIsEditable);t.setItem(r,3,method)
                status_text=str(item.get("status") or ("IA OK" if edited.exists() else "FALHOU"));status=QTableWidgetItem(status_text);status.setFlags(status.flags()&~Qt.ItemIsEditable);status.setToolTip(str(item.get("diagnostic") or ""));t.setItem(r,4,status)
                t.setItem(r,5,QTableWidgetItem(str(item.get("public_url") or "")))
                use=QTableWidgetItem("");use.setFlags((use.flags()|Qt.ItemIsUserCheckable)&~Qt.ItemIsEditable)
                ok=self._ad_image_is_valid(item);use.setCheckState(Qt.Checked if item.get("selected",1) and ok else Qt.Unchecked)
                if not ok:use.setFlags(use.flags()&~Qt.ItemIsEnabled)
                t.setItem(r,6,use)
        finally:t.setUpdatesEnabled(True)

    def _ad_image_is_valid(self,item):
        status=str(item.get("status") or "").upper();p=Path(str(item.get("edited_path") or ""))
        return bool(p.is_file() and status not in {"FALHOU","ERRO","REJEITADA","EXTERNA FALHOU"}
                    and "REVISAR" not in status and "PENDENTE" not in status)

    def _ad_sync_images_table(self):
        if not hasattr(self,"ad_images_table"):return
        for r,item in enumerate(getattr(self,"ad_current_images",[])):
            if r>=self.ad_images_table.rowCount():break
            url_item=self.ad_images_table.item(r,5);use_item=self.ad_images_table.item(r,6)
            item["public_url"]=(url_item.text().strip() if url_item else str(item.get("public_url") or ""))
            item["selected"]=1 if (use_item and use_item.checkState()==Qt.Checked and self._ad_image_is_valid(item)) else 0
            item["position"]=int(item.get("position") or (r+1))

    def _ad_target_rows(self):
        if not hasattr(self,"ad_images_table"):return []
        rows=sorted({x.row() for x in self.ad_images_table.selectedIndexes()})
        if rows:return rows
        return [i for i,x in enumerate(getattr(self,"ad_current_images",[])) if x.get("selected",1) or str(x.get("status") or "").upper()=="FALHOU"]

    def _ad_reprocess_images(self):
        if getattr(self,'ad_reprocess_thread',None):
            QMessageBox.information(self,'Fotos','Aguarde o reprocessamento atual terminar.');return
        rows=self._ad_target_rows()
        if not rows:
            QMessageBox.information(self,'Fotos','Selecione uma ou mais fotos na tabela.');return
        jobs=[]
        for row in rows:
            if row < 0 or row >= len(self.ad_current_images): continue
            item=self.ad_current_images[row]
            orig=Path(str(item.get('original_path') or ''))
            if not orig.is_file(): continue
            old=Path(str(item.get('edited_path') or ''))
            editdir=old.parent if old.parent.is_dir() else orig.parent.parent/'editadas'
            jobs.append({'row':row,'slot':int(item.get('position') or row+1),
                         'original_path':str(orig),'output_path':str(editdir/f'foto_{row+1:02d}_marketplace.jpg')})
        if not jobs:
            QMessageBox.warning(self,'Fotos','Nenhum original valido foi encontrado.');return
        self.ad_reprocess_btn.setEnabled(False)
        self.ad_steps.widget(1).setEnabled(False)
        self.ad_state.setText(f'Reprocessando {len(jobs)} fotos em segundo plano...')
        self.ad_reprocess_thread=QThread(self)
        self.ad_reprocess_worker=_AdReprocessWorker(jobs,self.ad_photo_mode.currentData(),self.ad_product_name.text().strip())
        self.ad_reprocess_worker.moveToThread(self.ad_reprocess_thread)
        self.ad_reprocess_thread.started.connect(self.ad_reprocess_worker.run)
        self.ad_reprocess_worker.progress.connect(self.ad_state.setText)
        self.ad_reprocess_worker.finished.connect(self._ad_reprocess_done)
        self.ad_reprocess_worker.finished.connect(self.ad_reprocess_thread.quit)
        self.ad_reprocess_thread.finished.connect(self._ad_reprocess_cleanup)
        self.ad_reprocess_thread.start()

    def _ad_fix_mask(self):
        rows=sorted({x.row() for x in self.ad_images_table.selectedIndexes()})
        if not rows:
            QMessageBox.information(self,'Correção de máscara','Selecione uma linha de foto primeiro.');return
        item=self.ad_current_images[rows[0]]
        src=Path(str(item.get('original_path') or ''))
        mask=Path(str(item.get('mask_path') or ''))
        if not src.is_file() or not mask.is_file():
            QMessageBox.warning(self,'Máscara não encontrada','Essa foto não tem máscara local. Use modo LOCAL para gerar a máscara primeiro.');return
        from ui.forgeon_mask_editor import MaskCorrectionDialog
        try:
            dlg=MaskCorrectionDialog(src,mask,self)
            if dlg.exec()!=QDialog.Accepted:return
            edited=Path(str(item.get('edited_path') or ''))
            if not edited.is_file():
                edited=src.parent.parent/'editadas'/f'foto_{rows[0]+1:02d}_corrigida.jpg'
            result=render_mask(src,mask,edited)
            if not result.get('success'):
                QMessageBox.warning(self,'Máscara ainda inválida',result.get('message') or 'Falha');return
            item.update(edited_path=str(edited),status='LOCAL CORRIGIDO',method='local/mascara-manual',
                        diagnostic='Máscara corrigida pelo usuário e registrada para dataset local.',
                        mask_path=str(mask),selected=1,public_url='')
            self._ad_refresh_images_table()
            self.ad_state.setText('Máscara corrigida. Confira a foto; depois clique REFORMAR CAPA COM POSES OK.')
        except Exception as e:
            logging.exception('mask editor')
            QMessageBox.critical(self,'Erro no editor de máscara',str(e))

    def _ad_rebuild_cover(self):
        """Regenerate cover using only ONE approved creator photo (never duo)."""
        items=list(getattr(self,'ad_current_images',[]) or [])
        bases=[x for x in items if x.get('original_path')
               and 1 <= int(x.get('position') or 999) <= 6
               and self._ad_image_is_valid(x)]
        bases.sort(key=lambda x:int(x.get('position') or 999))
        if not bases:
            QMessageBox.information(self,'Reformar capa','Aprove ao menos uma foto original antes de reformar a capa.');return
        base=bases[0]
        src=Path(str(base.get('edited_path') or ''))
        orig=Path(str(base.get('original_path') or ''))
        cover=orig.parent.parent/'editadas'/'foto_01_marketplace.jpg'
        cover.parent.mkdir(parents=True,exist_ok=True)
        try:
            if src.resolve()!=cover.resolve():
                shutil.copy2(src,cover)
            row=next((x for x in items if int(x.get('position') or 999)==1),None)
            if row is None:
                row=dict(base)
                items.insert(0,row)
                self.ad_current_images=items
            row.update(position=1,edited_path=str(cover),original_path=str(orig),
                       mask_path=str(base.get('mask_path') or ''),
                       method='makerworld/capa-foto-original',status=str(base.get('status') or 'LOCAL OK'),
                       composed=False,selected=1,public_url='',
                       diagnostic='Capa refeita com uma foto real aprovada, sem juntar outras fotos.')
            # If another row already represents the chosen cover source,
            # remove that duplicate rather than generating two of the same photo.
            self.ad_current_images=[x for x in items if x is row or
                                    str(x.get('original_path') or '') != str(orig)]
            self._ad_refresh_images_table()
            self.ad_state.setText('Capa refeita sem criar dupla adicional.')
        except Exception as exc:
            logging.exception('rebuild creator cover')
            QMessageBox.warning(self,'Reformar capa',f'Falha: {exc}')

    def _ad_approve_review(self):
        rows=sorted({x.row() for x in self.ad_images_table.selectedIndexes()})
        if not rows:
            QMessageBox.information(self,'Aprovação de foto','Selecione a foto que você conferiu visualmente.');return
        item=self.ad_current_images[rows[0]]
        status=str(item.get('status') or '').upper()
        p=Path(str(item.get('edited_path') or ''))
        if not p.is_file():
            QMessageBox.warning(self,'Foto não disponível','Esta foto ainda não possui arquivo editado.');return
        if 'REVISAR' not in status:
            QMessageBox.information(self,'Aprovação de foto','Aprovação manual é necessária apenas para fotos LOCAL REVISAR.');return
        reply=QMessageBox.question(self,'Confirmar aprovação',
            'Você conferiu a foto em tamanho grande e verificou pés, mãos, orelhas, asas e ausência de cenário?\n\n'
            'A aprovação registra sua conferência visual, NÃO comprova que o algoritmo reconheceu tudo corretamente.',
            QMessageBox.Yes|QMessageBox.No,QMessageBox.No)
        if reply!=QMessageBox.Yes:return
        item.update(status='LOCAL APROVADO',selected=1,
                    diagnostic=(str(item.get('diagnostic') or '')+' | Conferido manualmente pelo usuário.').strip(),public_url='')
        self._ad_refresh_images_table()
        self.ad_state.setText('Foto marcada como conferida. Refaça a capa quando terminar as revisões.')

    def _ad_compare_models(self):
        if getattr(self,'ad_compare_thread',None):
            QMessageBox.information(self,'Comparação em andamento','Aguarde os dois modelos concluírem.');return
        rows=sorted({x.row() for x in self.ad_images_table.selectedIndexes()})
        if not rows:
            QMessageBox.information(self,'Comparar máscaras','Selecione uma FOTO BASE na tabela (não a capa dupla).');return
        idx=rows[0];item=self.ad_current_images[idx]
        if int(item.get('position') or 999)>=7:
            QMessageBox.information(self,'Comparar máscaras','Selecione uma FOTO BASE dos slots 2 a 6. Mão e cenário não são recortes locais de catálogo.');return
        if item.get('composed') or str(item.get('method') or '').startswith('local/capa'):
            QMessageBox.information(self,'Comparar máscaras','A capa combina poses; compare cada FOTO BASE individualmente.');return
        src=Path(str(item.get('original_path') or ''))
        if not src.is_file():
            QMessageBox.warning(self,'Fonte não encontrada','Esta linha não possui a foto original no disco.');return
        if getattr(self,'ad_photo_mode',None) and self.ad_photo_mode.currentData()=='external_api':
            QMessageBox.information(self,'Comparação gratuita','Esse botão usa SOMENTE modelos locais. Não consome API Gemini/OpenAI.')
        self._ad_compare_index=idx
        folder=src.parent.parent/'comparacoes'/f'foto_{idx+1:02d}_{datetime.now().strftime("%H%M%S")}'
        self.ad_state.setText('Comparando ISNet e BiRefNet Lite na mesma foto... 1º uso pode baixar o modelo.')
        self.ad_compare_btn.setEnabled(False)
        self.ad_compare_thread=QThread(self)
        self.ad_compare_worker=_LocalCompareWorker(src,folder)
        self.ad_compare_worker.moveToThread(self.ad_compare_thread)
        self.ad_compare_thread.started.connect(self.ad_compare_worker.run)
        self.ad_compare_worker.finished.connect(self._ad_compare_done)
        self.ad_compare_worker.error.connect(self._ad_compare_error)
        self.ad_compare_worker.finished.connect(self.ad_compare_thread.quit)
        self.ad_compare_worker.error.connect(self.ad_compare_thread.quit)
        self.ad_compare_thread.finished.connect(self._ad_compare_cleanup)
        self.ad_compare_thread.start()

    def _ad_compare_done(self,payload):
        from ui.forgeon_compare_dialog import PhotoCompareDialog
        dlg=PhotoCompareDialog(payload,self)
        if dlg.exec()!=QDialog.Accepted or not dlg.selected_mode:
            self.ad_state.setText('Comparação concluída. Foto original mantida.');return
        idx=getattr(self,'_ad_compare_index',-1)
        if not 0<=idx<len(self.ad_current_images):return
        choice=dict(payload.get('results',{}).get(dlg.selected_mode) or {})
        pic=Path(str(choice.get('output_path') or ''))
        mask=Path(str(choice.get('mask_path') or ''))
        if not choice.get('success') or not pic.is_file() or not mask.is_file():
            QMessageBox.warning(self,'Comparação','O modelo escolhido não produziu arquivo de saída válido.');return
        item=self.ad_current_images[idx]
        item.update(edited_path=str(pic),mask_path=str(mask),status=str(choice.get('status') or 'LOCAL REVISAR'),
                    method=f"comparado/{dlg.selected_mode}",
                    diagnostic=str(choice.get('message') or '')+' | Escolhido pelo usuário no teste A/B.',
                    selected=0 if (choice.get('metrics') or {}).get('review') else 1,
                    public_url='')
        self._ad_refresh_images_table()
        self.ad_state.setText('Foto base atualizada após comparação. Clique em REFORMAR CAPA COM POSES OK para atualizar a capa.')

    def _ad_compare_error(self,message):
        self.ad_state.setText('Falha ao comparar modelos locais.')
        QMessageBox.warning(self,'Comparar modelos','Não foi possível comparar as máscaras.\n\n'+str(message))

    def _ad_compare_cleanup(self):
        if getattr(self,'ad_compare_worker',None):self.ad_compare_worker.deleteLater()
        if getattr(self,'ad_compare_thread',None):self.ad_compare_thread.deleteLater()
        self.ad_compare_worker=None;self.ad_compare_thread=None
        if hasattr(self,'ad_compare_btn'):self.ad_compare_btn.setEnabled(True)

    def _ad_test_external_ai(self):
        if getattr(self,'ad_test_thread',None):return
        item=self._ad_current_image_item()
        if not item:
            QMessageBox.information(self,'IA externa','Selecione uma foto primeiro.');return
        orig=Path(str(item.get('original_path') or ''))
        if not orig.is_file():
            QMessageBox.warning(self,'IA externa','Original nao encontrado.');return
        out=orig.parent.parent/'editadas'/'teste_ia_externa.jpg'
        self.ad_test_ai_btn.setEnabled(False)
        self.ad_state.setText('Testando IA externa em segundo plano...')
        self.ad_test_thread=QThread(self)
        self.ad_test_worker=_AdAiImageTestWorker(orig,out,self.ad_product_name.text().strip())
        self.ad_test_worker.moveToThread(self.ad_test_thread)
        self.ad_test_thread.started.connect(self.ad_test_worker.run)
        self.ad_test_worker.finished.connect(self._ad_test_ai_done)
        self.ad_test_worker.finished.connect(self.ad_test_thread.quit)
        self.ad_test_thread.finished.connect(self._ad_test_ai_cleanup)
        self.ad_test_thread.start()

    def _ad_current_image_item(self):
        rows=self._ad_target_rows()
        if not rows:return None
        r=rows[0]
        return self.ad_current_images[r] if 0<=r<len(self.ad_current_images) else None

    def _ad_show_diagnostic(self):
        item=self._ad_current_image_item()
        if not item:
            QMessageBox.information(self,"Diagnóstico","Selecione uma foto na tabela.");return
        msg=(f"Status: {item.get('status') or '—'}\nMétodo: {item.get('method') or '—'}\n\n{item.get('diagnostic') or 'Sem mensagem adicional.'}\n\nOriginal: {item.get('original_path') or '—'}\nSaída: {item.get('edited_path') or '—'}\nMáscara: {item.get('mask_path') or '—'}")
        tb=str(item.get("traceback") or "").strip()
        if tb:
            msg += "\n\nDetalhes técnicos:\n" + tb[-3500:]
        QMessageBox.information(self,"Diagnóstico da foto",msg)

    def _ad_show_image(self):
        item=self._ad_current_image_item()
        if not item:
            QMessageBox.information(self,"Foto","Selecione uma foto na tabela.");return
        edited=Path(str(item.get("edited_path") or ""));original=Path(str(item.get("original_path") or ""))
        p=edited if edited.exists() else original
        if not p.exists():
            QMessageBox.information(self,"Foto","Não encontrei o arquivo desta imagem.");return
        dlg=QDialog(self);dlg.setWindowTitle(f"Visualizar foto — {p.name}");dlg.resize(1500,1100)
        lay=QVBoxLayout(dlg)
        top=QLabel("Visualização ampliada. Use a barra de rolagem para conferir recorte, bordas e enquadramento.");top.setObjectName("Hint");top.setWordWrap(True);top.setAlignment(Qt.AlignCenter);lay.addWidget(top)
        area=QScrollArea();area.setWidgetResizable(True)
        holder=QWidget();v=QVBoxLayout(holder)
        lab=QLabel();lab.setAlignment(Qt.AlignCenter)
        pix=QPixmap(str(p))
        if not pix.isNull():
            target_w=max(900,min(1450,pix.width()))
            target_h=max(900,min(1450,pix.height()))
            lab.setPixmap(pix.scaled(target_w,target_h,Qt.KeepAspectRatio,Qt.SmoothTransformation))
        else:
            lab.setText("Falha ao carregar imagem.")
        v.addWidget(lab,1)
        area.setWidget(holder)
        lay.addWidget(area,1)
        hint=QLabel(str(p));hint.setObjectName("Hint");hint.setWordWrap(True);hint.setAlignment(Qt.AlignCenter)
        lay.addWidget(hint)
        dlg.exec()

    def _ad_show_gallery(self):
        dlg=QDialog(self)
        dlg.setWindowTitle('Forgeon Photo Lab - galeria de anuncio')
        dlg.resize(1500,960)
        outer=QVBoxLayout(dlg)
        outer.addWidget(QLabel('GALERIA GRANDE - veja fotos, status e metodo antes de publicar. LOCAL REVISAR pede correcao manual.'))
        sc=QScrollArea();sc.setWidgetResizable(True)
        holder=QWidget();grid=QGridLayout(holder)
        for i,item in enumerate(getattr(self,'ad_current_images',[]) or []):
            box=QFrame();box.setObjectName('Panel')
            v=QVBoxLayout(box)
            pos=item.get('position') or (i+1)
            title=QLabel(f'FOTO {pos:02d} | {item.get("status") or "-"}')
            title.setWordWrap(True);v.addWidget(title)
            img=Path(str(item.get('edited_path') or ''))
            if not img.is_file():img=Path(str(item.get('original_path') or ''))
            preview=QLabel();preview.setAlignment(Qt.AlignCenter)
            if img.is_file():
                pix=QPixmap(str(img))
                if not pix.isNull():preview.setPixmap(pix.scaled(310,310,Qt.KeepAspectRatio,Qt.SmoothTransformation))
            else:
                preview.setText('Foto nao disponivel / aguardando')
            preview.setMinimumSize(310,310)
            v.addWidget(preview)
            meta=QLabel(str(item.get('method') or 'Sem metodo'))
            meta.setWordWrap(True);v.addWidget(meta)
            grid.addWidget(box,i//4,i%4)
        sc.setWidget(holder);outer.addWidget(sc,1)
        close=QPushButton('FECHAR');close.clicked.connect(dlg.accept);outer.addWidget(close)
        dlg.exec()

    def _ad_show_mask(self):
        item=self._ad_current_image_item()
        if not item:
            QMessageBox.information(self,"Máscara","Selecione uma foto na tabela.");return
        p=Path(str(item.get("mask_path") or ""))
        if not p.exists():
            QMessageBox.information(self,"Máscara","Esta foto ainda não possui uma máscara válida. Veja o diagnóstico para saber por quê.");return
        dlg=QDialog(self);dlg.setWindowTitle("Máscara do recorte — branco = produto");dlg.resize(720,720);lay=QVBoxLayout(dlg);lab=QLabel();lab.setAlignment(Qt.AlignCenter);pix=QPixmap(str(p));lab.setPixmap(pix.scaled(680,640,Qt.KeepAspectRatio,Qt.SmoothTransformation));lay.addWidget(lab,1);hint=QLabel("Branco deve cobrir somente o produto; preto deve ser o fundo.");hint.setObjectName("Hint");hint.setAlignment(Qt.AlignCenter);lay.addWidget(hint);dlg.exec()

    def _ad_pick_print_file(self):
        path,_=QFileDialog.getOpenFileName(self,"Selecionar 3MF / G-code",str(Path.home()),"Arquivos de impressão (*.3mf *.gcode *.gc);;Todos os arquivos (*)")
        if not path:return
        try:result=parse_print_file(path)
        except ThreeMFNotSlicedError as e:QMessageBox.warning(self,"Arquivo sem dados",str(e));return
        except ThreeMFError as e:QMessageBox.critical(self,"Arquivo de impressão",str(e));return
        except Exception as e:logging.exception("ad print parse");QMessageBox.critical(self,"Arquivo de impressão",str(e));return
        self.ad_print_result=result;self.ad_print_path.setText(path)
        fil=aggregate_plate_filaments(result.plates);self.ad_detected_colors=[(f.friendly_name or "Cor",f.filament_type or "",float(f.used_g or 0)) for f in fil if float(f.used_g or 0)>0]
        total=sum(x[2] for x in self.ad_detected_colors);hours=sum(float(p.print_hours or 0) for p in result.plates)
        self.ad_weight.setValue(total);self.ad_hours.setValue(hours);self._ad_fill_colors(self.ad_detected_colors)
        if not self.ad_product_name.text().strip():
            name=Path(path).name
            for suffix in (".gcode.3mf",".3mf",".gcode",".gc"):
                if name.lower().endswith(suffix):name=name[:-len(suffix)];break
            self.ad_product_name.setText(clean_model_name(name))
        self._ad_recalculate(force_price=True);self._ad_generate_seo();self.ad_state.setText(f"Arquivo lido: {total:.2f} g • {hours:.2f} h • {len(self.ad_detected_colors)} cor(es).")

    def _ad_fill_colors(self,rows):
        if not hasattr(self,"ad_colors_table"):return
        self.fill(self.ad_colors_table,[[a,b or "—",f"{float(c):.2f} g"] for a,b,c in rows])

    def _ad_recalculate(self,*_,force_price=False):
        if not hasattr(self,"ad_cost_summary"):return
        s=all_settings();pack=float(s.get("default_packaging_cost",0.30) or 0.30);v=_pricing(self.ad_weight.value(),self.ad_hours.value(),pack,0,s)
        if force_price or self.ad_price.value()<=0:self.ad_price.setValue(v["suggested"])
        self.ad_cost_summary.setText(f'Custo estimado: {_brl(v["total"])}\nPreço sugerido: {_brl(v["suggested"])}\nLucro estimado: {_brl(v["profit"])}')

    def _ad_generate_seo(self):
        if not hasattr(self,"ad_product_name"):return
        result=getattr(self,"ad_current_result",None)
        source_title=getattr(result,"title","") or ""
        source_tags=list(getattr(result,"tags",[]) or [])
        source_description=getattr(result,"description","") or ""
        name=self.ad_product_name.text().strip() or _best_ptbr_name(result)
        height=self.ad_product_height.value()
        material=self.ad_material.currentText()
        image_path=""
        for item in getattr(self,"ad_current_images",[]) or []:
            candidate=str(item.get("original_path") or "").strip()
            if candidate and Path(candidate).exists():
                image_path=candidate;break
        # Automatic SEO is always offline and immediate. External text models
        # run only when explicitly requested, in a background thread.
        clean_source=_best_ptbr_name(result) if result is not None else name
        clean_source=clean_model_name(clean_source) or clean_model_name(name) or 'Personagem'
        data={'product_name':clean_source,
              'title':generate_seo_title(clean_source,height),
              'description':generate_description(clean_source,height,material),
              'category':suggest_shopee_category(clean_source,source_title,source_tags,source_description),
              'variations':'','provider_used':'','provider_status':'local_sem_api'}
        final_name=clean_model_name(data.get("product_name") or name) or name
        self.ad_product_name.setText(final_name)
        self.ad_title.setText(str(data.get("title") or generate_seo_title(final_name,height)))
        self.ad_description.setPlainText(str(data.get("description") or generate_description(final_name,height,material)))
        category=str(data.get("category") or suggest_shopee_category(final_name,source_title,source_tags,source_description)).strip()
        if category:
            self.ad_category.setText(category)
        variations=str(data.get("variations") or "").strip()
        if variations and hasattr(self,"ad_variations") and not self.ad_variations.toPlainText().strip():
            self.ad_variations.setPlainText(variations)
        provider=str(data.get("provider_used") or "").strip()
        status=str(data.get("provider_status") or "fallback_local")
        if provider and status=="ok":
            self.ad_state.setText(f"SEO/categoria gerados com IA ({provider}).")
        elif provider:
            self.ad_state.setText(f"SEO/categoria gerados localmente. IA tentou {provider} mas retornou {status}.")
        else:
            self.ad_state.setText("SEO/categoria gerados localmente.")
        self._ad_update_plan_hint();self._ad_refresh_ai_status();self._ad_write_ai_plan()

    def _ad_reprocess_done(self, results):
        ok=0;errors=[]
        for res in results:
            row=int(res.get('row',-1))
            if row<0 or row>=len(self.ad_current_images):continue
            item=self.ad_current_images[row]
            if res.get('success'):
                item.update(edited_path=str(res.get('out') or ''),
                            status=res.get('status','LOCAL OK'),method=res.get('method','-'),
                            diagnostic=res.get('message',''),traceback=res.get('traceback',''),
                            mask_path=res.get('mask_path',''),public_url='',
                            selected=0 if res.get('metrics',{}).get('review') else 1)
                ok+=1
            else:
                errors.append(f"Foto {row+1}: {res.get('message') or 'erro no recorte'}")
        self._ad_refresh_images_table()
        self.ad_state.setText(f'Reprocessamento concluido: {ok} OK; {len(errors)} falha(s).')
        if errors:
            QMessageBox.warning(self,'Diagnostico de fotos','Algumas fotos falharam:\n\n'+'\n'.join(errors[:6]))

    def _ad_reprocess_cleanup(self):
        if getattr(self,'ad_reprocess_worker',None): self.ad_reprocess_worker.deleteLater()
        if getattr(self,'ad_reprocess_thread',None): self.ad_reprocess_thread.deleteLater()
        self.ad_reprocess_worker=None;self.ad_reprocess_thread=None
        if hasattr(self,'ad_reprocess_btn'):self.ad_reprocess_btn.setEnabled(True)
        self.ad_steps.widget(1).setEnabled(True)

    def _ad_test_ai_done(self, payload):
        result=payload['result']
        if result.get('success'):
            self.ad_state.setText('IA externa OK: '+str(result.get('method')))
            QMessageBox.information(self,'Teste IA externa',f"Sucesso: {result.get('method')}\n{payload.get('out')}")
        else:
            details='\n'.join(result.get('attempts') or [])[-1800:]
            self.ad_state.setText('IA externa falhou; consulte o erro.')
            QMessageBox.warning(self,'Teste IA externa',f"Falhou: {result.get('message')}\n{details}")

    def _ad_test_ai_cleanup(self):
        if getattr(self,'ad_test_worker',None):self.ad_test_worker.deleteLater()
        if getattr(self,'ad_test_thread',None):self.ad_test_thread.deleteLater()
        self.ad_test_worker=None;self.ad_test_thread=None
        self.ad_test_ai_btn.setEnabled(True)

    def _ad_generate_seo_external(self):
        if getattr(self,'ad_seo_thread',None):return
        result=getattr(self,'ad_current_result',None)
        image_path=''
        for item in getattr(self,'ad_current_images',[]) or []:
            p=Path(str(item.get('original_path') or ''))
            if p.is_file():image_path=str(p);break
        args={'product_name':self.ad_product_name.text().strip(),
              'source_title':getattr(result,'title','') or '',
              'tags':list(getattr(result,'tags',[]) or []),
              'description':getattr(result,'description','') or '',
              'material':self.ad_material.currentText(),
              'height_cm':self.ad_product_height.value(),
              'image_path':image_path}
        self.ad_seo_ai_btn.setEnabled(False)
        self.ad_state.setText('Gerando SEO via IA externa (pode cobrar)...')
        self.ad_seo_thread=QThread(self)
        self.ad_seo_worker=_AdSeoExternalWorker(args)
        self.ad_seo_worker.moveToThread(self.ad_seo_thread)
        self.ad_seo_thread.started.connect(self.ad_seo_worker.run)
        self.ad_seo_worker.finished.connect(self._ad_seo_ai_done)
        self.ad_seo_worker.finished.connect(self.ad_seo_thread.quit)
        self.ad_seo_thread.finished.connect(self._ad_seo_ai_cleanup)
        self.ad_seo_thread.start()

    def _ad_seo_ai_done(self,data):
        if data.get('provider_status') != 'ok':
            self.ad_state.setText('IA de SEO indisponivel; texto local foi mantido.')
            return
        name=clean_model_name(data.get('product_name') or '')
        if name:self.ad_product_name.setText(name)
        if data.get('title'):self.ad_title.setText(str(data['title'])[:120])
        if data.get('description'):self.ad_description.setPlainText(str(data['description']))
        if data.get('category'):self.ad_category.setText(str(data['category']))
        self.ad_state.setText('SEO concluido via IA: '+str(data.get('provider_used','')))

    def _ad_seo_ai_cleanup(self):
        if getattr(self,'ad_seo_worker',None):self.ad_seo_worker.deleteLater()
        if getattr(self,'ad_seo_thread',None):self.ad_seo_thread.deleteLater()
        self.ad_seo_worker=None;self.ad_seo_thread=None
        self.ad_seo_ai_btn.setEnabled(True)

    def _ad_plan_payload(self):
        result=getattr(self,"ad_current_result",None)
        product_name=self.ad_product_name.text().strip() or _best_ptbr_name(result)
        images=getattr(self,"ad_current_images",[]) or []
        ensure_provider_config(AI_PROVIDER_CONFIG_PATH)
        payload = {
            "version":"0.5.2",
            "product_name":product_name,
            "photo_rules":{
                "count":9,
                "cover":"Somente personagem com fundo branco; pode combinar duas poses reais sem inventar.",
                "white_slots":[1,2,3,4,5,6],
                "handheld_slots":[7,8],
                "scene_slots":[9],
                "handheld_source_policy":"Foto 7 prefere a primeira foto valida; Foto 8 prefere a segunda.",
                "scene_source_policy":"Foto 9 prefere a segunda foto valida.",
                "max_output_bytes":int(SHOPEE_MAX_IMAGE_BYTES),
                "provider_policy":"Executar Gemini/OpenAI de verdade para imagem; rotacionar em caso de falha; somente então usar fallback local.",
            },
            "slots":build_standard_plan(images, product_name, SHOPEE_MAX_IMAGE_BYTES),
        }
        return enrich_jobs(payload)

    def _ad_plan_base_dir(self):
        images=getattr(self,"ad_current_images",[]) or []
        for item in images:
            for key in ("edited_path","original_path","mask_path"):
                raw=str(item.get(key) or "").strip()
                if raw:
                    p=Path(raw)
                    if p.exists():
                        return p.parent.parent if p.parent.name in {"editadas","originais"} else p.parent
        return None

    def _ad_write_ai_plan(self):
        try:
            payload=self._ad_plan_payload()
            base=self._ad_plan_base_dir()
            if base:
                out=Path(base)/"ai_photo_plan_v038.json"
                out.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
            return payload
        except Exception:
            logging.exception("write ai photo plan")
            return None

    def _ad_update_plan_hint(self):
        if not hasattr(self,"ad_plan_hint"):
            return
        payload=self._ad_plan_payload()
        slots=payload.get("slots",[])
        hand1=next((x for x in slots if int(x.get("slot",0))==7),{})
        hand2=next((x for x in slots if int(x.get("slot",0))==8),{})
        scene=next((x for x in slots if int(x.get("slot",0))==9),{})
        self.ad_plan_hint.setText(
            f"Padrão automático: 9 fotos. 7 usa base {hand1.get('source_position') or '-'}; 8 usa base {hand2.get('source_position') or '-'}; 9 usa base {scene.get('source_position') or '-'}. Limite Shopee: até {SHOPEE_MAX_IMAGE_BYTES/1_000_000:.1f} MB por imagem."
        )

    def _ad_refresh_ai_status(self):
        if not hasattr(self,"ad_ai_status"):
            return
        try:
            info=router_summary()
            path=str(info.get("config_path") or AI_PROVIDER_CONFIG_PATH)
            tip = " Preencha a chave no ai_provider_settings.json para ativar Gemini/OpenAI." if int(info.get("providers_ready") or 0) == 0 else ""
            last=last_image_status()
            if last.get("ok"):
                image_real=f"Última imagem REAL: {last.get('provider')}/{last.get('model')} OK"
            elif last:
                image_real="Última imagem REAL: falhou (veja TESTAR IA EXTERNA)"
            else:
                image_real="Última imagem REAL: ainda não testada"
            current_mode=self.ad_photo_mode.currentText() if hasattr(self,'ad_photo_mode') else 'não selecionado'
            self.ad_ai_status.setText(f"MODO ATIVO: {current_mode} | {image_real}. {info.get('status_text','sem dados')}. O modo grátis NÃO chama API. Configuração: {path}.{tip}")
        except Exception as e:
            logging.exception("ai status")
            self.ad_ai_status.setText(f"Integração IA: falhou ao carregar configuração ({e}).")

    def _ad_collect(self):
        self._ad_sync_images_table();s=all_settings();result=getattr(self,"ad_current_result",None)
        description=(self.ad_description.toPlainText().strip()+_variation_block(getattr(self,"ad_variations",None).toPlainText() if hasattr(self,"ad_variations") else "")).strip()
        return {
            "makerworld_url":self.ad_mw_url.text().strip(),"source_title":getattr(result,"title","") or "","source_description":getattr(result,"description","") or "",
            "source_creator":getattr(result,"creator","") or "","source_license":getattr(result,"license","") or "","source_model_id":getattr(result,"model_id","") or "","source_profile_id":getattr(result,"profile_id","") or "","source_tags":", ".join(getattr(result,"tags",[]) or []),
            "product_name":self.ad_product_name.text().strip(),"sku":self.ad_sku.text().strip(),"main_sku":self.ad_sku.text().strip(),"variant_id":self.ad_product_combo.currentData(),
            "title":self.ad_title.text().strip(),"description":description,"material":self.ad_material.currentText(),"product_height_cm":self.ad_product_height.value(),"category_id":self.ad_category.text().strip(),
            "price":self.ad_price.value(),"stock":self.ad_stock.value(),"weight_g":self.ad_weight.value(),"print_hours":self.ad_hours.value(),
            "length_cm":self.ad_length.value(),"width_cm":self.ad_width.value(),"height_cm":self.ad_height.value(),"preorder_days":int(float(s.get("shopee_default_preorder_days",3) or 3)),
            "ncm":s.get("shopee_ncm","") or "","cfop_same":s.get("shopee_cfop_same","") or "","cfop_diff":s.get("shopee_cfop_diff","") or "","product_origin":s.get("shopee_origin","") or "",
            "csosn":s.get("shopee_csosn","") or "","cest":s.get("shopee_cest","") or "","measure_unit":s.get("shopee_measure_unit","UN") or "UN",
            "pis_cofins_cst":s.get("shopee_pis_cofins_cst","") or "","tax_total_pct":s.get("shopee_tax_total_pct","") or "","operation_type":s.get("shopee_operation_type","") or "","ex_tipi":s.get("shopee_ex_tipi","") or "","fci_num":s.get("shopee_fci_num","") or "","recopi_num":s.get("shopee_recopi_num","") or "","additional_info":s.get("shopee_additional_info","") or "",
            "xpress_cpf":s.get("shopee_xpress_cpf","Ativado") or "Ativado","pickup":s.get("shopee_pickup","Desativado") or "Desativado",
            "print_file":self.ad_print_path.text().strip(),
        }

    def _ad_ensure_product(self,ad):
        vid=ad.get("variant_id")
        if vid or not getattr(self,"ad_create_product",None) or not self.ad_create_product.isChecked():
            return vid
        name=str(ad.get("product_name") or "").strip()
        if not name:
            return None
        sku=str(ad.get("sku") or "").strip();now=datetime.now().isoformat(timespec="seconds")
        with db() as con:
            if sku:
                existing=con.execute("SELECT id FROM variants WHERE TRIM(sku)=? OR variant_key=? LIMIT 1",(sku,f"SKU:{sku}")).fetchone()
                if existing:
                    vid=int(existing["id"]);self.refresh_ad_creator();ix=self.ad_product_combo.findData(vid)
                    if ix>=0:self.ad_product_combo.setCurrentIndex(ix)
                    return vid
            key=f"SKU:{sku}" if sku else f"AD:{datetime.now().strftime('%Y%m%d%H%M%S%f')}"
            pack=float(all_settings().get("default_packaging_cost",0.30) or 0.30)
            con.execute("""INSERT INTO variants(variant_key,sku,main_sku,listing_name,variation_name,boneco_name,weight_g,print_hours,manual_cost,packaging_cost,other_cost,notes,active,created_at,updated_at)
                           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                        (key,sku,sku,name,name,name,float(ad.get("weight_g") or 0),float(ad.get("print_hours") or 0),0.0,pack,0.0,
                         "Cadastro criado pela aba Criação de anúncio",1,now,now))
            vid=int(con.execute("SELECT last_insert_rowid() id").fetchone()["id"])
        # Refresh the selector so this new product becomes the canonical base of the draft.
        self.refresh_ad_creator();ix=self.ad_product_combo.findData(vid)
        if ix>=0:self.ad_product_combo.setCurrentIndex(ix)
        return vid

    def _ad_apply_to_product(self,ad):
        vid=ad.get("variant_id")
        if not vid or not self.ad_apply_product.isChecked():return
        now=datetime.now().isoformat(timespec="seconds");colors=getattr(self,"ad_detected_colors",[]) or []
        with db() as con:
            con.execute("UPDATE variants SET weight_g=?,print_hours=?,manual_cost=0,updated_at=? WHERE id=?",(ad["weight_g"],ad["print_hours"],now,vid))
            if colors:
                if len(colors)>8:raise ValueError("O arquivo tem mais de 8 cores agrupadas; ajuste o cadastro antes de aplicar ao produto.")
                con.execute("DELETE FROM variant_colors WHERE variant_id=?",(vid,))
                for slot,(name,_mat,g) in enumerate(colors,1):con.execute("INSERT INTO variant_colors(variant_id,slot,color_name,grams_per_unit) VALUES (?,?,?,?)",(vid,slot,name,g))
                sync_variant_weight_from_colors(con,vid)
        self.invalidate_data_pages()

    def _ad_save_draft(self,show_message=True):
        ad=self._ad_collect()
        if not ad["product_name"]:
            QMessageBox.warning(self,"Rascunho","Preencha o nome do produto.");return None
        now=datetime.now().isoformat(timespec="seconds")
        cols=["makerworld_url","source_title","source_description","source_creator","source_license","source_model_id","source_profile_id","source_tags","product_name","sku","variant_id","title","description","material","product_height_cm","category_id","price","stock","weight_g","print_hours","length_cm","width_cm","height_cm","preorder_days","ncm","cfop_same","cfop_diff","product_origin","csosn","cest","measure_unit","print_file"]
        try:
            vid=self._ad_ensure_product(ad)
            if vid:
                ad["variant_id"]=vid
            with db() as con:
                if getattr(self,"ad_draft_id",None):
                    sets=",".join(f"{c}=?" for c in cols)+",updated_at=?";vals=[ad.get(c) for c in cols]+[now,self.ad_draft_id];con.execute(f"UPDATE ad_drafts SET {sets} WHERE id=?",vals);did=self.ad_draft_id
                else:
                    qs=",".join("?" for _ in cols+['created_at','updated_at']);con.execute(f"INSERT INTO ad_drafts({','.join(cols)},created_at,updated_at) VALUES ({qs})",[ad.get(c) for c in cols]+[now,now]);did=con.execute("SELECT last_insert_rowid() id").fetchone()["id"];self.ad_draft_id=did
                con.execute("DELETE FROM ad_images WHERE draft_id=?",(did,))
                for item in getattr(self,"ad_current_images",[]):
                    con.execute("INSERT INTO ad_images(draft_id,position,source_url,original_path,edited_path,public_url,selected) VALUES (?,?,?,?,?,?,?)",(did,int(item.get("position",0)),item.get("source_url","") or "",item.get("original_path","") or "",item.get("edited_path","") or "",item.get("public_url","") or "",int(bool(item.get("selected",1)))))
            self._ad_apply_to_product(ad)
        except Exception as e:
            logging.exception("save ad draft");QMessageBox.critical(self,"Rascunho",f"Não consegui salvar o anúncio:\n\n{e}");return None
        self.ad_state.setText(f"Rascunho #{self.ad_draft_id} salvo.");self.mark_dirty("Produtos","Mapeamento","Precificação")
        if show_message:QMessageBox.information(self,"Criação de anúncio","Rascunho salvo no ERP.")
        return self.ad_draft_id

    def _ad_export_shopee(self):
        if getattr(self,'ad_reprocess_thread',None):
            QMessageBox.information(self,"Fotos","Aguarde o reprocessamento das fotos terminar antes de exportar.");return
        if getattr(self,"ad_upload_thread",None):
            QMessageBox.information(self,"Fotos","Aguarde o envio das fotos terminar.");return
        ad=self._ad_collect()
        if not ad["title"] or len(ad["title"])<2:
            QMessageBox.warning(self,"Exportação","Gere ou preencha o título do anúncio.");return
        if len(ad["description"])<10:
            QMessageBox.warning(self,"Exportação","Preencha a descrição do anúncio.");return
        if ad["weight_g"]<=0 or ad["price"]<=0:
            QMessageBox.warning(self,"Exportação","Peso e preço precisam estar preenchidos.");return
        if min(ad["length_cm"],ad["width_cm"],ad["height_cm"])<=0:
            QMessageBox.warning(self,"Exportação","Preencha comprimento, largura e altura para evitar rejeição do frete na Shopee.");return
        self._ad_sync_images_table();selected=[x for x in getattr(self,"ad_current_images",[]) if x.get("selected",1)]
        if not selected:
            QMessageBox.warning(self,"Exportação","Selecione pelo menos uma foto aprovada para o anúncio.");return
        invalid=[x for x in selected if not self._ad_image_is_valid(x)]
        if invalid:
            QMessageBox.warning(self,"Exportação","Há foto(s) sem recorte aprovado. Reprocesse ou desmarque essas imagens antes de exportar.");return
        if not self._ad_save_draft(False):return
        if any(not str(x.get("public_url") or "").strip() for x in selected):
            self._ad_start_photo_upload(True);return
        self._ad_do_export()

    def _ad_start_photo_upload(self,export_after=False):
        if getattr(self,'ad_reprocess_thread',None):
            QMessageBox.information(self,"Fotos","Aguarde o reprocessamento terminar antes de hospedar.");return
        if getattr(self,"ad_upload_thread",None):
            QMessageBox.information(self,"Fotos","Ja existe um envio em andamento.");return
        self._ad_sync_images_table()
        selected=[x for x in self.ad_current_images if x.get('selected')]
        if not selected or any(not self._ad_image_is_valid(x) for x in selected):
            QMessageBox.warning(self,"Fotos","Selecione pelo menos uma foto valida para hospedar.");return
        missing=[x for x in selected if not str(x.get('public_url') or '').strip()]
        if not missing:
            self.ad_state.setText('As fotos selecionadas ja possuem URLs publicas.')
            if export_after:self._ad_do_export()
            return
        settings=all_settings();cloud=str(settings.get('cloudinary_cloud_name') or '').strip();preset=str(settings.get('cloudinary_upload_preset') or '').strip()
        if not cloud or not preset:
            QMessageBox.warning(self,"Hospedagem das fotos","Configure Cloudinary Cloud Name e Upload Preset unsigned em Configuracoes > Fotos. Alternativamente, cole URLs diretas publicas na tabela. A planilha nao anexa os arquivos locais.");return
        answer=QMessageBox.question(self,"Hospedar fotos",f"Enviar {len(missing)} foto(s) para sua conta Cloudinary e gerar links publicos? O uso segue os limites e custos da sua conta.",QMessageBox.Yes|QMessageBox.No,QMessageBox.No)
        if answer!=QMessageBox.Yes:return
        self.ad_upload_then_export=export_after
        self.ad_steps.widget(1).setEnabled(False)
        self.ad_upload_thread=QThread(self);self.ad_upload_worker=_AdUploadWorker(self.ad_current_images,cloud,preset);self.ad_upload_worker.moveToThread(self.ad_upload_thread)
        self.ad_upload_thread.started.connect(self.ad_upload_worker.run)
        self.ad_upload_worker.progress.connect(self.ad_state.setText)
        self.ad_upload_worker.updated.connect(self._ad_upload_partial)
        self.ad_upload_worker.finished.connect(self._ad_upload_done);self.ad_upload_worker.error.connect(self._ad_upload_error)
        self.ad_upload_worker.finished.connect(self.ad_upload_thread.quit);self.ad_upload_worker.error.connect(self.ad_upload_thread.quit)
        self.ad_upload_thread.finished.connect(self._ad_upload_cleanup);self.ad_upload_thread.start()

    def _ad_upload_partial(self,images):
        self.ad_current_images=images;self._ad_refresh_images_table()
        if self.ad_product_name.text().strip():self._ad_save_draft(False)

    def _ad_upload_done(self,images):
        self._ad_upload_partial(images)
        self.ad_state.setText('Fotos hospedadas. URLs prontas para a planilha.')
        if self.ad_upload_then_export:self._ad_do_export()

    def _ad_upload_error(self,text):
        self.ad_state.setText('Envio interrompido. Os links ja recebidos foram mantidos; tente novamente para enviar as fotos restantes.')
        QMessageBox.critical(self,"Upload das fotos",text)

    def _ad_upload_cleanup(self):
        if getattr(self,"ad_upload_worker",None):self.ad_upload_worker.deleteLater()
        if getattr(self,"ad_upload_thread",None):self.ad_upload_thread.deleteLater()
        self.ad_upload_worker=None;self.ad_upload_thread=None;self.ad_upload_then_export=False
        self.ad_steps.widget(1).setEnabled(True)

    def _ad_do_export(self):
        ad=self._ad_collect();urls=[str(x.get("public_url") or "").strip() for x in self.ad_current_images if x.get("selected",1) and str(x.get("public_url") or "").strip()]
        if not urls:
            QMessageBox.warning(self,"Exportação","Nenhuma URL pública de foto disponível.");return
        safe=re.sub(r"[^A-Za-z0-9_-]+","_",_norm(ad["product_name"]).replace(" ","_")).strip("_") or "produto"
        default=EXPORT_DIR/f"Shopee_{safe}_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx"
        path,_=QFileDialog.getSaveFileName(self,"Salvar planilha Shopee",str(default),"Excel (*.xlsx)")
        if not path:return
        if not path.lower().endswith(".xlsx"):path+=".xlsx"
        try:
            out=export_shopee_template(TEMPLATES_DIR/"Shopee_mass_upload_template.xlsx",path,ad,urls)
            if getattr(self,"ad_draft_id",None):
                with db() as con:con.execute("UPDATE ad_drafts SET status='EXPORTADO',updated_at=? WHERE id=?",(datetime.now().isoformat(timespec="seconds"),self.ad_draft_id))
            self.ad_state.setText(f"Planilha exportada: {Path(out).name}")
            QMessageBox.information(self,"Shopee",f"Planilha pronta para upload.\n\n{out}\n\nAs fotos foram preenchidas como URLs públicas no template.")
        except ShopeeExportError as e:QMessageBox.critical(self,"Exportação Shopee",str(e))
        except Exception as e:logging.exception("shopee export");QMessageBox.critical(self,"Exportação Shopee",str(e))

    # -------------------------------- MAPEAMENTO ---------------------------------
    def make_mapping(self):
        w,l=self.shell("Mapeamento de SKUs","Use esta aba quando anúncios diferentes usam SKUs diferentes para o mesmo personagem. O SKU de origem continua rastreável, mas custos, cores e agrupamento dos relatórios passam a usar o produto de destino.")
        filters=QHBoxLayout();self.map_search=QLineEdit();self.map_search.setPlaceholderText("Buscar SKU, boneco, anúncio ou destino...");self._connect_debounced(self.map_search,self.refresh_mapping,"map_search")
        self.map_status=QComboBox();self.map_status.addItems(["Todos","Somente mapeados","Somente não mapeados"]);self.map_status.currentIndexChanged.connect(self.refresh_mapping)
        filters.addWidget(self.map_search,3);filters.addWidget(self.map_status,1);l.addLayout(filters)
        self.map_table=self.table(["Boneco atual","SKU origem","Anúncio / variação","Mapeado para","SKU destino","Status"],2);self.map_table.itemSelectionChanged.connect(self._mapping_selection_changed);l.addWidget(self.map_table,1)
        box=QFrame();box.setObjectName("Panel");bh=QHBoxLayout(box);bh.setContentsMargins(12,10,12,10)
        self.map_target=QComboBox();self.map_target.setMinimumWidth(500);self.map_note=QLineEdit();self.map_note.setPlaceholderText("Observação opcional")
        save=QPushButton("MAPEAR SKU SELECIONADO");save.clicked.connect(self._mapping_save);remove=QPushButton("REMOVER MAPEAMENTO");remove.setObjectName("Secondary");remove.clicked.connect(self._mapping_remove)
        bh.addWidget(QLabel("Produto correto:"));bh.addWidget(self.map_target,2);bh.addWidget(self.map_note,1);bh.addWidget(save);bh.addWidget(remove);l.addWidget(box)
        hint=QLabel("Exemplo: se SKU 000041 e SKU SONIC-A representam o mesmo Sonic, selecione o SKU errado/alternativo na tabela e mapeie para o cadastro principal do Sonic. Pedidos antigos e futuros continuam mantendo o SKU original para auditoria.");hint.setObjectName("Hint");hint.setWordWrap(True);l.addWidget(hint)
        return w

    def refresh_mapping(self):
        if not hasattr(self,"map_table"):return
        search=_norm(self.map_search.text()) if hasattr(self,"map_search") else "";status=self.map_status.currentText() if hasattr(self,"map_status") else "Todos";current_target=self.map_target.currentData() if hasattr(self,"map_target") else None
        with db() as con:
            rows=con.execute("""SELECT v.id,v.boneco_name,v.sku,v.listing_name,v.variation_name,vm.target_variant_id,vm.notes,
                                       tv.boneco_name target_boneco,tv.sku target_sku,tv.variation_name target_var,tv.listing_name target_listing
                                FROM variants v LEFT JOIN variant_mappings vm ON vm.source_variant_id=v.id LEFT JOIN variants tv ON tv.id=vm.target_variant_id
                                WHERE v.active=1 ORDER BY v.boneco_name,v.sku,v.id""").fetchall()
            targets=con.execute("SELECT id,boneco_name,sku,variation_name,listing_name FROM variants WHERE active=1 ORDER BY boneco_name,sku,id").fetchall()
        self.map_target.blockSignals(True);self.map_target.clear();self.map_target.addItem("Selecione o produto correto...",None)
        for r in targets:
            name=r["boneco_name"] or r["variation_name"] or r["listing_name"] or "Produto";self.map_target.addItem(f'{name} • SKU {r["sku"] or "—"} • {r["variation_name"] or "sem variação"}',r["id"])
        ix=self.map_target.findData(current_target)
        if ix>=0:self.map_target.setCurrentIndex(ix)
        self.map_target.blockSignals(False)
        out=[];ids=[]
        for r in rows:
            mapped=bool(r["target_variant_id"])
            if status=="Somente mapeados" and not mapped:continue
            if status=="Somente não mapeados" and mapped:continue
            source_name=r["boneco_name"] or r["variation_name"] or r["listing_name"] or "—";target_name=r["target_boneco"] or r["target_var"] or r["target_listing"] or "—"
            blob=_norm(" ".join([source_name,r["sku"] or "",r["listing_name"] or "",r["variation_name"] or "",target_name,r["target_sku"] or ""]))
            if search and search not in blob:continue
            out.append([source_name,r["sku"] or "—",f'{r["listing_name"] or "—"} • {r["variation_name"] or "sem variação"}',target_name if mapped else "—",r["target_sku"] or "—","MAPEADO" if mapped else "PENDENTE"]);ids.append(r["id"])
        self.fill(self.map_table,out,ids)

    def _mapping_source_id(self):
        r=self.map_table.currentRow() if hasattr(self,"map_table") else -1
        if r<0 or not self.map_table.item(r,0):return None
        return self.map_table.item(r,0).data(Qt.UserRole)

    def _mapping_selection_changed(self):
        sid=self._mapping_source_id()
        if not sid:return
        with db() as con:r=con.execute("SELECT target_variant_id,notes FROM variant_mappings WHERE source_variant_id=?",(sid,)).fetchone()
        if r:
            ix=self.map_target.findData(r["target_variant_id"])
            if ix>=0:self.map_target.setCurrentIndex(ix)
            self.map_note.setText(r["notes"] or "")
        else:
            self.map_target.setCurrentIndex(0);self.map_note.clear()

    def _mapping_save(self):
        source=self._mapping_source_id();target=self.map_target.currentData()
        if not source:
            QMessageBox.information(self,"Mapeamento","Selecione um SKU na tabela.");return
        if not target:
            QMessageBox.information(self,"Mapeamento","Escolha o produto correto no campo Produto correto.");return
        if source==target:
            QMessageBox.warning(self,"Mapeamento","Origem e destino são o mesmo cadastro. Não é necessário mapear.");return
        with db() as con:
            seen={source};root=int(target)
            for _ in range(20):
                if root in seen:
                    QMessageBox.critical(self,"Mapeamento","Esse mapeamento criaria um ciclo. Escolha o produto principal/canônico como destino.");return
                seen.add(root);r=con.execute("SELECT target_variant_id FROM variant_mappings WHERE source_variant_id=?",(root,)).fetchone()
                if not r:break
                root=int(r["target_variant_id"])
            con.execute("INSERT INTO variant_mappings(source_variant_id,target_variant_id,notes,updated_at) VALUES (?,?,?,?) ON CONFLICT(source_variant_id) DO UPDATE SET target_variant_id=excluded.target_variant_id,notes=excluded.notes,updated_at=excluded.updated_at",(source,root,self.map_note.text().strip(),datetime.now().isoformat(timespec="seconds")))
        self.invalidate_data_pages();self.mark_dirty("Mapeamento");self.refresh_mapping();QMessageBox.information(self,"Mapeamento","SKU mapeado. Os relatórios e o consumo de filamento passarão a usar os dados do produto de destino.")

    def _mapping_remove(self):
        source=self._mapping_source_id()
        if not source:
            QMessageBox.information(self,"Mapeamento","Selecione um SKU na tabela.");return
        with db() as con:con.execute("DELETE FROM variant_mappings WHERE source_variant_id=?",(source,))
        self.invalidate_data_pages();self.mark_dirty("Mapeamento");self.refresh_mapping()
