from PySide6.QtCore import Qt,QRectF
from PySide6.QtGui import QColor,QPainter,QPen,QFont
from PySide6.QtWidgets import QFrame,QVBoxLayout,QHBoxLayout,QLabel,QWidget,QSizePolicy

class MetricCard(QFrame):
    def __init__(self,title,value="—",subtitle=""):
        super().__init__(); self.setObjectName("MetricCard")
        l=QVBoxLayout(self);l.setContentsMargins(20,18,20,18);l.setSpacing(8)
        t=QLabel(title.capitalize());t.setObjectName("MetricTitle");t.setWordWrap(True)
        self.v=QLabel(value);self.v.setObjectName("MetricValue");self.v.setWordWrap(True);self.v.setTextInteractionFlags(Qt.TextSelectableByMouse);self.v.setMinimumWidth(0);self.v.setSizePolicy(QSizePolicy.Ignored,QSizePolicy.Preferred)
        self.s=QLabel(subtitle);self.s.setObjectName("MetricSubtitle");self.s.setWordWrap(True);self.s.setVisible(bool(subtitle))
        l.addWidget(t);l.addWidget(self.v);l.addWidget(self.s)
    def set_value(self,value,subtitle=None):
        self.v.setText(str(value))
        if subtitle is not None:self.s.setText(str(subtitle));self.s.setVisible(bool(subtitle))

class MultiLineChart(QWidget):
    def __init__(self,title="Evolução"):
        super().__init__();self.title=title;self.labels=[];self.series=[];self.setMinimumHeight(260)
    def set_data(self,labels,series):
        self.labels=list(labels);self.series=list(series);self.update()
    def paintEvent(self,e):
        p=QPainter(self);p.setRenderHint(QPainter.Antialiasing)
        p.fillRect(self.rect(),QColor("#14171e"))
        p.setPen(QColor("#f6f0e7"));p.setFont(QFont("Segoe UI",11,QFont.Bold));p.drawText(18,28,self.title)
        plot=QRectF(52,52,max(20,self.width()-78),max(50,self.height()-94))
        p.setPen(QPen(QColor("#33333b"),1))
        for i in range(5):
            y=plot.top()+i*plot.height()/4;p.drawLine(plot.left(),y,plot.right(),y)
        vals=[v for s in self.series for v in s[1]]
        if not vals:
            p.setPen(QColor("#667080"));p.drawText(plot,Qt.AlignCenter,"Sem dados");return
        mn=min(0,min(vals));mx=max(vals);span=mx-mn or 1
        colors=["#e53949","#f0c16f","#d8dce3","#9f4151"]
        for si,(name,values) in enumerate(self.series):
            pts=[]
            for i,v in enumerate(values):
                x=plot.left()+plot.width()*(i/(max(1,len(values)-1)))
                y=plot.bottom()-((v-mn)/span)*plot.height()
                pts.append((x,y))
            p.setPen(QPen(QColor(colors[si%len(colors)]),2.5))
            for i in range(1,len(pts)):p.drawLine(*pts[i-1],*pts[i])
            p.setBrush(QColor(colors[si%len(colors)]));p.setPen(Qt.NoPen)
            for x,y in pts:p.drawEllipse(QRectF(x-3,y-3,6,6))
        p.setFont(QFont("Segoe UI",8));p.setPen(QColor("#b5adb1"))
        if self.labels:
            for i,lab in enumerate(self.labels):
                if i==len(self.labels)-1 or i%max(1,len(self.labels)//6)==0:
                    x=plot.left()+plot.width()*(i/max(1,len(self.labels)-1))
                    p.drawText(QRectF(x-35,plot.bottom()+7,70,18),Qt.AlignCenter,str(lab))

class BarsChart(QWidget):
    def __init__(self,title="Origem das vendas"):
        super().__init__();self.title=title;self.data=[];self.setMinimumHeight(220)
    def set_data(self,data):self.data=list(data);self.update()
    def paintEvent(self,e):
        p=QPainter(self);p.setRenderHint(QPainter.Antialiasing);p.fillRect(self.rect(),QColor("#14171e"))
        p.setPen(QColor("#f6f0e7"));p.setFont(QFont("Segoe UI",11,QFont.Bold));p.drawText(18,28,self.title)
        if not self.data:
            p.setPen(QColor("#667080"));p.drawText(self.rect(),Qt.AlignCenter,"Sem dados");return
        maxv=max(v for _,v in self.data) or 1
        y=58
        for name,v in self.data:
            p.setPen(QColor("#ddd6d0"));p.setFont(QFont("Segoe UI",9));p.drawText(18,y+13,name)
            bar=QRectF(115,y,self.width()-175,16)
            p.setPen(Qt.NoPen);p.setBrush(QColor("#33333b"));p.drawRoundedRect(bar,5,5)
            fill=QRectF(bar.left(),bar.top(),bar.width()*(v/maxv),bar.height())
            p.setBrush(QColor("#d93040"));p.drawRoundedRect(fill,5,5)
            p.setPen(QColor("#f1c474"));p.drawText(self.width()-55,y+13,f"{v:,.0f}")
            y+=31
