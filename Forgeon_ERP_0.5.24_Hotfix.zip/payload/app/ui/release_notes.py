"""Release history shipped with each hotfix. No personal data."""
RELEASE_NOTES = """
<h1>Versão 0.5.24 — Produtos reunidos por boneco</h1>
<p>Mostra uma linha por nome normalizado, reunindo sufixos como - Hedgehog e repetições idênticas separadas por vírgula. Sonic e Super Sonic continuam separados, mesmo com SKU repetido. Mostra os SKUs e o cadastro mais completo; diferenças de custos e cores são sinalizadas. VER ANÚNCIOS permite consultar e editar os cadastros individuais. Não altera pedidos, SKUs ou vínculos automaticamente.</p>
<p>Mensagem de atualização explica quando o canal não está acessível sem login.</p><hr>

<h1>Versão 0.5.23 — Atualizações pelo próprio ERP</h1>
<p>Consulta o canal oficial ao abrir e pelo botão ATUALIZAR. Quando houver nova versão, permite baixar, verificar integridade, fazer backup e reiniciar para instalar. Falhas de conexão não impedem usar o ERP. Dados e configurações são preservados.</p>
<p>A primeira instalação desta versão é manual. O canal online precisa estar publicado no GitHub e acessível neste computador.</p><hr>

<h1>Versão 0.5.22 — Importação mensal e catálogo de SKUs</h1>
<ul>
<li>Arquivos de pedidos são combinados por ID. Importar um arquivo parcial não apaga os demais pedidos do mês.</li>
<li>Identifica Order.toship como pedidos A Enviar e informa que não representa o mês inteiro.</li>
<li>Produtos vendidos no resumo mensal aparecem no catálogo mesmo sem pedidos detalhados, identificados como resumo sem variações/SKU.</li>
<li>Painel de mais vendidos usa o resumo mensal quando disponível; consumo por cor e custos são sinalizados como parciais se faltam pedidos detalhados.</li>
<li>Na aba existente Vínculos de SKU, inclui SKUs e personagens, reservas manuais/próximo código livre, duplicados em vermelho e correção de SKU.</li>
<li>Não une mais automaticamente cadastros com SKU repetido. Correções preservam custos, cores, vínculos e o código original nos pedidos.</li>
<li>Catálogo crescente de SKUs usa transações para evitar reservas repetidas, preserva zeros e pode ser exportado em Planilhas.</li>
<li>Cria backup consistente do banco antes de adicionar o catálogo de SKUs. Mantém o foco no ERP da versão 0.5.21.</li>
</ul>
<p>O resumo mensal não informa a distribuição por variação de cada anúncio. Para todas as variações e consumo por cor do mês, importe Todos os pedidos (Order.all), não somente A Enviar. Corrigir um SKU no ERP não modifica a Shopee.</p><hr>

<h1>Versão 0.5.21 — Foco no ERP</h1>
<ul>
<li>Retira Criação de anúncio, Creative Studio, edição de fotos e controles de ChatGPT/MCP da interface.</li>
<li>Preserva produtos, pedidos, custos, cores, vínculos de SKU, financeiro, importação Shopee, relatórios e backup.</li>
<li>Adiciona Novo produto para cadastro manual, sem exigir anúncio ou arquivo 3MF.</li>
<li>Nova área Planilhas: exporta produtos/custos e cores, pedidos/itens, financeiro e resumos mensais em Excel.</li>
<li>Valores numéricos são exportados como números; SKUs e identificadores mantêm zeros à esquerda.</li>
<li>Separa vínculos de SKU do módulo de anúncios, removendo a dependência de bibliotecas de edição de fotos na inicialização.</li>
<li>Configurações exibem apenas custos/taxas e fiscal. Dados e preferências anteriores continuam preservados.</li>
</ul>
<p>Esta versão não publica anúncios nem integra a extensão de fotos. Desative a extensão Forgeon no Opera se ainda estiver instalada. Não é necessário remover fotos, perfis, chaves ou bancos existentes. As planilhas de gestão não são modelos de publicação em marketplaces.</p><hr>

<h1>Versão 0.5.20 — Anexos e envio nativos no Opera GX</h1>
<ul>
<li>Usa a API de depuração da extensão para anexar arquivos e inserir texto com eventos nativos do navegador.</li>
<li>Exige fotos reconhecidas antes de inserir o prompt. Botões genéricos de remoção não comprovam anexos.</li>
<li>Aciona clique nativo ou Enter nativo no alvo verificado, sem repetir tentativas automaticamente.</li>
<li>Inclui Cancelar espera e Copiar diagnóstico do envio para identificar a etapa e os controles disponíveis.</li>
<li>Detecta extensão antiga e informa que ela precisa ser recarregada.</li>
</ul>
<p>Recarregue a extensão em opera://extensions e aceite a nova permissão de depuração. Ela se conecta somente à aba exata da conversa Fotos. Testes locais usam CDP e página simulada; validação no Opera GX real ainda necessária. Retorno automático das imagens prontas ainda não implementado.</p><hr>

<h1>Versão 0.5.19 — Usar a aba já aberta no Opera GX</h1>
<ul>
<li>Substitui o iniciador de perfil separado por uma extensão instalada no Opera GX do usuário.</li>
<li>Usa apenas a aba existente com o endereço exato da conversa Fotos, aproveitando o login e os dados locais desse perfil.</li>
<li>Se a aba não estiver aberta, avisa no ERP; não cria janela, aba ou conversa.</li>
<li>Pareamento local protege a transferência das fotos selecionadas e do prompt, sem expor cookies ou senhas ao ERP.</li>
<li>Confirma o prompt e todas as imagens na mensagem enviada; não repete automaticamente tentativas.</li>
</ul>
<p>Instalação e pareamento da extensão são necessários uma vez. Testes em Chromium e página simulada; interface real do ChatGPT e Opera GX no Windows ainda exigem validação no PC. Download/retorno automático dos resultados ainda não implementado.</p><hr>

<h1>Versão 0.5.18 — Envio pelo Opera GX</h1>
<ul>
<li>O envio de fotos e prompt passa a usar Opera GX, conforme o navegador utilizado pelo usuário.</li>
<li>Aceita o endereço da conversa Fotos com caminho /c/ ou /local/, conferindo a página antes do envio.</li>
<li>Detecta instalações comuns por usuário e por máquina. O botão Localizar Opera GX permite informar instalações em outra pasta.</li>
<li>Mantém o endereço salvo da conversa Fotos, reutiliza a mesma aba e usa um perfil próprio do Opera GX com login inicial.</li>
<li>Preserva o perfil anterior do Chrome, sem exigir Chrome para novos envios.</li>
</ul>
<p>Detecção e comando de inicialização testados com instalações simuladas; anexos/prompt testados em Chromium com página de simulação. Opera GX no Windows e envio na conta real ainda precisam ser validados no PC. Retorno automático de imagens ainda não implementado.</p><hr>

<h1>Versão 0.5.17 — Enviar fotos para a conversa Fotos</h1>
<ul>
<li>Configuração do endereço fixo da conversa Fotos existente.</li>
<li>Envio das fotos selecionadas e do prompt pelo Google Chrome, com janela própria e login inicial feito pelo usuário.</li>
<li>Reutiliza a mesma aba e conversa; não abre a página inicial a cada tarefa.</li>
<li>Confere anexos, prompt e mensagem recebida antes de informar envio confirmado. Falhas não disparam reenvio automático.</li>
<li>Protege rascunhos existentes e impede envios simultâneos.</li>
</ul>
<p>Requer Windows e Chrome. A automação usa a interface do ChatGPT e pode exigir ajustes se ela mudar. Validada com navegador e página de teste; envio na conta real depende de teste no PC. A geração e o download automático dos resultados ainda não estão implementados.</p><hr>

<h1>Versão 0.5.16 — Retorno da autorização MCP</h1>
<ul>
<li>Corrige a política de segurança da página que podia bloquear, no navegador, o retorno da autorização ao cliente MCP.</li>
<li>A permissão de formulário considera somente a origem do callback registrado, sem liberar qualquer endereço.</li>
<li>Distingue solicitação realmente expirada, formulário incompleto, autorização já usada e link antigo/ponte reiniciada.</li>
<li>Mantém validação do código local, CSRF, PKCE, tokens e limite de tentativas.</li>
</ul>
<p>Fluxo reproduzido e corrigido em Chromium, com versões do servidor equivalentes às exibidas na instalação Windows. A conexão final na conta real do ChatGPT ainda deve ser confirmada.</p><hr>

<h1>Versão 0.5.15 — Colar imagens</h1>
<ul>
<li>Botão Colar imagem na aba Anúncio &gt; Fotos.</li>
<li>Ctrl+V e o atalho padrão de colar funcionam nessa área quando o foco está fora de campos de texto.</li>
<li>Aceita imagem copiada no navegador/captura de tela e arquivos JPG, PNG ou WebP copiados no Explorador.</li>
<li>Importa como foto pronta, sem recorte ou chamada de IA, mantendo o limite de 9 fotos por anúncio.</li>
<li>Usar fotos da galeria prepara a tarefa e o prompt do ChatGPT com as imagens marcadas, sem precisar procurá-las novamente no disco. O anexo e envio no chat continuam manuais.</li>
<li>Preserva colar texto em título, descrição, URLs e outros campos. Colar não envia imagens à internet.</li>
</ul>
<p>O conteúdo disponível depende do aplicativo de origem. Copiar endereço de imagem não copia a imagem; nesse caso use Copiar imagem ou baixe o arquivo.</p><hr>

<h1>Versão 0.5.14 — Instalação completa do PC de casa</h1>
<ul>
<li>Compatibilidade baseada no app.zip completo enviado pelo usuário, incluindo ad_tools.py personalizado.</li>
<li>Preserva reprocessamento, teste de imagem e SEO externo em segundo plano. SEO automático continua local; a chamada externa exige o botão específico.</li>
<li>Mantém a galeria sem posições vazias artificiais e a seleção de fotos do criador nos perfis do MakerWorld.</li>
<li>Creative Studio e seu módulo de integrações incluídos a partir do código recebido, sem configurações pessoais.</li>
<li>Corrige o caminho de importação do Creative Studio e mantém a extensão separada da inicialização do ERP.</li>
<li>Impede ordenação/remoção de fotos durante reprocessamento e evita fechar o ERP com tarefas Qt em andamento.</li>
</ul>
<p>Testes usam o conjunto de código recebido e dados sintéticos. Integrações externas foram simuladas; programas ArtCraft/VectorCraft/Freebuff, hospedagem real e execução no Windows continuam dependentes do PC do usuário.</p><hr>

<h1>Versão 0.5.13 — Compatibilidade com Creative Studio</h1>
<ul>
<li>Reconhece a variante 0.5.8 enviada pelo usuário que acrescenta a aba Creative Studio.</li>
<li>Preserva o módulo Creative Studio existente e seu acesso pelo menu, quando instalado.</li>
<li>O Creative Studio é carregado ao clicar em Abrir Creative Studio, para que dependências opcionais não bloqueiem a abertura do ERP.</li>
<li>Notas de atualização continuam no fim do menu, com índice independente da presença da extensão.</li>
<li>Mantém localização automática da pasta e comparação compatível com BOM e quebras de linha do Windows.</li>
</ul>
<p>A atualização não inclui nem substitui o código do Creative Studio. O módulo real não foi recebido neste ambiente; foram testados o acesso, o carregamento e o tratamento de falha usando módulos de teste.</p><hr>

<h1>Versão 0.5.12 — Atualização cumulativa e ponte MCP autenticada</h1>
<ul>
<li>Hotfix cumulativo para as bases conhecidas 0.5.8, 0.5.9, 0.5.10 e 0.5.11, sem instalar versões intermediárias.</li>
<li>Modo HTTP do MCP com OAuth, PKCE e autorização pelo código local do ERP.</li>
<li>Iniciador opcional de HTTPS temporário, com instalação isolada do SDK e suporte ao Cloudflare Tunnel.</li>
<li>Botões para iniciar a ponte e copiar URL/código. O código não faz parte do pacote e é criado no seu PC.</li>
<li>Porta local vinculada somente ao próprio computador. A ponte não funciona sem cliente autorizado.</li>
<li>Prompt e fotos continuam disponíveis pelo MCP; anexo/envio e geração no ChatGPT ainda dependem do cliente e não são disparados automaticamente pelo ERP.</li>
</ul>
<p>Testado localmente: OAuth/PKCE, conexão MCP HTTP, retorno de fotos, bloqueio de acessos sem autorização e limites de requisição.
A publicação pelo túnel, o iniciador Windows e a conexão na conta do ChatGPT não foram validados neste ambiente.</p><hr>

<h1>Versão 0.5.11 — Prompt salvo e conector MCP local</h1>
<ul>
<li>Seleção de até 9 fotos, altura do personagem e prompt padronizado em uma tarefa local.</li>
<li>Botão que prepara os arquivos, copia o prompt e abre o ChatGPT e a pasta de originais.</li>
<li>O anexo e o envio da mensagem no ChatGPT continuam manuais; nenhuma geração pela assinatura é automatizada.</li>
<li>Conector MCP opcional por stdio: consulta de tarefas, acesso individual às fotos, prompt salvo, retorno de JPGs editados e consulta básica de produtos.</li>
<li>Importação dos resultados locais do conector para a galeria do anúncio.</li>
<li>O MCP não fornece um editor: o cliente precisa de ferramenta de imagem própria. Não há servidor remoto exposto nem leitura de credenciais de login.</li>
</ul>
<p>Consulte app/integrations/LEIA-ME-MCP.md para instalação opcional e limites.
Transporte MCP e tarefas testados localmente. Integração direta com a interface do ChatGPT não foi estabelecida.</p><hr>

<h1>Versão 0.5.10 — Fotos prontas e hospedagem em lote</h1>
<ul>
<li>Importação de até 9 fotos prontas por anúncio, inclusive imagens editadas no ChatGPT, sem recorte automático ou chamada de IA.</li>
<li>Preservação do enquadramento e dos cenários. Apenas orientação, ajuste ao quadro e compressão para o limite configurado.</li>
<li>Seleção da capa, ordenação e remoção de fotos da galeria sem apagar os arquivos originais.</li>
<li>Botão para hospedar fotos selecionadas em lote no Cloudinary e preencher URLs públicas na planilha Shopee.</li>
<li>Links recebidos antes de uma falha são mantidos, evitando reenviar as mesmas fotos na próxima tentativa.</li>
<li>Confirmação antes do envio das fotos para a conta configurada; nenhuma assinatura de edição de IA é necessária nesse fluxo.</li>
</ul>
<p>Configure Cloudinary Cloud Name e Upload Preset unsigned em Configurações &gt; Fotos.
A hospedagem segue as cotas e custos da sua conta. Não apague as imagens hospedadas enquanto precisar dos links.</p>
<p>Validado localmente com imagens sintéticas, envio simulado e inspeção das URLs na planilha.
O envio real ao Cloudinary e a aceitação pela Shopee dependem da sua conta e não foram testados neste ambiente.</p>
<hr>

<h1>Versão 0.5.9</h1>
<p>Interface reorganizada e atualização por hotfix.</p>
<h2>Interface</h2>
<ul>
<li>Menu organizado por vendas, produção e gestão. Notas de atualização no fim do menu.</li>
<li>Removidos atalhos repetidos do painel inicial; funções continuam disponíveis no menu.</li>
<li>Criação de anúncio em três etapas: Produto e preço, Fotos, Texto e exportação.</li>
<li>Ferramentas avançadas de fotos e diagnóstico recolhidas em um painel expansível.</li>
<li>Configurações divididas em Custos, Shopee e fiscal, Fotos, com busca entre os grupos.</li>
<li>Precificação destaca custo total, preço sugerido, lucro e margem; composição detalhada expansível.</li>
<li>Bordas arredondadas, contraste maior nos campos, títulos e valores mais legíveis.</li>
<li>Campos numéricos alinhados à direita e com formatação brasileira.</li>
</ul>
<h2>Instalação e manutenção</h2>
<ul>
<li>Pacote de instalação limpa para Windows, com ambiente Python isolado e atalhos.</li>
<li>Pacotes de hotfix separados, com conferência de integridade, versão e arquivos-base.</li>
<li>Backup dos arquivos alterados e restauração em caso de falha na aplicação do pacote.</li>
<li>Banco, fotos e configurações pessoais não fazem parte dos pacotes de atualização.</li>
</ul>
<h2>Verificações desta versão</h2>
<p>Interface validada em Linux, sem tela: navegação, etapas, busca, cálculo de preço,
banco de teste e exportação Shopee. Instalação e atalhos no Windows ainda precisam
ser validados no Windows. Integrações externas não foram alteradas nem revalidadas.</p>
<hr>
<h1>Versão 0.5.8 — base recebida</h1>
<p>Ícones de dragões, tema com bordas arredondadas, fundo transparente dos rótulos
 e agrupamento de janela no Windows, conforme o hotfix fornecido.</p>
"""
