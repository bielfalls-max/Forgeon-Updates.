"""Forgeon Creative Studio CS3.1: ferramentas instaladas pelo usuario, sem downloads ocultos.
VectorCraft: API TCP apenas em loopback; ArtCraft: troca explicita de arquivos;
Freebuff: inicializacao em copia de desenvolvimento, nunca executado sobre producao.
"""
import json
import os
import shutil
import socket
import subprocess
import threading
from datetime import datetime
from pathlib import Path
from app.config import APP_ROOT
from PySide6.QtCore import Signal
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QFileDialog, QMessageBox, QGroupBox, QPlainTextEdit, QScrollArea, QApplication
)
from app.services.creative_integrations import (
    vectorcraft_request, vectorcraft_open, vectorcraft_export,
    artcraft_submit_video, artcraft_job_status
)

# Armazena preferências junto à instalação efetiva, sem depender de 'Documentos'.
# Mantém leitura legada sem alterar nem excluir o arquivo anterior.
HOME = Path(APP_ROOT).resolve()
CONFIG = HOME / 'creative_tools.json'
LEGACY_CONFIG = Path.home() / 'Documents' / 'Forgeon Studio ERP' / 'creative_tools.json'
EXCHANGE = HOME / 'creative_exchange' / 'artcraft'
EXPORTS = HOME / 'creative_exports' / 'vectorcraft'


def _load():
    # O arquivo local é prioritário. Se incompleto, recupera as opções legadas
    # sem sobrepor escolhas válidas feitas na instalação atual.
    result = {}
    for path in (LEGACY_CONFIG, CONFIG):
        try:
            obj = json.loads(path.read_text(encoding='utf-8'))
            if isinstance(obj, dict):
                result.update({k: v for k, v in obj.items() if v not in (None, '')})
        except (OSError, ValueError, TypeError):
            pass
    return result


def _save(data):
    # Grava atomicamente para não perder o JSON caso o aplicativo seja fechado.
    import tempfile
    CONFIG.parent.mkdir(parents=True, exist_ok=True)
    temp_path = None
    try:
        with tempfile.NamedTemporaryFile('w', encoding='utf-8', dir=str(CONFIG.parent),
                                         prefix='.creative_tools_', suffix='.tmp',
                                         delete=False) as fh:
            temp_path = Path(fh.name)
            json.dump(data, fh, indent=2, ensure_ascii=False)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(temp_path, CONFIG)
    finally:
        if temp_path is not None and temp_path.exists():
            temp_path.unlink()


def _windows_candidates(program):
    program_files = [os.environ.get('ProgramFiles', ''), os.environ.get('ProgramFiles(x86)', '')]
    local = os.environ.get('LOCALAPPDATA', '')
    variants = [program, program.lower(), program.capitalize()]
    for base in program_files:
        if base:
            for item in variants:
                yield Path(base) / item / (program + '.exe')
    if local:
        for item in variants:
            yield Path(local) / 'Programs' / item / (program + '.exe')
        yield Path(local) / (program + '.exe')
    found = shutil.which(program)
    if found:
        yield Path(found)


def _find_exe(configured, program):
    if configured:
        p = Path(configured).expanduser()
        if p.is_file() and p.suffix.lower() == '.exe' and not p.stem.lower().endswith(('setup', 'installer')):
            return p.resolve()
    for p in _windows_candidates(program):
        if p.is_file():
            return p.resolve()
    return None


class CreativeStudioWidget(QWidget):
    done = Signal(str, object, str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.data = _load()
        self.done.connect(self._task_done)
        root = QVBoxLayout(self)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QScrollArea.NoFrame)
        root.addWidget(scroll)
        content = QWidget()
        scroll.setWidget(content)
        v = QVBoxLayout(content)
        title = QLabel('FORGEON CREATIVE STUDIO — CS3.1')
        title.setStyleSheet('font-size:22px;font-weight:700')
        v.addWidget(title)
        subtitle = QLabel('Integração local e troca de arquivos. Seus produtos e bancos de dados não são alterados automaticamente.')
        subtitle.setWordWrap(True)
        v.addWidget(subtitle)
        self.fields = {}
        self._init_finished = False
        for key, name, msg in [
            ('artcraft', 'ArtCraft', 'Abre o aplicativo; fotos podem ser preparadas para importação manual.'),
            ('vectorcraft', 'VectorCraft', 'O Forgeon pode iniciar o controle local e abrir/exportar arquivos.'),
            ('freebuff', 'Freebuff', 'Agente de programação. Execute apenas em cópia de desenvolvimento.')
        ]:
            box = QGroupBox(name)
            vv = QVBoxLayout(box)
            lbl = QLabel(msg);lbl.setWordWrap(True);vv.addWidget(lbl)
            rr = QHBoxLayout()
            edit = QLineEdit(self.data.get(key, ''))
            edit.setPlaceholderText('Local do programa instalado (.exe, não instalador)')
            self.fields[key] = edit
            edit.editingFinished.connect(self.save_silent)
            rr.addWidget(edit, 1)
            browse = QPushButton('Procurar...')
            browse.clicked.connect(lambda checked=False, k=key: self.browse(k))
            rr.addWidget(browse)
            run = QPushButton('Abrir' if key != 'vectorcraft' else 'Iniciar e conectar')
            run.clicked.connect(lambda checked=False, k=key: self.launch(k))
            rr.addWidget(run)
            vv.addLayout(rr)
            v.addWidget(box)

        art = QGroupBox('ArtCraft — preparar fotografia do produto')
        av = QVBoxLayout(art)
        msg = QLabel('Escolha a foto original: será COPIADA para uma pasta de troca e o ArtCraft será aberto. A importação no ArtCraft ainda é manual.')
        msg.setWordWrap(True);av.addWidget(msg)
        row = QHBoxLayout()
        btn = QPushButton('Selecionar foto e preparar')
        btn.clicked.connect(self.stage_photo)
        row.addWidget(btn)
        btn2 = QPushButton('Abrir pasta de troca')
        btn2.clicked.connect(self.open_exchange)
        row.addWidget(btn2)
        av.addLayout(row)
        v.addWidget(art)

        vc = QGroupBox('VectorCraft — automação local de arquivos')
        cv = QVBoxLayout(vc)
        cv.addWidget(QLabel('Porta local (127.0.0.1):'))
        self.vector_port = QLineEdit(str(self.data.get('vector_port', '7979')))
        cv.addWidget(self.vector_port)
        self.vector_port.editingFinished.connect(self.save_silent)
        row = QHBoxLayout()
        for label, method in [
            ('Conectar / testar', self.connect_vector),
            ('Abrir arquivo no VectorCraft', self.open_vector_document),
            ('Exportar SVG', lambda: self.export_vector('svg')),
            ('Exportar PNG', lambda: self.export_vector('png')),
        ]:
            btn = QPushButton(label);btn.clicked.connect(method);row.addWidget(btn)
        cv.addLayout(row)
        vc_info = QLabel('Para abrir/exportar, primeiro inicie o VectorCraft com o botão “Iniciar e conectar”. Documentos são abertos/exportados somente com sua escolha.')
        vc_info.setWordWrap(True);cv.addWidget(vc_info)
        v.addWidget(vc)

        api = QGroupBox('ArtCraft — API opcional de vídeo (pode consumir créditos)')
        ap = QVBoxLayout(api)
        ap.addWidget(QLabel('Somente para contas com API habilitada; chave não é salva. Não é edição automática de fundo branco.'))
        self.art_key = QLineEdit();self.art_key.setEchoMode(QLineEdit.Password);self.art_key.setPlaceholderText('artcraft_api_...');ap.addWidget(self.art_key)
        self.art_url = QLineEdit();self.art_url.setPlaceholderText('URL HTTPS pública da imagem inicial');ap.addWidget(self.art_url)
        self.art_prompt = QPlainTextEdit();self.art_prompt.setMaximumHeight(75);self.art_prompt.setPlaceholderText('Prompt de animação');ap.addWidget(self.art_prompt)
        bt = QPushButton('Solicitar geração (confirmar cobrança)');bt.clicked.connect(self.submit_art);ap.addWidget(bt)
        self.art_token = QLineEdit();self.art_token.setPlaceholderText('Token jinf_...');ap.addWidget(self.art_token)
        bt = QPushButton('Consultar geração');bt.clicked.connect(self.check_art);ap.addWidget(bt)
        v.addWidget(api)

        free = QGroupBox('Freebuff — auxiliar na programação (cópia de desenvolvimento)')
        fv = QVBoxLayout(free)
        self.project = QLineEdit(self.data.get('project', ''))
        self.project.setPlaceholderText('Escolha uma cópia de desenvolvimento fora da instalação principal')
        fv.addWidget(self.project)
        self.project.editingFinished.connect(self.save_silent)
        rr = QHBoxLayout()
        bt = QPushButton('Selecionar pasta');bt.clicked.connect(self.browse_project);rr.addWidget(bt)
        bt = QPushButton('Abrir Freebuff na cópia');bt.clicked.connect(self.launch_freebuff);rr.addWidget(bt)
        fv.addLayout(rr)
        v.addWidget(free)

        bottom = QHBoxLayout()
        bt = QPushButton('Localizar programas instalados')
        bt.clicked.connect(self.auto_detect);bottom.addWidget(bt)
        bt = QPushButton('Salvar caminhos')
        bt.clicked.connect(self.save);bottom.addWidget(bt)
        v.addLayout(bottom)
        self.status = QPlainTextEdit()
        self.status.setReadOnly(True)
        self.status.setMaximumHeight(115)
        self.status.setPlaceholderText('Resultado das operações será mostrado aqui.')
        v.addWidget(self.status)
        v.addStretch(1)
        self._init_finished = True
        # Detecta apenas programas que ainda não possuem um caminho válido.
        for key, program in [('artcraft','ArtCraft'), ('vectorcraft','VectorCraft'), ('freebuff','Freebuff')]:
            value = self.fields[key].text().strip()
            if value and any(part in Path(value).stem.lower() for part in ('setup', 'installer')):
                self.fields[key].clear()  # nunca executar instalador como programa
                value = ''
            if not value or not _find_exe(value, program):
                found = _find_exe('', program)
                if found:
                    self.fields[key].setText(str(found))
        self.save_silent()
        app = QApplication.instance()
        if app is not None:
            app.aboutToQuit.connect(self.save_silent)

    def _message(self, msg):
        self.status.appendPlainText(datetime.now().strftime('%H:%M:%S')+'  '+str(msg))

    def browse(self, key):
        file, _ = QFileDialog.getOpenFileName(self, 'Selecione o executável INSTALADO', str(Path.home()), 'Aplicativos Windows (*.exe)')
        if file:
            stem = Path(file).stem.lower()
            if 'setup' in stem or 'installer' in stem:
                QMessageBox.warning(self, 'Instalador selecionado',
                    'Selecione o programa já instalado, não o arquivo usado para instalar.')
                return
            self.fields[key].setText(file)
            self.save_silent()

    def browse_project(self):
        base = self.project.text() or str(Path.home())
        folder = QFileDialog.getExistingDirectory(self, 'Cópia de desenvolvimento do Forgeon', base)
        if folder:
            self.project.setText(folder)
            self.save_silent()

    def auto_detect(self):
        found = []
        for key, name in [('artcraft', 'ArtCraft'), ('vectorcraft', 'VectorCraft'), ('freebuff', 'Freebuff')]:
            exe = _find_exe(self.fields[key].text().strip(), name)
            if exe:
                self.fields[key].setText(str(exe))
                found.append(name)
        self.save_silent()
        self._message('Detectados: '+(', '.join(found) if found else 'nenhum. Selecione via Procurar...'))

    def _collect_settings(self):
        data = dict(self.data)  # preserva possíveis campos de versões futuras
        data.update({k: f.text().strip() for k, f in self.fields.items()})
        data['project'] = self.project.text().strip()
        data['vector_port'] = self.vector_port.text().strip()
        return data

    def save_silent(self):
        if not self._init_finished:
            return
        try:
            data = self._collect_settings()
            _save(data)
            self.data = data
        except OSError as exc:
            self._message('Não consegui salvar os caminhos: '+str(exc))

    def save(self):
        try:
            data = self._collect_settings()
            _save(data)
            self.data = data
            self._message('Configuração salva em: '+str(CONFIG))
        except OSError as exc:
            QMessageBox.warning(self, 'Falha ao salvar', str(exc))

    def closeEvent(self, event):
        self.save_silent()
        super().closeEvent(event)

    def _exe(self, key):
        value = self.fields[key].text().strip()
        if value:
            filename = Path(value).name.lower()
            if 'setup' in filename or 'installer' in filename:
                raise ValueError('Você selecionou um INSTALADOR. Procure o .exe do programa instalado.')
        exe = _find_exe(value, {'artcraft':'ArtCraft','vectorcraft':'VectorCraft','freebuff':'Freebuff'}[key])
        if not exe:
            raise FileNotFoundError('Executável não localizado. Clique em Procurar... para selecionar o programa instalado.')
        self.fields[key].setText(str(exe))
        self.save_silent()
        return exe

    def _port(self):
        port = int(self.vector_port.text().strip())
        if not 1 <= port <= 65535:
            raise ValueError('Porta deve ser entre 1 e 65535.')
        return port

    def _async(self, name, task):
        self._message(name+' — executando...')
        def work():
            try:
                result = task()
                self.done.emit(name, result, '')
            except Exception as err:
                self.done.emit(name, None, str(err))
        threading.Thread(target=work, daemon=True).start()

    def _task_done(self, name, result, error):
        if error:
            self._message(name+' — ERRO: '+error)
        else:
            txt = json.dumps(result, ensure_ascii=False, default=str) if not isinstance(result, str) else result
            self._message(name+' — '+(txt[:550] if txt else 'concluído'))

    def launch(self, key):
        try:
            if key == 'vectorcraft':
                exe = self._exe(key)
                port = self._port()
                self._async('VectorCraft', lambda: self._start_vector(exe, port))
            elif key == 'freebuff':
                self.launch_freebuff()
            else:
                exe = self._exe(key)
                subprocess.Popen([str(exe)], cwd=str(exe.parent), shell=False)
                self._message('ArtCraft aberto. Use o botão “Preparar foto” para copiar um arquivo.')
        except Exception as e:
            QMessageBox.warning(self, 'Falha ao iniciar', str(e))

    @staticmethod
    def _start_vector(exe, port):
        import time
        try:
            vectorcraft_request('ui.inspect', port=port, timeout=2)
            return 'Serviço VectorCraft já conectado em 127.0.0.1:'+str(port)
        except (OSError, ConnectionError, TimeoutError):
            pass
        # O usuario acionou explicitamente o botao para iniciar.
        proc = subprocess.Popen([str(exe), '--control', str(port)], cwd=str(exe.parent), shell=False)
        for _ in range(24):
            if proc.poll() is not None:
                raise RuntimeError('VectorCraft encerrou antes de abrir o controle. Feche outras instâncias e tente novamente.')
            time.sleep(0.5)
            try:
                vectorcraft_request('ui.inspect', port=port, timeout=1)
                return 'Controle local ativo em 127.0.0.1:'+str(port)
            except (OSError, ConnectionError, TimeoutError):
                pass
        raise TimeoutError('VectorCraft abriu, mas a porta não respondeu. Feche instâncias abertas sem --control e tente novamente.')

    def connect_vector(self):
        try:
            port = self._port()
            self._async('Inspeção VectorCraft', lambda: self._vector_status(port))
        except Exception as e:
            QMessageBox.warning(self, 'VectorCraft', str(e))

    @staticmethod
    def _vector_status(port):
        info = vectorcraft_request('ui.inspect', port=port)
        return {'conectado': True, 'documentos':len(info.get('documents', [])), 'ferramenta': info.get('tool')}

    def open_vector_document(self):
        path, _ = QFileDialog.getOpenFileName(self, 'Arquivo para abrir no VectorCraft', str(Path.home()), 'Arte (*.svg *.pdf *.png *.jpg *.jpeg *.webp *.vectorcraft *.ai *.eps *.dxf);;Todos (*)')
        if path:
            try:
                port = self._port()
                self._async('Abrir no VectorCraft', lambda: vectorcraft_open(path, port))
            except Exception as e:
                QMessageBox.warning(self, 'VectorCraft', str(e))

    def export_vector(self, fmt):
        EXPORTS.mkdir(parents=True, exist_ok=True)
        path, _ = QFileDialog.getSaveFileName(self, 'Exportar pelo VectorCraft', str(EXPORTS / ('arte.'+fmt)), f'Arquivo {fmt.upper()} (*.{fmt})')
        if not path:
            return
        p = Path(path)
        if p.suffix.lower() != '.'+fmt:
            p = Path(str(p)+'.'+fmt)
        if p.exists():
            ans = QMessageBox.question(self, 'Sobrescrever?', 'Este arquivo já existe. Deseja substituí-lo?')
            if ans != QMessageBox.Yes:
                return
        try:
            port = self._port()
            self._async('Exportar '+fmt.upper(), lambda: vectorcraft_export(str(p), fmt, port))
        except Exception as e:
            QMessageBox.warning(self, 'VectorCraft', str(e))

    def stage_photo(self):
        src, _ = QFileDialog.getOpenFileName(self, 'Foto original do produto', str(Path.home()), 'Imagens (*.png *.jpg *.jpeg *.webp *.bmp)')
        if not src:
            return
        p = Path(src)
        try:
            if not p.is_file():
                raise FileNotFoundError(str(p))
            EXCHANGE.mkdir(parents=True, exist_ok=True)
            stamped = datetime.now().strftime('%Y%m%d_%H%M%S_%f')
            dest = EXCHANGE / (p.stem+'_'+stamped+p.suffix.lower())
            shutil.copy2(p, dest)
            self._message('Foto COPIADA sem edição: '+str(dest))
            self.open_exchange()
            answer = QMessageBox.question(self, 'ArtCraft', 'Foto preparada. Abrir o ArtCraft agora? A importação deve ser feita no aplicativo.')
            if answer == QMessageBox.Yes:
                self.launch('artcraft')
        except Exception as e:
            QMessageBox.warning(self, 'Preparar foto', str(e))

    def open_exchange(self):
        EXCHANGE.mkdir(parents=True, exist_ok=True)
        try:
            if os.name == 'nt':
                os.startfile(str(EXCHANGE))
            else:
                self._message('Pasta: '+str(EXCHANGE))
        except OSError as e:
            QMessageBox.warning(self, 'Pasta de troca', str(e))

    def launch_freebuff(self):
        try:
            exe = self._exe('freebuff')
            path = self.project.text().strip()
            if not path:
                raise ValueError('Selecione uma cópia de DESENVOLVIMENTO do ERP antes de executar o Freebuff.')
            project = Path(path).expanduser().resolve(strict=True)
            if not project.is_dir() or not (project/'app'/'main.py').is_file():
                raise ValueError('Selecione uma cópia do Forgeon que contenha app/main.py.')
            production = Path(__file__).resolve().parents[2]
            if project == production or production in project.parents:
                raise ValueError('Proteção: Freebuff bloqueado na instalação principal. Crie outra cópia em outra pasta.')
            confirm = QMessageBox.question(self, 'Permissão para alterar arquivos',
                'O Freebuff poderá alterar qualquer arquivo da pasta selecionada. Você conferiu que é uma CÓPIA do projeto, sem dados reais?')
            if confirm != QMessageBox.Yes:
                return
            subprocess.Popen([str(exe)], cwd=str(project), shell=False)
            self._message('Freebuff iniciado. Pasta de trabalho configurada: '+str(project))
            self._message('Atenção: o aplicativo pode ignorar o diretório inicial; confirme o workspace dentro dele.')
        except Exception as e:
            QMessageBox.warning(self, 'Freebuff', str(e))

    def submit_art(self):
        key = self.art_key.text().strip(); url = self.art_url.text().strip(); prompt = self.art_prompt.toPlainText().strip()
        if not all((key, url, prompt)):
            QMessageBox.warning(self, 'ArtCraft', 'Informe chave, URL HTTPS e descrição da animação.');return
        ans = QMessageBox.question(self, 'Custo da API', 'Você confirma envio de geração de vídeo, que pode consumir créditos?')
        if ans == QMessageBox.Yes:
            self._async('Solicitação ArtCraft', lambda: artcraft_submit_video(key, prompt, url))

    def check_art(self):
        key = self.art_key.text().strip(); token = self.art_token.text().strip()
        self._async('Consultar ArtCraft', lambda: artcraft_job_status(key, token))
