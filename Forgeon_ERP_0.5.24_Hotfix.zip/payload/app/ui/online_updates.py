"""Qt controller: checks at startup, installs only between ERP operations."""
import os
from pathlib import Path
import shutil
import subprocess
import sys

from PySide6.QtCore import QObject, QThread, QTimer
from PySide6.QtWidgets import QApplication, QMessageBox

from config import APP_ROOT, APP_VERSION
from database import create_backup
from services import online_updates


class UpdateTask(QThread):
    def __init__(self, operation, parent):
        super().__init__(parent)
        self.operation = operation
        self.result = None
        self.error = None

    def run(self):
        try:
            self.result = self.operation()
        except Exception as exc:
            self.error = str(exc)


class OnlineUpdater(QObject):
    def __init__(self, window, button):
        super().__init__(window)
        self.window, self.button = window, button
        self.task = None
        self.installing = False
        button.clicked.connect(lambda: self.check(manual=True))
        if os.environ.get('FORGEON_UPDATE_CHECK', '1') != '0':
            QTimer.singleShot(5000, self.check)

    def busy(self):
        return self.installing or (self.task is not None and self.task.isRunning())

    def start(self, operation, callback):
        self.button.setEnabled(False)
        task = UpdateTask(operation, self)
        self.task = task
        def done():
            self.task = None
            self.button.setEnabled(True)
            callback(task.result, task.error)
            task.deleteLater()
        task.finished.connect(done)
        task.start()

    def check(self, manual=False):
        if self.busy():
            return
        def checked(info, error):
            if error:
                self.window.statusBar().showMessage('Atualização online indisponível. O ERP continua funcionando.', 12000)
                if manual:
                    QMessageBox.information(self.window, 'Atualizações',
                        'Não foi possível consultar o canal de atualizações.\n\n' + error)
                return
            if info is None:
                if manual:
                    QMessageBox.information(self.window, 'Atualizações', 'Seu Forgeon está atualizado.')
                return
            answer = QMessageBox.question(self.window, 'Atualização disponível',
                f"Forgeon {info['version']} disponível.\n\n"
                'Baixar, fazer backup e reiniciar para instalar agora?\n'
                'Seus dados e configurações serão preservados.',
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if answer == QMessageBox.Yes:
                self.start(lambda: online_updates.stage(info), self.prepared)
        self.start(lambda: online_updates.check(APP_VERSION), checked)

    def prepared(self, package, error):
        if error:
            QMessageBox.warning(self.window, 'Atualizações', error)
            return
        thread = getattr(self.window, 'import_thread', None)
        if thread is not None and thread.isRunning():
            shutil.rmtree(package.parent)
            QMessageBox.information(self.window, 'Atualizações',
                'Aguarde a importação terminar e clique em ATUALIZAR novamente.')
            return
        try:
            if getattr(sys, 'frozen', False) or os.name != 'nt':
                raise RuntimeError('Instalação automática disponível para o Forgeon Python no Windows.')
            create_backup()
            helper = package.parent / 'update_runner.py'
            source = Path(__file__).resolve().parents[1] / 'services' / 'update_runner.py'
            shutil.copy2(source, helper)
            python = APP_ROOT / '.venv' / 'Scripts' / 'python.exe'
            if not python.is_file():
                raise RuntimeError('Python da instalação não encontrado.')
            subprocess.Popen([str(python), str(helper), str(os.getpid()), str(APP_ROOT), str(package)],
                cwd=package.parent, creationflags=subprocess.CREATE_NEW_CONSOLE)
        except Exception as exc:
            shutil.rmtree(package.parent)
            QMessageBox.warning(self.window, 'Atualizações', str(exc))
            return
        self.installing = True
        self.button.setEnabled(False)
        self.window.close()
        QApplication.instance().quit()
