"""Visual identity of Forgeon Studio ERP PRO.

Only UI styles; no storage, network calls or business logic.
"""

BLACK = "#090a0e"
RED = "#e3313e"
GOLD = "#efbf62"

PRO_STYLE = """
QWidget { font-family: 'Segoe UI', Arial; font-size: 10pt; color: #edeef1; background-color: #090a0e; }
QMainWindow { background-color: #090a0e; }
QLabel { background: transparent; border: none; }
QFrame#TopBar QLabel, QFrame#SideBar QLabel, QFrame#Panel QLabel, QFrame#DashboardPanel QLabel, QFrame#MetricCard QLabel { background-color: transparent; border: 0; }
QFrame#TopBar { background: #11141b; border: none; border-bottom: 1px solid #34252a; }
QFrame#SideBar { background: #0c0e14; border-right: 1px solid #30232a; }
QWidget#SidebarContent { background: #0c0e14; }
QScrollArea#SidebarScroll { background: #0c0e14; border: none; }
QFrame#SidebarFooter { background: #0c0e14; border-top: 1px solid #30232a; }
QLabel#BrandText { font-size: 13pt; font-weight: 800; color: #f4f0e9; }
QLabel#BrandSubtext { font-size: 8pt; font-weight: 800; color: #e3313e; }
QLabel#NavGroup { color: #c7a96d; font-size: 8pt; font-weight: 700; padding: 13px 9px 5px 9px; }
QPushButton#SideNav { background: transparent; border: 1px solid transparent; border-radius: 13px; color: #aeb4bf; padding: 11px 13px; text-align: left; font-size: 9.5pt; font-weight: 600; }
QPushButton#SideNav:hover { background: #241a20; border-color: #493039; color: #ffffff; }
QPushButton#SideNav:checked { background: #63151f; border: 1px solid #b12837; color: #ffffff; font-weight: 800; }
QPushButton#SideNav:focus { outline: none; }
QPushButton#SidebarToggle { background: #222129; color: #f0bd6a; border: 1px solid #5c4439; min-width: 35px; padding: 6px; }
QLineEdit#GlobalSearch { background: #191d26; border: 1px solid #3d3337; color: #f1f1f4; padding: 9px 14px; border-radius: 13px; }
QLineEdit#GlobalSearch:focus { border: 1px solid #dba955; }
QLabel#TopBadge { background: #231a17; color: #e9bc71; border: 1px solid #644c32; border-radius: 13px; padding: 7px 11px; }
QLabel#PageTitle { color: #f8f6f3; font-size: 20pt; font-weight: 800; }
QLabel#Hint { color: #a6adba; }
QLabel#SectionTitle { color: #eee5d8; font-size: 11.5pt; font-weight: 800; }
QLabel#MetricTitle { color: #bdc2ce; font-size: 9pt; }
QLabel#MetricValue { color: #f7f7f8; font-size: 20pt; font-weight: 800; }
QLabel#MetricSubtitle { color: #e9b963; font-size: 8.5pt; }
QFrame#MetricCard { background: #15171e; border: 1px solid #453339; border-radius: 18px; }
QFrame#MetricCard[accent="red"] { border: 1px solid #742b3b; background: #1d141a; }
QFrame#MetricCard[accent="gold"] { border: 1px solid #705438; background: #1c1918; }
QFrame#Panel, QFrame#DashboardPanel { background: #14171e; border: 1px solid #30323c; border-radius: 18px; }
QPushButton { background: #a51f2d; color: #fff9f5; border: 1px solid #c62c3e; border-radius: 13px; padding: 9px 14px; font-weight: 700; }
QPushButton:hover { background: #d32c3d; }
QPushButton:disabled { background: #30272b; color: #777a82; border-color: #4c3c43; }
QPushButton#Secondary { background: #25242b; color: #e9c489; border: 1px solid #644c3e; }
QPushButton#Secondary:hover { background: #3a2e31; color: #fff1c5; }
QPushButton#GoldAction { background: #7d541d; color: #fff4db; border: 1px solid #bf9546; }
QPushButton#GoldAction:hover { background: #9a6a23; }
QLabel#Badge { background: #2c1d18; color: #eec175; border: 1px solid #6b4a2b; border-radius: 13px; padding: 6px 10px; }
QLineEdit, QDoubleSpinBox, QSpinBox, QComboBox, QDateEdit, QTextEdit, QPlainTextEdit { background: #10131a; color: #f1f2f4; border: 1px solid #3e3b45; border-radius: 12px; padding: 7px; selection-background-color: #a52331; }
QLineEdit:focus, QDoubleSpinBox:focus, QComboBox:focus, QTextEdit:focus { border: 1px solid #d5a34f; }
QComboBox QAbstractItemView { background: #191b22; color: #e6e8e9; selection-background-color: #6c2230; }
QTableWidget { background: #11141a; alternate-background-color: #171a21; border: 1px solid #30313a; border-radius: 12px; gridline-color: #282b34; selection-background-color: #72212f; selection-color: #ffffff; }
QHeaderView::section { background: #1f222a; color: #ebc17e; padding: 8px; border: none; border-bottom: 1px solid #513c35; font-weight: 700; }
QTableCornerButton::section { background: #1f222a; border: none; }
QTabWidget::pane { border: 1px solid #37313a; background: #11141b; border-radius: 14px; }
QTabBar::tab { background: #1a1e24; color: #a3a9b4; padding: 10px 16px; border-radius: 10px; margin-right: 4px; }
QTabBar::tab:selected { color: #f3ca82; border-bottom: 2px solid #d52f3c; }
QScrollBar:vertical { background: #0c0f15; width: 11px; }
QScrollBar::handle:vertical { background: #564147; border-radius: 5px; min-height: 22px; }
QScrollBar:horizontal { background: #0c0f15; height: 10px; }
QScrollBar::handle:horizontal { background: #564147; border-radius: 5px; }
QCheckBox::indicator:checked { background: #ac2635; border: 1px solid #efbc65; }
QStatusBar { background: #10131a; color: #b6b9c2; border-top: 1px solid #35282b; }
QToolTip { background: #251c20; color: #f5dfb7; border: 1px solid #be8a3a; padding: 5px; }

/* Interface refresh: quieter surfaces, clear fields and consistent focus. */
QWidget { font-size: 10pt; }
QFrame#Panel, QFrame#DashboardPanel { background: #151922; border: 1px solid #303847; border-radius: 20px; }
QLabel#PageTitle { font-size: 23pt; font-weight: 700; }
QLabel#Hint { color: #b1bac9; }
QLabel#SectionTitle { font-size: 12pt; color: #f4f6fa; }
QLabel#MetricTitle { font-size: 10pt; color: #c9d0dc; font-weight: 600; }
QLabel#MetricValue { font-size: 23pt; color: #ffffff; font-weight: 700; }
QLabel#MetricSubtitle { color: #aeb8c8; font-size: 9pt; }
QFrame#MetricCard, QFrame#MetricCard[accent="red"], QFrame#MetricCard[accent="gold"] { background: #171c26; border: 1px solid #354052; border-radius: 20px; }
QLineEdit, QDoubleSpinBox, QSpinBox, QComboBox, QDateEdit { min-height: 24px; padding: 8px 12px; border-radius: 12px; border: 1px solid #4b586d; background: #1c2330; color: #ffffff; selection-background-color: #923042; }
QLineEdit:read-only { background: #151922; color: #bdc6d5; border-color: #354052; }
QLineEdit:focus, QAbstractSpinBox:focus, QComboBox:focus, QTextEdit:focus { border: 2px solid #efbf62; }
QAbstractSpinBox::up-button, QAbstractSpinBox::down-button { width: 22px; border-radius: 5px; }
QPushButton { min-height: 22px; padding: 9px 14px; border-radius: 12px; font-weight: 600; }
QPushButton#Secondary { background: #232b38; border-color: #49566a; color: #e0e5ef; }
QPushButton#Secondary:hover { background: #303b4d; border-color: #8091aa; color: #ffffff; }
QPushButton:focus, QToolButton:focus { border: 2px solid #efbf62; }
QToolButton { text-align: left; background: #1b2230; color: #dce3ef; border: 1px solid #3b485b; border-radius: 12px; padding: 12px; font-weight: 600; }
QTabWidget::pane { border: 1px solid #354052; border-radius: 16px; background: #11151d; }
QTabBar::tab { background: #1b2230; color: #b9c4d5; border: 1px solid #354052; border-radius: 10px; padding: 12px 18px; margin: 0px 8px 8px 0px; }
QTabBar::tab:selected { background: #47232d; color: #ffffff; border: 1px solid #d06371; }
QHeaderView::section { background: #222b39; color: #dce3ee; padding: 12px 10px; border: none; font-weight: 600; }
QTableWidget { background: #141923; alternate-background-color: #1b2230; border: 1px solid #354052; border-radius: 14px; selection-background-color: #633340; }
QTableWidget::item { padding: 7px; }
QCheckBox { spacing: 9px; padding: 4px; }
QCheckBox::indicator { width: 18px; height: 18px; border: 1px solid #7e8da4; border-radius: 5px; background: #1c2330; }
QCheckBox::indicator:checked { background: #b02e43; border: 1px solid #ed9ca9; }

QCheckBox { background: transparent; }
QAbstractSpinBox { padding-left: 12px; padding-right: 26px; }
"""
