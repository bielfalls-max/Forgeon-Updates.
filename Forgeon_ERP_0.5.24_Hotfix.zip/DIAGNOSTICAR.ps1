﻿$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
$picker = New-Object System.Windows.Forms.FolderBrowserDialog
$picker.Description = 'Selecione a pasta do Forgeon instalado (a pasta que contem app e .venv).'
$picker.ShowNewFolderButton = $false
if ($picker.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { exit 1 }
$root = $picker.SelectedPath
$lines = @('DIAGNOSTICO FORGEON - somente leitura', ('Pasta: ' + $root))
$config = Join-Path $root 'app\config.py'
if (Test-Path -LiteralPath $config) {
    $text = [IO.File]::ReadAllText($config)
    $m = [regex]::Match($text, '(?m)^\s*APP_VERSION\s*=\s*[''"]([^''"]+)[''"]')
    if ($m.Success) { $lines += 'Versao: ' + $m.Groups[1].Value }
    else { $lines += 'Versao: nao identificada no config.py' }
} else { $lines += 'app/config.py: nao encontrado (pasta incorreta ou instalacao incompleta)' }
foreach ($rel in @('app\main.py','app\config.py','app\ui\ad_tools.py','app\ui\widgets.py','app\ui\forgeon_pro_theme.py')) {
    $path = Join-Path $root $rel
    if (Test-Path -LiteralPath $path) { $lines += $rel + ' SHA256: ' + (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash }
    else { $lines += $rel + ': ausente' }
}
$lines += 'Python do ERP presente: ' + (Test-Path -LiteralPath (Join-Path $root '.venv\Scripts\python.exe'))
$lines += 'Nenhum banco, chave ou configuracao pessoal foi lido ou alterado.'
$lines | ForEach-Object { Write-Host $_ }
$report = Join-Path $PSScriptRoot 'diagnostico-forgeon.txt'
$lines | Set-Content -LiteralPath $report -Encoding UTF8
Write-Host ('Envie o arquivo: ' + $report)
