"""Forgeon package deployment. Only files declared in manifest can be written."""
import argparse, ast, hashlib, json, os, shutil, subprocess, sys, uuid, tempfile
from pathlib import Path, PurePosixPath

VERSION = '0.5.24'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def text_digest(path):
    try:
        text=path.read_bytes().decode('utf-8-sig').replace('\r\n','\n').replace('\r','\n')
        return hashlib.sha256(text.encode('utf-8')).hexdigest()
    except (UnicodeDecodeError,OSError):return None

def relative(name):
    p=PurePosixPath(name)
    if p.is_absolute() or '..' in p.parts or '\\' in name or ':' in name:
        raise ValueError('Caminho de pacote invalido')
    if not (name.startswith(('app/','assets/','templates/')) or name in ('run_erp.py','requirements.txt','INICIAR_FORGEON.vbs','ABRIR_COM_DIAGNOSTICO.cmd')):
        raise ValueError('Arquivo fora dos componentes do programa: '+name)
    return Path(*p.parts)

def version(root):
    path=root/'app/config.py'
    if not path.exists(): return None
    tree=ast.parse(path.read_text(encoding='utf-8-sig'))
    for node in tree.body:
        if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='APP_VERSION' for t in node.targets):
            return ast.literal_eval(node.value)
    raise ValueError('Versao instalada nao identificada')

def run(args,**kwargs):
    subprocess.run([str(a) for a in args],check=True,**kwargs)

def validate(root, python):
    # Use an isolated temporary runtime; never migrate the user's real database here.
    code='''import sys,os,logging
from pathlib import Path
os.environ["FORGEON_ERP_HOME"]=sys.argv[2]
os.environ["QT_QPA_PLATFORM"]="offscreen"
os.environ["FORGEON_UPDATE_CHECK"]="0"
sys.path.insert(0,str(Path(sys.argv[1])/"app"))
from database import initialize_database
initialize_database()
from main import MainWindow
from PySide6.QtWidgets import QApplication
app=QApplication([])
w=None
try:
 w=MainWindow();w.show();app.processEvents()
 assert w.stack.count()==len(w.page_names)==11
 assert "Planilhas" in w.page_names and "Criação de anúncio" not in w.page_names and "Creative Studio" not in w.page_names
 assert "ui.ad_tools" not in sys.modules and not hasattr(w,"ad_steps")
 assert w.page_names[-1]=="Notas de atualização"
 for i in range(w.stack.count()):w.goto(i);app.processEvents()
 assert "0.5.24" in w.windowTitle()
 print("Validacao local OK")
finally:
 if w is not None:w.close();app.processEvents()
 logging.shutdown()
'''
    # The parent owns cleanup. The child exits first, releasing Windows file
    # handles even when a UI assertion fails or an import raises an exception.
    with tempfile.TemporaryDirectory(prefix="forgeon-install-test-") as tmp:
        run([python,'-c',code,root,tmp])


def resumable(root, entries):
    expected={e['path']:e['sha256'] for e in entries}
    for report in (root/'backups').glob('hotfix_0.5.9_*/restore.json'):
        if (report.parent/'SUCCESS').exists():continue
        try:
            records=json.loads(report.read_text(encoding='utf-8'))
            if len(records)!=len(expected):continue
            if {r['path']:r['installed'] for r in records}!=expected:continue
            if any(r['previous'] is not None for r in records):continue
            return True
        except (ValueError,KeyError,TypeError):continue
    return False

def deploy(package,root,resume=False):
    package=package.resolve();root=root.resolve()
    m=json.loads((package/'manifest.json').read_text(encoding='utf-8'))
    if m['version']!=VERSION or m['kind'] not in ('install','hotfix'):raise ValueError('Pacote desconhecido')
    entries=m['files']
    if not entries or len({x['path'] for x in entries})!=len(entries):raise ValueError('Manifesto invalido')
    if root==package or package in root.parents or root in package.parents:raise ValueError('Extraia o pacote fora da instalacao')
    installed=version(root)
    if resume and m['kind']!='install':raise ValueError('Retomada disponivel apenas para instalacao incompleta.')
    if m['kind']=='install' and root.exists() and any(root.iterdir()):
        if not resume or not resumable(root,entries):
            raise ValueError('Pasta ocupada. RETOMAR_INSTALACAO.cmd so aceita instalacao incompleta comprovada deste pacote; para atualizar use hotfix.')
    if m['kind']=='hotfix' and installed not in m['from_versions']:
        raise ValueError('Versao encontrada: '+str(installed or 'nao identificada (app/config.py ausente)')+'; pasta: '+str(root)+'. Este hotfix aceita: '+', '.join(m['from_versions'])+'. Nenhum arquivo foi alterado. Verifique a pasta do atalho do ERP; nao reinstale por cima nem altere APP_VERSION manualmente.')
    python=root/'.venv'/('Scripts/python.exe' if os.name=='nt' else 'bin/python')
    if m['kind']=='hotfix' and not python.exists():raise ValueError('Ambiente Python instalado nao encontrado')
    for e in entries:
        rel=relative(e['path']);src=package/'payload'/rel;dest=root/rel
        if not dest.resolve().is_relative_to(root):raise ValueError('Destino fora da instalacao')
        if not src.resolve().is_relative_to(package/'payload'):raise ValueError('Origem fora do pacote')
        if digest(src)!=e['sha256']:raise ValueError('Falha de integridade: '+e['path'])
        if resume and dest.exists() and digest(dest)!=e['sha256']:
            raise ValueError('Retomada recusada: arquivo diferente do pacote: '+e['path'])
        if m['kind']=='hotfix':
            current=digest(dest) if dest.exists() else None
            if current not in e['base_sha256']+[e['sha256']]:
                normalized=text_digest(dest) if dest.is_file() else None
                accepted=e.get('base_text_sha256',[])+[e.get('text_sha256')]
                if normalized is None or normalized not in accepted:
                    raise ValueError('Arquivo local diferente das bases conhecidas: '+e['path']+'. Nenhum arquivo foi alterado. Envie esse arquivo de codigo para comparacao; nao altere APP_VERSION.')
                print('Base reconhecida com diferenca de BOM/quebra de linha: '+e['path'])
    root.mkdir(parents=True,exist_ok=True)
    # Exclusive lock prevents two installer/hotfix operations running together.
    lock=root/'.forgeon-update.lock'
    fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY)
    backup=root/'backups'/('hotfix_'+VERSION+'_'+uuid.uuid4().hex)
    changed=[];records=[]
    try:
        backup.mkdir(parents=True)
        for e in entries:
            rel=relative(e['path']);dest=root/rel;saved=backup/'files'/rel
            old_hash=digest(dest) if dest.exists() else None
            if old_hash is not None:
                saved.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(dest,saved)
            records.append({'path':e['path'],'previous':old_hash,'installed':e['sha256']})
        (backup/'restore.json').write_text(json.dumps(records,indent=2),encoding='utf-8')
        shutil.copy2(Path(__file__),backup/'deploy.py')
        for e in entries:
            rel=relative(e['path']);dest=root/rel;dest.parent.mkdir(parents=True,exist_ok=True)
            changed.append(e['path'])
            tmp=dest.with_name(dest.name+'.forgeon-tmp')
            try:
                shutil.copy2(package/'payload'/rel,tmp);os.replace(tmp,dest)
            finally:tmp.unlink(missing_ok=True)
        if m['kind']=='install':
            if not python.exists():run([sys.executable,'-m','venv',root/'.venv'])
            run([python,'-m','pip','install','-r',root/'requirements.txt'])
        run([python,'-m','pip','check'])
        validate(root,python)
        (backup/'SUCCESS').write_text(VERSION)
        print('SUCESSO: Forgeon '+VERSION+' instalado em '+str(root))
        print('Backup para restauracao: '+str(backup))
    except BaseException:
        for e in records:
            if e['path'] not in changed:continue
            dest=root/relative(e['path'])
            if e['previous'] is None:dest.unlink(missing_ok=True)
            else:shutil.copy2(backup/'files'/relative(e['path']),dest)
        raise
    finally:
        os.close(fd);lock.unlink(missing_ok=True)

def restore(backup,root):
    root=root.resolve();backup=backup.resolve()
    records=json.loads((backup/'restore.json').read_text(encoding='utf-8'))
    if (root/'.forgeon-update.lock').exists():raise ValueError('Ha uma atualizacao em andamento')
    for e in records:
        dest=root/relative(e['path'])
        if not dest.resolve().is_relative_to(root):raise ValueError('Destino fora da instalacao')
        if not dest.exists() or digest(dest)!=e['installed']:raise ValueError('Arquivo mudou apos o hotfix: '+e['path'])
        if e['previous'] is not None and digest(backup/'files'/relative(e['path']))!=e['previous']:raise ValueError('Backup invalido')
    for e in records:
        dest=root/relative(e['path'])
        if e['previous'] is None:dest.unlink()
        else:shutil.copy2(backup/'files'/relative(e['path']),dest)
    print('Arquivos anteriores restaurados. Banco e configuracoes preservados.')

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--package',type=Path);parser.add_argument('--root',type=Path,required=True);parser.add_argument('--restore',type=Path);parser.add_argument('--resume-install',action='store_true')
    args=parser.parse_args()
    try:
        if args.restore:restore(args.restore,args.root)
        else:deploy(args.package,args.root,args.resume_install)
    except Exception as e:
        print('ERRO: '+str(e),file=sys.stderr);sys.exit(1)
