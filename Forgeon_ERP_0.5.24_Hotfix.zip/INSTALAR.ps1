﻿param([string]$Destino)
$ErrorActionPreference = 'Stop'
$package = $PSScriptRoot
$manifest = Get-Content -LiteralPath (Join-Path $package 'manifest.json') -Raw | ConvertFrom-Json
$settingsDir = Join-Path $env:LOCALAPPDATA 'Forgeon'
$settingsFile = Join-Path $settingsDir 'installation.json'
function Test-Forgeon([string]$path) {
    if (-not $path) { return $false }
    return ((Test-Path -LiteralPath (Join-Path $path 'app\main.py') -PathType Leaf) -and
            (Test-Path -LiteralPath (Join-Path $path 'app\config.py') -PathType Leaf) -and
            (Test-Path -LiteralPath (Join-Path $path '.venv\Scripts\python.exe') -PathType Leaf))
}
function Select-Forgeon([string[]]$paths) {
    $valid = @($paths | Where-Object { Test-Forgeon $_ } | ForEach-Object { [IO.Path]::GetFullPath($_).TrimEnd([char]92) } | Sort-Object -Unique)
    if ($valid.Count -eq 1) { return $valid[0] }
    if ($valid.Count -gt 1) {
        Write-Host 'Encontrei mais de uma instalacao. Escolha a que voce usa; nao vou mover seus dados:'
        for ($i=0; $i -lt $valid.Count; $i++) { Write-Host (($i+1).ToString() + ') ' + $valid[$i]) }
        $selection = Read-Host 'Digite o numero da instalacao (Enter cancela)'
        $number = 0
        if (-not [int]::TryParse($selection,[ref]$number) -or $number -lt 1 -or $number -gt $valid.Count) { throw 'Selecao cancelada ou invalida. Nenhum arquivo alterado.' }
        return $valid[$number-1]
    }
    return $null
}
function Find-InDocuments([string[]]$folders) {
    $found = @()
    foreach ($folder in ($folders | Where-Object { $_ } | Select-Object -Unique)) {
        if (-not (Test-Path -LiteralPath $folder -PathType Container)) { continue }
        $found += $folder
        $found += Join-Path $folder 'Forgeon Studio ERP'
        $found += Join-Path $folder 'Forgeon Studio ERP 0.5.9'
        try {
            $children = @(Get-ChildItem -LiteralPath $folder -Directory -Filter 'Forgeon*' -ErrorAction Stop)
            foreach ($child in $children) { $found += $child.FullName }
        } catch { Write-Warning ('Nao foi possivel verificar subpastas de: ' + $folder) }
    }
    return Select-Forgeon $found
}
# An explicit destination or override is respected; stale overrides are not silently replaced.
if (-not $Destino) {
    if ($env:FORGEON_ERP_HOME) { $Destino = $env:FORGEON_ERP_HOME }
    elseif ($env:FORGEON_HOME) { $Destino = $env:FORGEON_HOME }
}
if ($Destino -and -not (Test-Forgeon $Destino)) {
    throw ('Destino informado nao contem app/main.py, app/config.py e .venv/Scripts/python.exe: ' + $Destino + '. Corrija -Destino ou a variavel FORGEON_HOME/FORGEON_ERP_HOME.')
}
if (-not $Destino -and (Test-Path -LiteralPath $settingsFile)) {
    try {
        $saved = Get-Content -LiteralPath $settingsFile -Raw | ConvertFrom-Json
        if (Test-Forgeon $saved.install_root) { $Destino = $saved.install_root; Write-Host 'Usando a instalacao lembrada neste PC.' }
    } catch { Write-Warning 'O registro de instalacao anterior nao pode ser lido. Vou procurar em Documentos.' }
}
if (-not $Destino) {
    $documents = @([Environment]::GetFolderPath('MyDocuments'))
    if ($env:USERPROFILE) {
        $documents += Join-Path $env:USERPROFILE 'Documents'
        $documents += Join-Path $env:USERPROFILE 'Documentos'
        $documents += Join-Path $env:USERPROFILE 'OneDrive\Documents'
        $documents += Join-Path $env:USERPROFILE 'OneDrive\Documentos'
    }
    foreach ($onedrive in @($env:OneDrive,$env:OneDriveConsumer,$env:OneDriveCommercial)) {
        if ($onedrive) { $documents += Join-Path $onedrive 'Documents'; $documents += Join-Path $onedrive 'Documentos' }
    }
    $Destino = Find-InDocuments $documents
}
if (-not $Destino) {
    Write-Host 'Nao localizei o ERP automaticamente nas pastas Documentos deste usuario.'
    Add-Type -AssemblyName System.Windows.Forms
    $picker = New-Object System.Windows.Forms.FolderBrowserDialog
    $picker.Description = 'Selecione Forgeon Studio ERP (dentro de Documentos). A pasta deve conter app e .venv.'
    $picker.ShowNewFolderButton = $false
    $picker.SelectedPath = [Environment]::GetFolderPath('MyDocuments')
    if ($picker.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { throw 'Cancelado. Nenhum arquivo alterado.' }
    $Destino = if (Test-Forgeon $picker.SelectedPath) { $picker.SelectedPath } else { Find-InDocuments @($picker.SelectedPath) }
}
if (-not $Destino -or -not (Test-Forgeon $Destino)) { throw 'A pasta escolhida nao contem uma instalacao completa. Nenhum arquivo alterado.' }
$Destino = [IO.Path]::GetFullPath($Destino).TrimEnd([char]92)
Write-Host ('Destino identificado: ' + $Destino)
Write-Host ('Pacote: ' + $manifest.kind + ' ' + $manifest.version)
Write-Host 'Feche o Forgeon antes de continuar.'
$running = Get-CimInstance Win32_Process | Where-Object {
    $_.Name -match '^pythonw?\.exe$' -and (
        ($_.ExecutablePath -and $_.ExecutablePath.StartsWith($Destino + '\', [StringComparison]::OrdinalIgnoreCase)) -or
        ($_.CommandLine -and $_.CommandLine.IndexOf($Destino, [StringComparison]::OrdinalIgnoreCase) -ge 0)
    )
}
if ($running) { throw 'O Forgeon esta aberto. Feche o aplicativo e execute novamente.' }
$python = Join-Path $Destino '.venv\Scripts\python.exe'
& $python (Join-Path $package 'deploy.py') --package $package --root $Destino
if ($LASTEXITCODE -ne 0) { throw 'Atualizacao nao concluida. Leia o arquivo/versao indicado acima. Nao apague sua instalacao nem altere APP_VERSION.' }
# Remember the location only after successful deployment. Failure to save this preference
# does not turn a validated update into a failed update.
try {
    New-Item -ItemType Directory -Force -Path $settingsDir | Out-Null
    $temporary = Join-Path $settingsDir ('installation_' + [Guid]::NewGuid().ToString('N') + '.tmp')
    @{install_root=$Destino; version=$manifest.version} | ConvertTo-Json | Set-Content -LiteralPath $temporary -Encoding UTF8
    Move-Item -LiteralPath $temporary -Destination $settingsFile -Force
    Write-Host 'Pasta lembrada para as proximas atualizacoes neste PC.'
} catch { Write-Warning 'Atualizacao concluida; nao consegui salvar a preferencia de pasta. Ela sera procurada novamente na proxima vez.' }
Write-Host 'Concluido. Abra o ERP pelo atalho habitual.'
