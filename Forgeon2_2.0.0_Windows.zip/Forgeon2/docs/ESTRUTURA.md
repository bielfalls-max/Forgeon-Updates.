# Estrutura nova

- `main.py`: entrada do aplicativo.
- `forgeon/store.py`: banco novo, transações, auditoria, backup e restauração.
- `forgeon/values.py`: conversões, validação numérica e cálculo decimal de preço.
- `forgeon/catalog.py`: produtos físicos, cores, origens de anúncios e catálogo de SKUs.
- `forgeon/sheets.py`: leitura de XLSX, prévia, importação e exportação de dados.
- `forgeon/printing.py`: leitura de consumo/tempo de arquivos fatiados como dados.
- `forgeon/reports.py`: indicadores, cobertura, consumo, despesas e compras.
- `forgeon/ui.py`: interface desktop Qt Widgets.
- `tests/`: regras de negócio, fronteiras do aplicativo e interface.

O programa novo começa vazio em `%LOCALAPPDATA%\Forgeon2`. Não procura nem
lê a pasta do ERP anterior, seus perfis, dados ou extensões. Backups aceitos
na restauração são apenas do Forgeon 2.

```mermaid
flowchart LR
    UI[Interface desktop] --> Catalog[Produtos e SKUs]
    UI --> Sheets[Planilhas e arquivos fatiados]
    UI --> Reports[Relatórios e financeiro]
    Catalog --> DB[(Banco SQLite novo)]
    Sheets --> DB
    Reports --> DB
    DB --> Backup[Backup local]
```

Nenhuma camada depende de navegador, serviços externos ou APIs de IA.
O instalador inicial baixa somente dependências de versões/hashes fixos do PyPI.
