@echo off
setlocal
cd /d "%~dp0"
echo Forgeon 2.0 - ambiente novo e independente
echo Este passo cria .venv nesta pasta e instala dependencias publicadas no PyPI.
echo Nao usa arquivos da instalacao antiga nem altera o Windows Defender.
echo.
py -3.12 --version
if errorlevel 1 goto python_missing
if exist ".venv\Scripts\python.exe" goto install
py -3.12 -m venv .venv
if errorlevel 1 goto failed
:install
".venv\Scripts\python.exe" -m pip install --require-hashes --only-binary=:all: --index-url https://pypi.org/simple -r requirements.txt
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m pip check
if errorlevel 1 goto failed
echo.
echo Instalacao concluida. Abra ABRIR_FORGEON.cmd.
pause
exit /b 0
:python_missing
echo.
echo Python 3.12 nao encontrado. Instale o Python 3.12 de https://www.python.org/
echo com o Python Launcher, depois execute este arquivo novamente.
pause
exit /b 1
:failed
echo.
echo Nao foi possivel concluir. Leia a mensagem acima. Nenhum dado antigo foi importado.
pause
exit /b 1
