"""Forgeon 2: offline business management, independent implementation."""
__version__ = '2.0.0'
