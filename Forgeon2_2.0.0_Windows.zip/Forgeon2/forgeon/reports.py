"""Explicit coverage; summary sales never invent detailed quantities or costs."""
from collections import defaultdict
import calendar
from .catalog import product_rows
from .values import cents, number
from .store import audit


def month_report(store, month):
    products = {p['id']: p for p in product_rows(store, include_inactive=True)}
    orders = store.rows("SELECT * FROM orders WHERE substr(day,1,7)=?", (month,))
    valid = [o for o in orders if 'cancel' not in o['status'].casefold()]
    paid = [o for o in valid if not any(t in o['status'].casefold() for t in ('nao pago', 'não pago', 'unpaid', 'aguardando pagamento'))]
    ids = {o['id'] for o in paid}
    lines = store.rows('SELECT l.*,a.product_id FROM lines l JOIN aliases a ON a.id=l.alias_id JOIN orders o ON o.id=l.order_id WHERE substr(o.day,1,7)=?', (month,))
    lines = [r for r in lines if r['order_id'] in ids]
    sales = sum(o['total_cents'] for o in paid)
    fees = sum(o['fees_cents'] for o in paid)
    costs = 0; units = 0; missing = set(); colors = defaultdict(float); best = defaultdict(lambda: [0, 0])
    for line in lines:
        qty = max(0, line['qty'] - line['returned'])
        p = products.get(line['product_id'])
        units += qty
        if p is None:
            missing.add(str(line['product_id']));continue
        costs += p['cost_cents'] * qty
        if not p['complete']:
            missing.add(p['name'])
        best[p['name']][0] += qty
        best[p['name']][1] += line['subtotal_cents']
        for c in p['colors']:
            colors[c['name']] += c['grams'] * qty
    summary = store.rows('SELECT * FROM summaries WHERE month=?', (month,))
    summary = summary[0] if summary else None
    expenses = sum(r['amount_cents'] for r in store.rows('SELECT amount_cents FROM expenses WHERE substr(day,1,7)=?', (month,)))
    purchases = sum(r['amount_cents'] for r in store.rows('SELECT amount_cents FROM purchases WHERE substr(day,1,7)=?', (month,)))
    known_fees = all(o['fees_known'] for o in paid)
    month_end=month+'-'+str(calendar.monthrange(int(month[:4]),int(month[5:]))[1]).zfill(2)
    full_period=bool(summary) and summary['start_day']==month+'-01' and summary['end_day']==month_end
    coverage = full_period and len(paid) == summary['orders'] and sales == summary['sales_cents']
    warnings = []
    if not summary:
        warnings.append('Sem resumo Shopee para conferir a cobertura mensal dos pedidos.')
    if summary and not full_period:
        warnings.append('O resumo importado cobre apenas parte do mês.')
    if summary and not coverage:
        warnings.append(f"Resumo: {summary['orders']} pedidos; detalhados: {len(paid)}. Importe Todos os pedidos (Order.all).")
    if missing:
        warnings.append('Custo/cores incompletos: ' + ', '.join(sorted(missing)))
    if any(l['returned'] for l in lines) or any('reembols' in o['status'].casefold() or 'devol' in o['status'].casefold() for o in paid):
        warnings.append('Há devoluções/reembolsos: resultado e caixa não incluem conciliação bancária dessas operações.')
    if not known_fees:
        warnings.append('Há pedidos sem taxas detalhadas.')
    if not orders:
        warnings.append('Sem pedidos detalhados neste mês.')
    return dict(month=month, orders=len(paid), units=units, detailed_sales=sales,
                summary=summary, fees=fees, costs=costs, expenses=expenses, purchases=purchases,
                result=sales-fees-costs-expenses, cash=sales-fees-expenses-purchases,
                complete=coverage and not missing and known_fees and bool(orders) and not any(l['returned'] for l in lines) and not any('reembols' in o['status'].casefold() or 'devol' in o['status'].casefold() for o in paid), warnings=warnings,
                colors=dict(sorted(colors.items())), best=sorted([(k,*v) for k,v in best.items()], key=lambda r:r[1], reverse=True))


def add_expense(store, day, category, description, amount):
    from .values import iso_date
    value = cents(amount)
    if value <= 0:
        raise ValueError('Informe um valor maior que zero.')
    with store.connect() as con:
        con.execute('INSERT INTO expenses(day,category,description,amount_cents) VALUES(?,?,?,?)',
                    (iso_date(day), category, description, value))
        audit(con, 'expense', {'day': day, 'cents': value})


def add_purchase(store, day, color, grams, amount, notes=''):
    from .values import iso_date
    weight = float(number(grams));value = cents(amount)
    if weight <= 0 or not color.strip():
        raise ValueError('Informe a cor e um peso positivo.')
    with store.connect() as con:
        con.execute('INSERT INTO purchases(day,color,grams,amount_cents,notes) VALUES(?,?,?,?,?)',
                    (iso_date(day), color.strip(), weight, value, notes))
        audit(con, 'purchase', {'day': day, 'grams': weight})


def save_settings(store, values):
    validated = {}
    from .store import DEFAULTS
    for key in DEFAULTS:
        validated[key] = str(number(values[key]))
    if number(validated['fee_percent']) >= 100:
        raise ValueError('Taxa deve ser menor que 100%.')
    with store.connect() as con:
        con.executemany('UPDATE settings SET value=? WHERE key=?', [(v,k) for k,v in validated.items()])
        audit(con, 'settings', validated)
