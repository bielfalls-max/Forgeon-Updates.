"""Strict conversions shared by UI, spreadsheet readers and calculations."""
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from datetime import datetime, date
import re
import unicodedata


def number(value, *, minimum=0):
    if value is None or str(value).strip() in ('', '-', '--'):
        return Decimal(0)
    text = str(value).strip().replace('R$', '').replace('%', '').replace(' ', '')
    if ',' in text:
        text = text.replace('.', '').replace(',', '.')
    try:
        result = Decimal(text)
    except InvalidOperation as exc:
        raise ValueError(f'Número inválido: {str(value)[:60]}') from exc
    if not result.is_finite() or (minimum is not None and result < minimum):
        raise ValueError('Informe um número válido, sem valores negativos.')
    return result


def cents(value):
    return int((number(value) * 100).quantize(Decimal(1), rounding=ROUND_HALF_UP))


def money(value):
    text = f'{int(value) / 100:,.2f}'.replace(',', '_').replace('.', ',').replace('_', '.')
    return 'R$ ' + text


def normalized(text):
    text = unicodedata.normalize('NFKD', str(text or '')).encode('ascii', 'ignore').decode().casefold()
    return ' '.join(re.findall(r'[a-z0-9]+', text))


def product_key(name):
    # Only cosmetic equivalences, never substring or fuzzy matching.
    text = re.sub(r'\s*[-–—]\s*hedgehog\s*$', '', str(name), flags=re.I)
    pieces = [normalized(p) for p in text.split(',')]
    return pieces[0] if pieces and len(set(pieces)) == 1 else normalized(text)


def iso_date(value):
    if isinstance(value, (datetime, date)):
        return value.isoformat()[:10]
    text = str(value or '').strip()
    for fmt in ('%Y-%m-%d', '%d/%m/%Y', '%Y-%m-%d %H:%M', '%Y-%m-%d %H:%M:%S', '%d/%m/%Y %H:%M'):
        try:
            return datetime.strptime(text, fmt).date().isoformat()
        except ValueError:
            pass
    raise ValueError(f'Data não reconhecida: {text[:40]}')


def integer(value):
    n = number(value)
    if n != n.to_integral_value():
        raise ValueError('Quantidade deve ser inteira.')
    return int(n)


def quote(product, colors, settings):
    weight = sum(number(c['grams']) for c in colors) if colors else number(product['weight_g'])
    material = weight * number(settings['filament_kg']) / 1000
    hours = number(product['hours'])
    energy = hours * number(settings['printer_watts']) / 1000 * number(settings['energy_kwh'])
    machine = hours * number(settings['machine_hour'])
    manual = number(product['manual_cents']) / 100
    fabrication = manual if manual > 0 else material + energy + machine
    cost = fabrication + (number(product['packaging_cents']) + number(product['other_cents'])) / 100
    fee = number(settings['fee_percent']) / 100
    if fee >= 1:
        raise ValueError('Taxa deve ser menor que 100%.')
    suggested = (cost * (1 + number(settings['markup_percent']) / 100) + number(settings['fixed_fee'])) / (1 - fee)
    return dict(weight=float(weight), material_cents=cents(material), energy_cents=cents(energy),
                cost_cents=cents(cost), price_cents=cents(suggested))
