"""Qt Widgets desktop UI. No embedded browser, extension or remote execution."""
from datetime import date
from functools import wraps
from pathlib import Path
import json
import traceback
from PySide6.QtCore import Qt, QThread, QDate, Slot
from PySide6.QtGui import QColor, QPainter, QPen
from PySide6.QtWidgets import (QApplication,QMainWindow,QWidget,QDialog,QVBoxLayout,QHBoxLayout,QFormLayout,
    QStackedWidget,QListWidget,QPushButton,QLabel,QLineEdit,QComboBox,QDoubleSpinBox,QTableWidget,
    QTableWidgetItem,QAbstractItemView,QHeaderView,QMessageBox,QFileDialog,QInputDialog,QDialogButtonBox,
    QDateEdit,QTextEdit,QGroupBox,QSplitter,QFrame,QScrollArea,QCheckBox)
from . import __version__
from .values import money, number
from .store import Store, DEFAULTS, restore_backup, audit
from . import catalog, sheets, reports, printing

STYLE='''
QWidget {background:#10141c;color:#e7edf5;font-family:"Segoe UI";font-size:13px;}
QMainWindow {background:#10141c;}
QListWidget {background:#151c27;border:0;padding:12px;font-size:14px;}
QListWidget::item {padding:15px 12px;border-radius:7px;margin:3px;}
QListWidget::item:selected {background:#743527;color:#fff;}
QPushButton {background:#b94732;color:white;border:1px solid #d96348;border-radius:6px;padding:10px 15px;font-weight:600;}
QPushButton:hover {background:#d35b41;}
QPushButton:disabled {color:#87919f;background:#303845;border-color:#3c4655;}
QPushButton[secondary="true"] {background:#222e3d;border-color:#405069;}
QLineEdit,QComboBox,QDoubleSpinBox,QDateEdit,QTextEdit {background:#1d2735;border:1px solid #405069;border-radius:5px;padding:8px;selection-background-color:#8d4734;}
QTableWidget {background:#151d28;alternate-background-color:#1b2533;border:1px solid #344258;gridline-color:#29374b;selection-background-color:#5c3a32;}
QHeaderView::section {background:#233044;color:#e4ecf8;border:0;padding:10px;font-weight:600;}
QCheckBox::indicator {width:17px;height:17px;border:1px solid #64748b;border-radius:3px;background:#1d2735;}
QCheckBox::indicator:checked {background:#d76542;border-color:#ffb26c;}
QGroupBox {border:1px solid #344258;border-radius:8px;margin-top:12px;padding:15px;}
QGroupBox::title {subcontrol-origin:margin;left:12px;color:#ffb26c;}
QLabel[heading="true"] {font-size:27px;font-weight:700;}
QLabel[muted="true"] {color:#a6b7ce;}
QFrame[card="true"] {background:#1b2533;border:1px solid #344258;border-radius:9px;}
QScrollArea {border:0;}
QDialogButtonBox QPushButton {min-width:90px;}
'''


def guarded(fn):
    @wraps(fn)
    def call(self,*args,**kwargs):
        try:
            return fn(self,*args,**kwargs)
        except Exception as exc:
            QMessageBox.warning(self,'Forgeon 2.0',str(exc))
    return call


def button(text, callback, secondary=False):
    b=QPushButton(text);b.setProperty('secondary',secondary);b.clicked.connect(callback);return b


def table(headers):
    t=QTableWidget(0,len(headers));t.setHorizontalHeaderLabels(headers)
    t.setAlternatingRowColors(True);t.setSelectionBehavior(QAbstractItemView.SelectRows)
    t.setSelectionMode(QAbstractItemView.SingleSelection);t.setEditTriggers(QAbstractItemView.NoEditTriggers)
    t.verticalHeader().hide();t.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
    t.horizontalHeader().setStretchLastSection(True);t.setSortingEnabled(True)
    return t


def fill(t, rows, ids=None, red_rows=()):
    t.setSortingEnabled(False);t.setRowCount(len(rows))
    for i,row in enumerate(rows):
        for j,value in enumerate(row):
            item=QTableWidgetItem();item.setData(Qt.DisplayRole,value if value is not None else '')
            if ids is not None:item.setData(Qt.UserRole,ids[i])
            if i in red_rows:item.setForeground(QColor('#ff9b9b'));item.setBackground(QColor('#522b30'))
            t.setItem(i,j,item)
    t.resizeColumnsToContents()
    for c in range(t.columnCount()):t.setColumnWidth(c,min(360,max(90,t.columnWidth(c))))
    t.setSortingEnabled(True)


def selected(t):
    row=t.currentRow()
    if row<0 or t.item(row,0) is None:raise ValueError('Selecione uma linha primeiro.')
    return t.item(row,0).data(Qt.UserRole)


def spin(value=0, maximum=100000000, decimals=2):
    w=QDoubleSpinBox();w.setDecimals(decimals);w.setRange(0,maximum);w.setValue(float(value));return w


def text_label(text, muted=False):
    l=QLabel(text);l.setWordWrap(True);l.setProperty('muted',muted);return l


class Task(QThread):
    def __init__(self, operation, parent):
        super().__init__(parent);self.operation=operation;self.result=None;self.error=None
    def run(self):
        try:self.result=self.operation()
        except Exception as exc:self.error=str(exc)


class Bars(QWidget):
    def __init__(self):
        super().__init__();self.values=[];self.setMinimumHeight(190)
    def paintEvent(self,event):
        painter=QPainter(self);painter.setRenderHint(QPainter.Antialiasing)
        painter.fillRect(self.rect(),QColor('#151d28'))
        if not self.values:
            painter.setPen(QColor('#a6b7ce'));painter.drawText(self.rect(),Qt.AlignCenter,'Sem vendas detalhadas para exibir');return
        maximum=max(v for _,v in self.values) or 1
        width=max(1,self.width()-230);height=max(24,self.height()//len(self.values))
        for i,(name,value) in enumerate(self.values):
            y=i*height+8;painter.setPen(QColor('#e7edf5'));painter.drawText(8,y+18,name[:24])
            painter.setBrush(QColor('#d76542'));painter.setPen(Qt.NoPen)
            painter.drawRoundedRect(165,y,int(width*value/maximum),22,4,4)
            painter.setPen(QColor('#e7edf5'));painter.drawText(175+int(width*value/maximum),y+17,str(value))


class ProductEditor(QDialog):
    def __init__(self,store,product_id=None,parent=None):
        super().__init__(parent);self.store=store;self.pid=product_id
        self.setWindowTitle('Produto • custos e cores');self.resize(660,770)
        root=QVBoxLayout(self);form=QFormLayout();root.addLayout(form)
        data=store.rows('SELECT * FROM products WHERE id=?',(product_id,)) if product_id else []
        p=data[0] if data else {};self.name=QLineEdit(p.get('name',''));form.addRow('Nome do boneco / produto',self.name)
        self.fields={}
        for key,label,default in [('weight_g','Peso (g)',0),('hours','Tempo de impressão (h)',0),
            ('manual','Custo de fabricação manual (R$, opcional)',0),('packaging','Embalagem (R$)',.30),('other','Outros custos por unidade (R$)',0)]:
            value=p.get(key+'_cents',default*100)/100 if key in ('manual','packaging','other') else p.get(key,default)
            w=spin(value);self.fields[key]=w;form.addRow(label,w)
        root.addWidget(text_label('Custo manual maior que zero substitui material, energia e máquina. Com cores cadastradas, o peso é a soma dos gramas. Esses custos são compartilhados por todos os SKUs vinculados.',True))
        row=QHBoxLayout();row.addWidget(button('Ler 3MF / G-code',self.read_print));row.addWidget(button('Adicionar cor',self.add_color,True));row.addWidget(button('Remover cor',self.remove_color,True));root.addLayout(row)
        self.colors=QTableWidget(0,2);self.colors.setHorizontalHeaderLabels(['Cor / filamento','Gramas por unidade'])
        self.colors.horizontalHeader().setStretchLastSection(True);root.addWidget(self.colors,1)
        for c in store.rows('SELECT * FROM colors WHERE product_id=? ORDER BY name',(product_id,)) if product_id else []:self.add_color(c['name'],c['grams'])
        self.notes=QTextEdit();self.notes.setMaximumHeight(80);self.notes.setPlainText(p.get('notes',''));root.addWidget(self.notes)
        root.addWidget(text_label('Importar um arquivo de impressão só lê metadados; não envia comandos para impressoras.',True))
        controls=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);controls.accepted.connect(self.save);controls.rejected.connect(self.reject);root.addWidget(controls)
    def add_color(self,name=False,grams=0):
        i=self.colors.rowCount();self.colors.insertRow(i)
        self.colors.setItem(i,0,QTableWidgetItem(name if isinstance(name,str) else 'Nova cor'))
        self.colors.setItem(i,1,QTableWidgetItem(str(grams)))
    def remove_color(self):
        if self.colors.currentRow()>=0:self.colors.removeRow(self.colors.currentRow())
    @guarded
    def read_print(self):
        path,_=QFileDialog.getOpenFileName(self,'Arquivo fatiado','','Impressão (*.3mf *.gcode)')
        if not path:return
        plates=printing.parse_print(path)
        options=[f"{i+1}. {p['name']} — {p['weight_g']:.1f} g / {p['hours']:.2f} h" for i,p in enumerate(plates)]
        option,ok=QInputDialog.getItem(self,'Escolha a placa','Placa de impressão:',options,0,False)
        if not ok:return
        copies,ok=QInputDialog.getInt(self,'Quantidade na placa','Quantas unidades deste mesmo produto estão na placa?',1,1,10000)
        if not ok:return
        p=plates[options.index(option)];self.fields['weight_g'].setValue(p['weight_g']/copies);self.fields['hours'].setValue(p['hours']/copies)
        combined={}
        for name,grams in p['colors']:combined[name]=combined.get(name,0)+grams/copies
        self.colors.setRowCount(0)
        for name,grams in combined.items():self.add_color(name,grams)
    @guarded
    def save(self):
        data={k:w.value() for k,w in self.fields.items()};data.update(name=self.name.text(),notes=self.notes.toPlainText())
        colors=[]
        for i in range(self.colors.rowCount()):
            if not self.colors.item(i,0) or not self.colors.item(i,1):raise ValueError('Preencha nome e gramas de cada cor.')
            colors.append((self.colors.item(i,0).text(),self.colors.item(i,1).text()))
        self.pid=catalog.save_product(self.store,data,colors,self.pid);self.accept()


class Window(QMainWindow):
    def __init__(self,store=None):
        super().__init__();self.store=store or Store();self.task=None
        self.setWindowTitle(f'Forgeon Studio ERP • {__version__}');self.resize(1450,910)
        central=QWidget();self.setCentralWidget(central);outer=QVBoxLayout(central);outer.setContentsMargins(0,0,0,0)
        top=QHBoxLayout();top.setContentsMargins(22,12,22,10)
        brand=QLabel('FORGEON  2.0');brand.setStyleSheet('font-size:22px;font-weight:800;color:#ffb26c;');top.addWidget(brand)
        top.addWidget(text_label('Gestão de impressão 3D • uso local',True));top.addStretch()
        top.addWidget(QLabel('Mês:'));self.month=QComboBox();self.month.setEditable(True);self.month.setMinimumWidth(115);top.addWidget(self.month)
        top.addWidget(button('Fazer backup',self.backup,True));outer.addLayout(top)
        body=QHBoxLayout();self.nav=QListWidget();self.nav.setFixedWidth(220);self.stack=QStackedWidget();body.addWidget(self.nav);body.addWidget(self.stack,1);outer.addLayout(body,1)
        pages=[('Visão geral',self.dashboard_page),('Produtos',self.products_page),('Precificação',self.pricing_page),
               ('SKUs e vínculos',self.skus_page),('Pedidos',self.orders_page),('Importação',self.import_page),
               ('Financeiro',self.finance_page),('Relatórios',self.reports_page),('Planilhas',self.export_page),('Configurações',self.settings_page)]
        self.page_names=[p[0] for p in pages]
        for title,make in pages:self.nav.addItem(title);self.stack.addWidget(make())
        self.nav.currentRowChanged.connect(self.navigate);self.month.currentTextChanged.connect(self.month_changed)
        self.refresh_months();self.nav.setCurrentRow(0)
        self.statusBar().showMessage('Banco local: '+str(self.store.path))
    def page(self,title,description):
        container=QWidget();root=QVBoxLayout(container);root.setContentsMargins(24,20,24,18);root.setSpacing(14)
        label=QLabel(title);label.setProperty('heading',True);root.addWidget(label);root.addWidget(text_label(description,True));return container,root
    def toolbar(self,root,*buttons):
        bar=QHBoxLayout()
        for b in buttons:bar.addWidget(b)
        bar.addStretch();root.addLayout(bar)
    def month_value(self):
        value=self.month.currentText().strip()
        import re
        if not re.fullmatch(r'\d{4}-(0[1-9]|1[0-2])',value):raise ValueError('Informe o mês no formato AAAA-MM.')
        return value
    def month_changed(self,value):
        import re
        if re.fullmatch(r'\d{4}-(0[1-9]|1[0-2])',value.strip()):self.refresh_current()
    def refresh_months(self):
        current=self.month.currentText() or date.today().strftime('%Y-%m')
        months={date.today().strftime('%Y-%m'),current}
        for r in self.store.rows("SELECT substr(day,1,7) m FROM orders UNION SELECT month FROM summaries UNION SELECT substr(day,1,7) FROM expenses UNION SELECT substr(day,1,7) FROM purchases"):months.add(r['m'])
        self.month.blockSignals(True);self.month.clear();self.month.addItems(sorted(months,reverse=True));self.month.setCurrentText(current);self.month.blockSignals(False)
    def navigate(self,index):
        if index<0:return
        self.stack.setCurrentIndex(index);self.refresh_current()
    @guarded
    def refresh_current(self,*args):
        handlers=[self.refresh_dashboard,self.refresh_products,self.refresh_pricing,self.refresh_skus,self.refresh_orders,
                  self.refresh_imports,self.refresh_finance,self.refresh_reports,lambda:None,self.refresh_settings]
        index=self.stack.currentIndex()
        if 0<=index<len(handlers):handlers[index]()
    def run_task(self,fn,callback):
        if self.task is not None:raise ValueError('Aguarde a operação em andamento.')
        task=Task(fn,self);self.task=task;self.centralWidget().setEnabled(False);self.statusBar().showMessage('Processando…')
        self.task_callback=callback
        task.finished.connect(self.task_done);task.start()
    @Slot()
    def task_done(self):
        task=self.task
        if task is None:return
        callback=self.task_callback;self.task_callback=None;self.task=None
        task.finished.disconnect(self.task_done)
        self.centralWidget().setEnabled(True)
        self.statusBar().showMessage('Banco local: '+str(self.store.path))
        if task.error:QMessageBox.warning(self,'Operação não concluída',task.error)
        else:
            try:callback(task.result)
            except Exception as exc:QMessageBox.warning(self,'Forgeon',str(exc))
        task.deleteLater()
    def closeEvent(self,event):
        if self.task is not None:
            event.ignore();QMessageBox.information(self,'Aguarde','Aguarde a operação terminar antes de fechar.');return
        super().closeEvent(event)
    def dashboard_page(self):
        w,l=self.page('Visão geral','Resultados do mês selecionado. Estatísticas da Shopee e pedidos detalhados aparecem separados.')
        row=QHBoxLayout();self.metrics={}
        for key,title in [('sales','Vendas do resumo'),('details','Vendas detalhadas'),('units','Peças detalhadas'),('result','Resultado operacional estimado')]:
            card=QFrame();card.setProperty('card',True);cl=QVBoxLayout(card);cl.addWidget(text_label(title,True));label=QLabel('—');label.setStyleSheet('font-size:25px;font-weight:700;');cl.addWidget(label);row.addWidget(card);self.metrics[key]=label
        l.addLayout(row);self.coverage=QLabel();self.coverage.setWordWrap(True);l.addWidget(self.coverage)
        self.chart=Bars();l.addWidget(self.chart,1);self.dashboard_best=table(['Produto','Unidades','Subtotal dos itens']);l.addWidget(self.dashboard_best,1);return w
    def refresh_dashboard(self):
        r=reports.month_report(self.store,self.month_value());self.metrics['sales'].setText(money(r['summary']['sales_cents']) if r['summary'] else 'Sem resumo')
        self.metrics['details'].setText(money(r['detailed_sales']));self.metrics['units'].setText(str(r['units']));self.metrics['result'].setText(money(r['result']))
        self.coverage.setText(('Cobertura detalhada conferida. Custos usam o cadastro atual.' if r['complete'] else 'DADOS PARCIAIS • ')+'\n'.join(r['warnings']))
        self.chart.values=[(x[0],x[1]) for x in r['best'][:5]];self.chart.update()
        fill(self.dashboard_best,[[n,q,money(s)] for n,q,s in r['best']])
    def products_page(self):
        w,l=self.page('Produtos, custos e cores','Um cadastro por boneco. Todos os anúncios vinculados compartilham características e custos desse produto.')
        self.toolbar(l,button('Novo produto',lambda:self.edit_product()),button('Editar / cores / 3MF',self.edit_selected_product),button('Arquivar / reativar',self.archive_product,True))
        self.product_search=QLineEdit();self.product_search.setPlaceholderText('Buscar boneco, cor, SKU ou anúncio…');self.product_search.textChanged.connect(self.refresh_products);l.addWidget(self.product_search)
        self.show_archived=QCheckBox('Incluir produtos arquivados');self.show_archived.toggled.connect(self.refresh_products);l.addWidget(self.show_archived)
        self.products=table(['Boneco','SKUs','Origens','Cores / gramas','Peso','Horas','Custo total','Preço sugerido','Cadastro']);l.addWidget(self.products,1)
        self.products.cellDoubleClicked.connect(lambda *_:self.edit_selected_product());return w
    def refresh_products(self,*args):
        self.product_data=catalog.product_rows(self.store,include_inactive=self.show_archived.isChecked());query=self.product_search.text().strip().casefold();rows=[];ids=[]
        for p in self.product_data:
            colors=' • '.join(f"{c['name']} {c['grams']:g}g" for c in p['colors']);skus=', '.join(sorted({a['sku'] for a in p['aliases'] if a['sku']}))
            search=' '.join([p['name'],colors,skus]+[a['listing']+' '+a['variation'] for a in p['aliases']]).casefold()
            if query and query not in search:continue
            rows.append([p['name'],skus or 'Não vinculado',len(p['aliases']),colors or 'Faltam cores',f"{p['weight']:.1f} g",f"{p['hours']:.2f} h",money(p['cost_cents']),money(p['price_cents']),'Arquivado' if not p['active'] else ('Completo' if p['complete'] else 'Preencher custos / cores')]);ids.append(p['id'])
        fill(self.products,rows,ids)
    @guarded
    def edit_product(self,pid=None):
        dialog=ProductEditor(self.store,pid,self)
        if dialog.exec():self.refresh_products()
    @guarded
    def edit_selected_product(self):self.edit_product(selected(self.products))
    @guarded
    def archive_product(self):
        pid=selected(self.products)
        row=self.store.rows('SELECT active FROM products WHERE id=?',(pid,))[0]
        active=0 if row['active'] else 1
        action='Reativar' if active else 'Arquivar'
        if QMessageBox.question(self,action,action+' o produto? Pedidos e vínculos serão preservados.')!=QMessageBox.Yes:return
        with self.store.connect() as con:
            con.execute('UPDATE products SET active=? WHERE id=?',(active,pid));audit(con,'product_active',{'id':pid,'active':active})
        self.refresh_products()
    def pricing_page(self):
        w,l=self.page('Precificação','Preço = (custo × (1 + acréscimo) + taxa fixa) ÷ (1 − taxa percentual). Taxas são configuráveis, sem pressupor a regra atual da Shopee.')
        self.pricing=table(['Produto','Material','Energia','Custo total c/ embalagem','Preço sugerido','Peso','Horas']);l.addWidget(self.pricing,1)
        l.addWidget(text_label('Custos não são gravados como custos históricos dos pedidos. Relatórios recalculam usando o cadastro atual. O custo manual substitui fabricação, mas mantém embalagem e outros custos.',True));return w
    def refresh_pricing(self):
        rows=catalog.product_rows(self.store);fill(self.pricing,[[p['name'],money(p['material_cents']),money(p['energy_cents']),money(p['cost_cents']),money(p['price_cents']),f"{p['weight']:.1f}",p['hours']] for p in rows],[p['id'] for p in rows])
    def skus_page(self):
        w,l=self.page('SKUs e vínculos','Vários SKUs podem apontar para um produto. Código usado por bonecos diferentes fica vermelho; reservas não são reutilizadas.')
        self.toolbar(l,button('Vincular SKU / anúncio',lambda:self.alias_dialog()),button('Corrigir vínculo selecionado',self.edit_alias),button('Reservar próximo SKU',self.reserve_next),button('Reservar código manual',self.reserve_manual,True))
        self.skus=table(['SKU','Boneco','Variação','Anúncio','Situação']);l.addWidget(self.skus,2)
        l.addWidget(QLabel('Reservas e catálogo de códigos'));self.reserves=table(['Código','Produto / descrição','Situação']);l.addWidget(self.reserves,1);return w
    def refresh_skus(self):
        self.alias_data=catalog.sku_rows(self.store)
        fill(self.skus,[[r['sku'] or 'Sem SKU',r['name'],r['variation'],r['listing'],'REPETIDO ENTRE PRODUTOS' if r['conflict'] else 'Vinculado'] for r in self.alias_data],[r['id'] for r in self.alias_data],[i for i,r in enumerate(self.alias_data) if r['conflict']])
        rows=self.store.rows('SELECT s.*,p.name FROM sku_codes s LEFT JOIN products p ON p.id=s.product_id ORDER BY code')
        fill(self.reserves,[[r['code'],r['name'] or r['label'],'Aposentado' if r['retired'] else ('Vinculado' if r['product_id'] else 'Reservado')] for r in rows])
    @guarded
    def reserve_next(self):
        code=catalog.reserve_sku(self.store);self.refresh_skus();QMessageBox.information(self,'SKU reservado',code)
    @guarded
    def reserve_manual(self):
        code,ok=QInputDialog.getText(self,'Reservar SKU','Código único:')
        if ok and code.strip():catalog.reserve_sku(self.store,code);self.refresh_skus()
    @guarded
    def edit_alias(self):self.alias_dialog(selected(self.skus))
    @guarded
    def alias_dialog(self,alias_id=None):
        products=self.store.rows('SELECT id,name FROM products WHERE active=1 ORDER BY name')
        if not products:raise ValueError('Cadastre um produto primeiro.')
        old=next((r for r in catalog.sku_rows(self.store) if r['id']==alias_id),{})
        d=QDialog(self);d.setWindowTitle('Vínculo de SKU / anúncio');d.resize(580,300);f=QFormLayout(d)
        product=QComboBox()
        for p in products:product.addItem(p['name'],p['id'])
        if old:product.setCurrentIndex(product.findData(old['product_id']))
        sku=QLineEdit(old.get('sku',''));listing=QLineEdit(old.get('listing',''));variation=QLineEdit(old.get('variation',''))
        f.addRow('Produto físico',product);f.addRow('SKU',sku);f.addRow('Nome do anúncio',listing);f.addRow('Variação na origem',variation)
        buttons=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);f.addRow(buttons);buttons.accepted.connect(d.accept);buttons.rejected.connect(d.reject)
        if d.exec():catalog.link_alias(self.store,product.currentData(),sku.text(),listing.text(),variation.text(),alias_id);self.refresh_skus()
    def orders_page(self):
        w,l=self.page('Pedidos','Importados por ID, sem apagar o restante do mês. A data usada é a do pagamento, ou a criação quando não há pagamento.')
        self.toolbar(l,button('Registrar pedido manual',self.manual_order),button('Ver itens',self.order_details,True))
        self.order_search=QLineEdit();self.order_search.setPlaceholderText('Buscar ID ou status…');self.order_search.textChanged.connect(self.refresh_orders);l.addWidget(self.order_search)
        self.orders=table(['Pedido','Data','Status','Valor','Taxas','Taxas informadas']);l.addWidget(self.orders,1);return w
    def refresh_orders(self,*args):
        rows=self.store.rows('SELECT * FROM orders WHERE substr(day,1,7)=? ORDER BY day DESC,id',(self.month_value(),));q=self.order_search.text().casefold();rows=[r for r in rows if q in (r['id']+' '+r['status']).casefold()]
        fill(self.orders,[[r['id'],r['day'],r['status'],money(r['total_cents']),money(r['fees_cents']),'Sim' if r['fees_known'] else 'Não'] for r in rows],[r['id'] for r in rows])
    @guarded
    def order_details(self):
        oid=selected(self.orders);rows=self.store.rows('SELECT l.*,a.sku,a.variation,p.name FROM lines l JOIN aliases a ON a.id=l.alias_id JOIN products p ON p.id=a.product_id WHERE l.order_id=?',(oid,))
        d=QDialog(self);d.setWindowTitle('Itens • '+oid);d.resize(850,400);l=QVBoxLayout(d);t=table(['Produto','SKU atual','Variação','Quantidade','Devolvida','Subtotal']);l.addWidget(t);fill(t,[[r['name'],r['sku'],r['variation'],r['qty'],r['returned'],money(r['subtotal_cents'])] for r in rows]);d.exec()
    @guarded
    def manual_order(self):
        aliases=catalog.sku_rows(self.store)
        if not aliases:raise ValueError('Cadastre um produto e vincule um SKU primeiro.')
        d=QDialog(self);d.setWindowTitle('Pedido manual • um item');f=QFormLayout(d)
        oid=QLineEdit();day=QDateEdit(QDate.currentDate());day.setCalendarPopup(True);product=QComboBox()
        for a in aliases:product.addItem(a['sku']+' • '+a['name'],a['id'])
        qty=spin(1,100000,0);value=spin();fees=spin();status=QComboBox();status.addItems(['Pago','A Enviar','Concluído','Cancelado'])
        for label,field in [('ID único',oid),('Data',day),('SKU / produto',product),('Quantidade',qty),('Valor total (R$)',value),('Taxas totais (R$)',fees),('Status',status)]:f.addRow(label,field)
        controls=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);f.addRow(controls);controls.accepted.connect(d.accept);controls.rejected.connect(d.reject)
        if not d.exec():return
        from .values import cents
        if not oid.text().strip() or qty.value()<1:raise ValueError('Informe ID e quantidade.')
        with self.store.connect() as con:
            if con.execute('SELECT 1 FROM orders WHERE id=?',(oid.text().strip(),)).fetchone():raise ValueError('ID já cadastrado. Nenhum pedido foi substituído.')
            con.execute('INSERT INTO orders VALUES(?,?,?,?,?,?,?)',(oid.text().strip(),day.date().toString('yyyy-MM-dd'),status.currentText(),cents(value.value()),cents(fees.value()),1,'manual'))
            con.execute('INSERT INTO lines VALUES(?,?,?,?,?,?)',(oid.text().strip(),0,product.currentData(),int(qty.value()),0,cents(value.value())))
            audit(con,'manual_order',{'id':oid.text().strip()})
        self.refresh_months();self.refresh_orders()
    def import_page(self):
        w,l=self.page('Importar planilhas','Lê apenas os campos de gestão. Endereços, CPF, telefones e dados de compradores não são armazenados.')
        self.toolbar(l,button('Selecionar planilha Shopee (.xlsx)',self.choose_import))
        l.addWidget(text_label('Pedidos (Order.all / Order.toship): importa os IDs presentes, preservando outros pedidos e custos. Estatísticas: resumo mensal separado, sem inventar SKUs ou variações. Confira a prévia antes de confirmar.',True))
        self.imports=table(['Data','Tipo','Arquivo','Detalhes']);l.addWidget(self.imports,1);return w
    def refresh_imports(self):
        rows=self.store.rows('SELECT * FROM import_log ORDER BY id DESC');fill(self.imports,[[r['occurred'][:19],r['kind'],r['name'],r['details']] for r in rows])
    @guarded
    def choose_import(self):
        path,_=QFileDialog.getOpenFileName(self,'Planilha Shopee','','Excel sem macros (*.xlsx)')
        if path:self.run_task(lambda:sheets.preview(path),self.confirm_import)
    def confirm_import(self,data):
        d=QDialog(self);d.setWindowTitle('Prévia da importação');d.resize(880,580);l=QVBoxLayout(d)
        l.addWidget(text_label(data['source']+'\n'+'\n'.join(data['warnings'])))
        if data['kind']=='orders':
            label=f"{data['count']} pedidos; {data['units']} unidades. Até 100 pedidos na prévia."
            headers=['Pedido','Data','Status','Valor','Itens'];rows=[[o['id'],o['day'],o['status'],money(o['total']),len(o['lines'])] for o in data['orders'][:100]]
        else:
            label=f"Resumo {data['month']}: {data['orders']} pedidos pagos; vendas {money(data['sales'])}. Não substitui os pedidos detalhados."
            headers=['Anúncio','ID','Unidades','Vendas'];rows=[[p['name'],p['item_id'],p['units'],money(p['sales'])] for p in data['products']]
        l.addWidget(text_label(label));t=table(headers);fill(t,rows);l.addWidget(t)
        controls=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel);controls.button(QDialogButtonBox.Ok).setText('Confirmar importação');controls.accepted.connect(d.accept);controls.rejected.connect(d.reject);l.addWidget(controls)
        if d.exec():
            def done(backup):
                self.refresh_months();self.refresh_imports();QMessageBox.information(self,'Importação concluída','Dados combinados. Backup anterior:\n'+str(backup))
            self.run_task(lambda:sheets.apply_import(self.store,data),done)
    def finance_page(self):
        w,l=self.page('Financeiro','Despesas e compras de filamento. Compras afetam caixa estimado; consumo de material entra no custo, sem descontar a compra duas vezes no resultado.')
        self.toolbar(l,button('Adicionar despesa',self.new_expense),button('Compra de filamento',self.new_purchase),button('Excluir lançamento',self.remove_finance,True))
        self.finance=table(['Tipo','Data','Categoria / cor','Descrição / gramas','Valor']);l.addWidget(self.finance,1);self.finance_total=QLabel();l.addWidget(self.finance_total);return w
    def refresh_finance(self):
        month=self.month_value();rows=[];ids=[]
        for r in self.store.rows('SELECT * FROM expenses WHERE substr(day,1,7)=? ORDER BY day',(month,)):
            rows.append(['Despesa',r['day'],r['category'],r['description'],money(r['amount_cents'])]);ids.append(('expenses',r['id']))
        for r in self.store.rows('SELECT * FROM purchases WHERE substr(day,1,7)=? ORDER BY day',(month,)):
            rows.append(['Filamento',r['day'],r['color'],f"{r['grams']:g} g • {r['notes']}",money(r['amount_cents'])]);ids.append(('purchases',r['id']))
        fill(self.finance,rows,ids);r=reports.month_report(self.store,month)
        self.finance_total.setText(f"Despesas: {money(r['expenses'])}   |   Compras: {money(r['purchases'])}   |   Caixa operacional estimado: {money(r['cash'])} (não é saldo bancário)")
    @guarded
    def new_expense(self):
        d=QDialog(self);d.setWindowTitle('Despesa');f=QFormLayout(d);day=QDateEdit(QDate.currentDate());day.setCalendarPopup(True);category=QLineEdit('Geral');description=QLineEdit();value=spin()
        for label,w in [('Data',day),('Categoria',category),('Descrição',description),('Valor (R$)',value)]:f.addRow(label,w)
        controls=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);controls.accepted.connect(d.accept);controls.rejected.connect(d.reject);f.addRow(controls)
        if d.exec():reports.add_expense(self.store,day.date().toString('yyyy-MM-dd'),category.text(),description.text(),value.value());self.refresh_months();self.refresh_finance()
    @guarded
    def new_purchase(self):
        d=QDialog(self);d.setWindowTitle('Compra de filamento');f=QFormLayout(d);day=QDateEdit(QDate.currentDate());day.setCalendarPopup(True);color=QLineEdit();grams=spin(1000);value=spin();notes=QLineEdit()
        for label,w in [('Data',day),('Cor / material',color),('Gramas comprados',grams),('Valor total c/ frete (R$)',value),('Observações',notes)]:f.addRow(label,w)
        controls=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);controls.accepted.connect(d.accept);controls.rejected.connect(d.reject);f.addRow(controls)
        if d.exec():reports.add_purchase(self.store,day.date().toString('yyyy-MM-dd'),color.text(),grams.value(),value.value(),notes.text());self.refresh_months();self.refresh_finance()
    @guarded
    def remove_finance(self):
        kind,identifier=selected(self.finance)
        if kind not in ('expenses','purchases'):raise ValueError('Lançamento inválido.')
        if QMessageBox.question(self,'Excluir','Excluir este lançamento financeiro? A operação ficará no histórico.')!=QMessageBox.Yes:return
        with self.store.connect() as con:
            audit(con,'remove_finance',{'table':kind,'id':identifier});con.execute('DELETE FROM '+kind+' WHERE id=?',(identifier,))
        self.refresh_finance()
    def reports_page(self):
        w,l=self.page('Relatórios','Consumo e custos calculados a partir dos pedidos detalhados não cancelados e do cadastro atual. Valores parciais são identificados.')
        self.report_note=QLabel();self.report_note.setWordWrap(True);l.addWidget(self.report_note)
        self.report_metrics=table(['Indicador','Valor']);l.addWidget(self.report_metrics,1)
        self.report_colors=table(['Cor','Gramas usados no mês','1ª quinzena','2ª quinzena','Comprados no mês']);l.addWidget(self.report_colors,1)
        self.report_summary=table(['Anúncio do resumo Shopee','Unidades','Vendas']);l.addWidget(self.report_summary,1);return w
    def refresh_reports(self):
        month=self.month_value();r=reports.month_report(self.store,month)
        self.report_note.setText(('Cobertura conferida. ' if r['complete'] else 'PARCIAL • ')+' '.join(r['warnings'])+' Resultado estimado usa custos atuais, não conciliação contábil.')
        fill(self.report_metrics,[[label,money(r[key])] for label,key in [('Vendas detalhadas','detailed_sales'),('Taxas detalhadas','fees'),('Custo dos produtos e embalagem','costs'),('Despesas','expenses'),('Resultado operacional estimado','result'),('Compras de filamento','purchases'),('Caixa operacional estimado','cash')]])
        halves=[{},{}]
        with self.store.connect() as con:
            rows=con.execute('''SELECT c.name,c.grams,l.qty,l.returned,o.day,o.status FROM lines l JOIN orders o ON o.id=l.order_id
                JOIN aliases a ON a.id=l.alias_id JOIN colors c ON c.product_id=a.product_id WHERE substr(o.day,1,7)=?''',(month,)).fetchall()
        for x in rows:
            if any(t in x['status'].casefold() for t in ('cancel','não pago','nao pago','unpaid','aguardando pagamento')):continue
            half=0 if int(x['day'][8:10])<=15 else 1;halves[half][x['name']]=halves[half].get(x['name'],0)+x['grams']*max(0,x['qty']-x['returned'])
        purchases={}
        for x in self.store.rows('SELECT color,sum(grams) grams FROM purchases WHERE substr(day,1,7)=? GROUP BY color',(month,)):purchases[x['color']]=x['grams']
        fill(self.report_colors,[[c,round(r['colors'].get(c,0),2),round(halves[0].get(c,0),2),round(halves[1].get(c,0),2),round(purchases.get(c,0),2)] for c in sorted(set(r['colors'])|set(purchases))])
        summary=self.store.rows('SELECT * FROM summary_products WHERE month=? ORDER BY units DESC',(month,));fill(self.report_summary,[[x['name'],x['units'],money(x['sales_cents'])] for x in summary])
    def export_page(self):
        w,l=self.page('Planilhas','Exporte seus cadastros e relatórios em Excel. Arquivos gerados não contêm macros ou fórmulas importadas.')
        for label,kind in [('Catálogo de produtos e custos','products'),('Catálogo de SKUs e reservas','skus'),('Pedidos do mês','orders'),('Financeiro do mês','finance'),('Relatório mensal e consumo','report'),('Modelo de importação de pedidos','template')]:
            l.addWidget(button('Exportar • '+label,lambda checked=False,k=kind:self.export(k),True))
        l.addStretch();return w
    @guarded
    def export(self,kind):
        path,_=QFileDialog.getSaveFileName(self,'Salvar planilha',f'Forgeon2_{kind}.xlsx','Excel (*.xlsx)')
        if not path:return
        if kind=='template':sheets.write_orders_template(path)
        else:
            if kind=='products':
                ps=catalog.product_rows(self.store);headers=['Boneco','SKUs','Peso g','Horas','Cores / gramas','Custo total R$','Preço sugerido R$'];rows=[[p['name'],', '.join(a['sku'] for a in p['aliases']),p['weight'],p['hours'],'; '.join(f"{c['name']}:{c['grams']}" for c in p['colors']),p['cost_cents']/100,p['price_cents']/100] for p in ps]
            elif kind=='skus':
                rs=self.store.rows('SELECT s.*,p.name FROM sku_codes s LEFT JOIN products p ON p.id=s.product_id ORDER BY code');headers=['SKU','Produto / descrição','Situação'];rows=[[r['code'],r['name'] or r['label'],'Aposentado' if r['retired'] else ('Vinculado' if r['product_id'] else 'Reservado')] for r in rs]
                aliases=catalog.sku_rows(self.store);rows += [[r['sku'],r['name'],'REPETIDO ENTRE PRODUTOS' if r['conflict'] else 'Origem vinculada'] for r in aliases]
            elif kind=='orders':
                rs=self.store.rows('SELECT * FROM orders WHERE substr(day,1,7)=? ORDER BY day',(self.month_value(),));headers=['Pedido','Data','Status','Vendas R$','Taxas R$'];rows=[[r['id'],r['day'],r['status'],r['total_cents']/100,r['fees_cents']/100] for r in rs]
            elif kind=='finance':
                headers=['Tipo','Data','Categoria','Descrição','Valor R$'];rows=[]
                for t in ('expenses','purchases'):
                    rs=self.store.rows('SELECT * FROM '+t+' WHERE substr(day,1,7)=?',(self.month_value(),));rows += [[t,r['day'],r.get('category',r.get('color','')),r.get('description',r.get('notes','')),r['amount_cents']/100] for r in rs]
            else:
                r=reports.month_report(self.store,self.month_value());headers=['Indicador / cor','Valor','Unidade / observação'];rows=[['Mês',r['month'],''],['Cobertura','Conferida' if r['complete'] else 'PARCIAL','; '.join(r['warnings'])]]
                rows += [[k,r[k]/100,'R$'] for k in ('detailed_sales','fees','costs','expenses','result','purchases','cash')]
                rows += [[c,g,'g de consumo detalhado'] for c,g in r['colors'].items()]
                if r['summary']:rows += [['Vendas resumo Shopee',r['summary']['sales_cents']/100,'R$ (não somar às vendas detalhadas)']]
            sheets.export_table(path,'Forgeon 2',headers,rows)
        QMessageBox.information(self,'Planilha exportada',path)
    def settings_page(self):
        w,l=self.page('Configurações','Aplicativo independente, somente gestão. Não importa programas, extensões ou configurações da instalação antiga.')
        form=QFormLayout();self.settings_fields={}
        labels={'filament_kg':'Filamento — R$/kg','energy_kwh':'Energia — R$/kWh','printer_watts':'Potência da impressora — W','machine_hour':'Máquina — R$/hora','fee_percent':'Taxa da plataforma — %','fixed_fee':'Taxa fixa por unidade — R$','markup_percent':'Acréscimo sobre custo — %'}
        for key in DEFAULTS:
            field=spin(maximum=99.99 if key=='fee_percent' else 1000000);self.settings_fields[key]=field;form.addRow(labels[key],field)
        l.addLayout(form);self.toolbar(l,button('Salvar parâmetros',self.save_settings),button('Restaurar backup do Forgeon 2',self.restore,True),button('Histórico de operações',self.show_audit,True))
        l.addWidget(text_label('Não há criação de anúncios, tratamento de fotos, IA, MCP, extensão, terminal embutido ou download/execução automática de atualizações. O uso normal não precisa de internet. A instalação inicial das dependências requer internet.',True))
        l.addWidget(text_label('Dados ficam em: '+str(self.store.home)+'\nVersão: '+__version__,True));l.addStretch();return w
    def refresh_settings(self):
        for key,value in self.store.settings().items():
            if key in self.settings_fields:self.settings_fields[key].setValue(float(value))
    @guarded
    def save_settings(self):reports.save_settings(self.store,{k:w.value() for k,w in self.settings_fields.items()});QMessageBox.information(self,'Configurações','Parâmetros salvos.')
    @guarded
    def backup(self):
        path,_=QFileDialog.getSaveFileName(self,'Novo backup','Forgeon2_backup.sqlite3','Backup Forgeon 2 (*.sqlite3)')
        if path:QMessageBox.information(self,'Backup concluído',str(self.store.backup(path)))
    @guarded
    def restore(self):
        path,_=QFileDialog.getOpenFileName(self,'Backup do Forgeon 2','','Banco Forgeon 2 (*.sqlite3)')
        if not path:return
        if QMessageBox.question(self,'Restaurar','Substituir os dados atuais pelo backup selecionado? Será criado um backup dos dados atuais. O aplicativo fechará após a restauração.')!=QMessageBox.Yes:return
        previous=restore_backup(self.store,path);QMessageBox.information(self,'Backup restaurado','Dados anteriores preservados em:\n'+str(previous)+'\nAbra o aplicativo novamente.');self.close()
    @guarded
    def show_audit(self):
        d=QDialog(self);d.setWindowTitle('Histórico • últimas 500 operações');d.resize(900,500);l=QVBoxLayout(d);t=table(['Quando','Ação','Detalhes']);l.addWidget(t);rows=self.store.rows('SELECT * FROM audit ORDER BY id DESC LIMIT 500');fill(t,[[r['occurred'],r['action'],r['detail']] for r in rows]);d.exec()


def launch():
    app=QApplication.instance() or QApplication([])
    app.setApplicationName('Forgeon 2.0');app.setStyle('Fusion');app.setStyleSheet(STYLE)
    from PySide6.QtCore import QLocale, QLockFile
    QLocale.setDefault(QLocale(QLocale.Portuguese,QLocale.Brazil))
    store=Store();lock=QLockFile(str(store.home/'application.lock'));lock.setStaleLockTime(0)
    if not lock.tryLock(100):
        QMessageBox.information(None,'Forgeon 2.0','O Forgeon 2.0 já está aberto com este banco.');return 1
    w=Window(store);w.show();result=app.exec();lock.unlock();return result
