"""Read-only XLSX input and plain-cell exports. No macros or external links."""
from pathlib import Path
from datetime import datetime
import hashlib
import json
import re
import zipfile
from openpyxl import load_workbook, Workbook
from .values import normalized, number, cents, integer, iso_date, product_key
from .catalog import ensure_alias
from .store import audit


def open_sheet_file(path):
    path = Path(path)
    if path.suffix.casefold() != '.xlsx' or path.stat().st_size > 50*1024*1024:
        raise ValueError('Use uma planilha .xlsx de até 50 MB, sem macros.')
    with zipfile.ZipFile(path) as z:
        if len(z.infolist()) > 10000 or sum(i.file_size for i in z.infolist()) > 200*1024*1024:
            raise ValueError('Planilha excede o limite de leitura.')
        if any('vbaproject' in n.casefold() or 'externallinks/' in n.casefold() for n in z.namelist()):
            raise ValueError('Planilhas com macros ou vínculos externos não são aceitas.')
    wb = load_workbook(path, read_only=True, data_only=True, keep_links=False)
    for sheet in wb:
        sheet.reset_dimensions()  # Some Shopee exports incorrectly declare A1 as the whole sheet.
    return wb


def identifier(value):
    if value is None:
        return ''
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()


def row_dict(headers, row):
    # Duplicate Shopee columns are ignored; only explicitly named management fields are consumed.
    return {normalized(h): row[i] if i<len(row) else None for i,h in reversed(list(enumerate(headers))) if h}


def parse_orders(sheet):
    iterator = sheet.iter_rows(values_only=True)
    header = next(iterator, ())
    columns = {normalized(h) for h in header if h}
    required = {'id do pedido', 'nome do produto', 'quantidade', 'nome da variacao'}
    if not required <= columns:
        raise ValueError('Cabeçalho de pedidos Shopee não reconhecido.')
    groups = {};warnings=[]
    for index, row in enumerate(iterator, 2):
        if index>200000:
            raise ValueError('Limite de 200 mil linhas por importação. Divida a exportação em arquivos menores.')
        if not any(v is not None for v in row):
            continue
        r = row_dict(header, row)
        oid = identifier(r.get('id do pedido'))
        if not oid:
            raise ValueError(f'Linha {index}: pedido sem ID.')
        try:
            day = iso_date(r.get('hora do pagamento do pedido') or r.get('data de criacao do pedido'))
            listing = str(r.get('nome do produto') or '').strip()
            variation = str(r.get('nome da variacao') or '').strip()
            name = variation or listing
            if not name:
                raise ValueError('produto sem nome')
            sku = identifier(r.get('numero de referencia sku'))
            main = identifier(r.get('no de referencia do sku principal'))
            qty = integer(r.get('quantidade'))
            returned = integer(r.get('returned quantity'))
            if qty<=0 or returned>qty:
                raise ValueError('quantidade ou devolução inválida')
            fee_names = ('taxa de transacao', 'taxa de comissao liquida', 'taxa de servico liquida', 'taxa de envio reversa')
            fees_known = all(k in r and r[k] is not None and str(r[k]).strip() != '' for k in fee_names[:3])
            fees = sum(cents(r.get(k, 0)) for k in fee_names)
            total = cents(r.get('valor total', r.get('subtotal do produto')))
            external = json.dumps([sku.casefold(),main.casefold(),normalized(listing),normalized(variation)], ensure_ascii=True)
            item = dict(external=external,name=name,sku=sku,listing=listing,variation=variation,qty=qty,
                        returned=returned,subtotal=cents(r.get('subtotal do produto')))
            status = str(r.get('status do pedido') or '')
            if oid not in groups:
                groups[oid] = dict(id=oid,day=day,status=status,total=total,fees=fees,fees_known=fees_known,lines=[])
            g=groups[oid]
            if (g['day'],g['status'],g['total'],g['fees']) != (day,status,total,fees):
                raise ValueError('totais do mesmo pedido divergentes; confira a planilha')
            g['lines'].append(item)
        except ValueError as exc:
            raise ValueError(f'Linha {index}: {exc}') from exc
    if not groups:
        raise ValueError('Nenhum pedido encontrado.')
    warnings.append('Importe TODOS OS PEDIDOS para cobrir o mês. O nome/data do arquivo não garante cobertura completa.')
    return dict(kind='orders',orders=list(groups.values()),warnings=warnings,
                count=len(groups),units=sum(l['qty'] for g in groups.values() for l in g['lines']))


def period(text):
    match = re.fullmatch(r'(\d{2}/\d{2}/\d{4})\s*-\s*(\d{2}/\d{2}/\d{4})', str(text or '').strip())
    if not match:
        raise ValueError('Período mensal não identificado nas estatísticas.')
    start,end = (iso_date(x) for x in match.groups())
    if start>end or start[:7]!=end[:7]:
        raise ValueError('Importe as estatísticas de um único mês por arquivo.')
    return start,end


def parse_summary(wb):
    paid = next((s for s in wb if normalized(s.title)=='produto pago'),None)
    if paid is None:
        raise ValueError('Planilha de estatísticas: aba Produto Pago ausente.')
    iterator=paid.iter_rows(values_only=True);headers=next(iterator,());values=next(iterator,())
    r=row_dict(headers,values);start,end=period(r.get('data'))
    products=[];traffic_units=0
    for sheet in wb:
        title=normalized(sheet.title)
        if not (title.startswith('product contribution paid') or title.startswith('pedido pago contribuicao')):
            continue
        head=None;section=''
        for row in sheet.iter_rows(values_only=True):
            first=normalized(row[0]) if row else ''
            if first in ('id do item','fontes de trafego'):
                head=row;continue
            if head is None or not first:
                continue
            d=row_dict(head,row)
            if normalized(head[0])=='id do item':
                item=identifier(d.get('id do item'))
                if not item or not item.isdigit():
                    continue
                products.append(dict(item_id=item,name=str(d.get('produto') or ''),units=integer(d.get('unidades')),
                                     sales=cents(d.get('vendas brl'))))
            elif first in ('card do produto','live','video','afiliado','afiliados','anuncios','lives','videos','video do vendedor','afiliado shopee'):
                traffic_units+=integer(d.get('unidades'))
    # The product contribution report may repeat header sections; aggregate item IDs explicitly.
    aggregate={}
    for p in products:
        if p['item_id'] in aggregate:
            aggregate[p['item_id']]['units']+=p['units'];aggregate[p['item_id']]['sales']+=p['sales']
        else:
            aggregate[p['item_id']]=p.copy()
    units=traffic_units or sum(p['units'] for p in aggregate.values())
    return dict(kind='summary',start=start,end=end,month=start[:7],orders=integer(r.get('pedidos')),
                units=units,sales=cents(r.get('vendas brl')),products=list(aggregate.values()),
                count=len(aggregate),warnings=['Estatísticas são resumo: não identificam os SKUs/variações vendidos nem permitem consumo exato por cor.'])


def preview(path):
    wb=open_sheet_file(path)
    try:
        orders=next((s for s in wb if normalized(s.title)=='orders'),None)
        data=parse_orders(orders) if orders is not None else parse_summary(wb)
    finally:
        wb.close()
    data['source']=Path(path).name
    data['digest']=hashlib.sha256(Path(path).read_bytes()).hexdigest()
    return data


def apply_import(store, data):
    backup = store.backup()
    with store.connect() as con:
        con.execute('BEGIN IMMEDIATE')
        if data['kind']=='orders':
            for order in data['orders']:
                con.execute('''INSERT INTO orders VALUES(?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET
                  day=excluded.day,status=excluded.status,total_cents=excluded.total_cents,fees_cents=excluded.fees_cents,
                  fees_known=excluded.fees_known,source=excluded.source''',
                  (order['id'],order['day'],order['status'],order['total'],order['fees'],int(order['fees_known']),data['source']))
                con.execute('DELETE FROM lines WHERE order_id=?',(order['id'],))
                for i,line in enumerate(order['lines']):
                    alias=ensure_alias(con,line['external'],line['name'],line['sku'],line['listing'],line['variation'])
                    con.execute('INSERT INTO lines VALUES(?,?,?,?,?,?)',(order['id'],i,alias,line['qty'],line['returned'],line['subtotal']))
        elif data['kind']=='summary':
            con.execute('''INSERT INTO summaries VALUES(?,?,?,?,?,?,?) ON CONFLICT(month) DO UPDATE SET
              start_day=excluded.start_day,end_day=excluded.end_day,orders=excluded.orders,units=excluded.units,
              sales_cents=excluded.sales_cents,source=excluded.source''',
              (data['month'],data['start'],data['end'],data['orders'],data['units'],data['sales'],data['source']))
            con.execute('DELETE FROM summary_products WHERE month=?',(data['month'],))
            con.executemany('INSERT INTO summary_products VALUES(?,?,?,?,?)',
                [(data['month'],p['item_id'],p['name'],p['units'],p['sales']) for p in data['products']])
        else:
            raise ValueError('Tipo de importação desconhecido.')
        con.execute('INSERT INTO import_log(digest,kind,name,occurred,details) VALUES(?,?,?,?,?)',
            (data['digest'],data['kind'],data['source'],datetime.now().isoformat(),json.dumps({'count':data['count']})))
        audit(con,'import',{'kind':data['kind'],'count':data['count']})
    return backup


def export_table(path, title, headers, rows):
    path=Path(path)
    if path.suffix.casefold()!='.xlsx':
        raise ValueError('Salve como .xlsx.')
    wb=Workbook();sheet=wb.active;sheet.title=title[:31]
    sheet.append(headers)
    for row in rows:
        sheet.append([v if isinstance(v,(int,float)) else str(v if v is not None else '') for v in row])
        # Explicit string cells prevent formula injection from imported names/SKUs.
        for cell in sheet[sheet.max_row]:
            if isinstance(cell.value,str):cell.data_type='s'
    from openpyxl.styles import Font,PatternFill
    for c in sheet[1]:
        c.font=Font(bold=True,color='FFFFFF');c.fill=PatternFill('solid',fgColor='202C3B')
    sheet.freeze_panes='A2';sheet.auto_filter.ref=sheet.dimensions
    for column in sheet.columns:
        letter=column[0].column_letter
        sheet.column_dimensions[letter].width=min(55,max(14,max(len(str(c.value or '')) for c in column)+2))
    temp=path.with_name(path.stem+'.forgeon-tmp.xlsx')
    try:
        wb.save(temp);temp.replace(path)
    finally:
        wb.close();temp.unlink(missing_ok=True)


def write_orders_template(path):
    export_table(path,'orders',['ID do pedido','Status do pedido','Data de criação do pedido','Hora do pagamento do pedido',
        'Nome do Produto','Número de referência SKU','Nome da variação','Quantidade','Returned quantity',
        'Subtotal do produto','Valor Total','Taxa de transação','Taxa de comissão líquida','Taxa de serviço líquida'],[])
