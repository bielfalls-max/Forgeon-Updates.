"""Reads slicer metadata as data; never executes G-code or extracts archives."""
from pathlib import Path
import re
import zipfile
from defusedxml import ElementTree
from .values import number


def duration(text):
    if re.fullmatch(r'\d+(\.\d+)?', text.strip()):
        return float(number(text))
    parts = re.findall(r'(\d+(?:\.\d+)?)\s*([dhms])',text.casefold())
    return sum(float(n)*{'d':86400,'h':3600,'m':60,'s':1}[unit] for n,unit in parts)


def gcode_summary(lines):
    seconds=0;grams=[];colors=[]
    for line in lines:
        if not line.startswith(';'):
            continue
        key,sep,value=line[1:].partition('=')
        key=key.strip().casefold();value=value.strip()
        if sep and key.startswith('estimated printing time'):
            if seconds==0 or 'normal mode' in key:
                seconds=duration(value)
        elif line.startswith(';TIME:') and not seconds:
            seconds=float(number(line.split(':',1)[1]))
        elif key=='filament used [g]':
            grams=[float(number(v)) for v in re.split(r'[,;]',value) if v.strip()]
        elif key=='total filament used [g]' and not grams:
            grams=[float(number(value))]
        elif key in ('filament_colour','filament_color'):
            colors=[c.strip() for c in re.split(r'[,;]',value)]
    if not grams or sum(grams)<=0:
        raise ValueError('O G-code não informa gramas de filamento. Reexporte com metadados do fatiador.')
    return dict(name='G-code',hours=seconds/3600,weight_g=sum(grams),
                colors=[(colors[i] if i<len(colors) and colors[i] else f'Filamento {i+1}',g) for i,g in enumerate(grams) if g>0])


def parse_print(path):
    path=Path(path)
    if path.stat().st_size>512*1024*1024:
        raise ValueError('Arquivo de impressão excede 512 MB.')
    if path.suffix.casefold()=='.gcode':
        with path.open(encoding='utf-8',errors='replace') as handle:
            return [gcode_summary(handle)]
    if path.suffix.casefold()!='.3mf':
        raise ValueError('Use .3mf fatiado (Bambu/Orca) ou .gcode com metadados.')
    with zipfile.ZipFile(path) as archive:
        entries=archive.infolist()
        if len(entries)>10000:
            raise ValueError('Arquivo 3MF contém entradas demais.')
        entry=next((e for e in entries if e.filename.casefold()=='metadata/slice_info.config'),None)
        if entry:
            if entry.file_size>8*1024*1024:
                raise ValueError('Metadados excedem o tamanho permitido.')
            raw=archive.read(entry)
            if b'<!DOCTYPE' in raw.upper() or b'<!ENTITY' in raw.upper():
                raise ValueError('Declarações XML externas não são permitidas.')
            root=ElementTree.fromstring(raw)
            result=[]
            for index,plate in enumerate(root.iter('plate'),1):
                meta={e.get('key'):e.get('value','') for e in plate.findall('metadata')}
                colors=[]
                for fil in plate.findall('filament'):
                    grams=float(number(fil.get('used_g',0)))
                    if grams>0:
                        colors.append((fil.get('color') or 'Filamento '+str(fil.get('id','')),grams))
                weight=sum(g for _,g in colors) or float(number(meta.get('weight',0)))
                if weight<=0:
                    continue
                result.append(dict(name=meta.get('plate_name') or meta.get('plater_name') or f'Placa {index}',
                    hours=float(number(meta.get('prediction',0)))/3600,weight_g=weight,colors=colors))
            if result:
                return result
        raise ValueError('Este 3MF não contém consumo fatiado compatível. Fatie e exporte o projeto com informações de placa, ou use G-code.')
