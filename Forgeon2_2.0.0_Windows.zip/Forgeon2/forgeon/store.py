"""New SQLite schema. No old application modules are imported."""
from contextlib import contextmanager
from pathlib import Path
from datetime import datetime
import json
import os
import sqlite3

DEFAULTS = dict(filament_kg='100', energy_kwh='1', printer_watts='150', machine_hour='1',
                fee_percent='20', fixed_fee='0', markup_percent='100')
SCHEMA = '''
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS products(
 id INTEGER PRIMARY KEY, name TEXT NOT NULL, name_key TEXT NOT NULL UNIQUE,
 weight_g REAL NOT NULL DEFAULT 0 CHECK(weight_g>=0), hours REAL NOT NULL DEFAULT 0 CHECK(hours>=0),
 manual_cents INTEGER NOT NULL DEFAULT 0 CHECK(manual_cents>=0),
 packaging_cents INTEGER NOT NULL DEFAULT 30 CHECK(packaging_cents>=0),
 other_cents INTEGER NOT NULL DEFAULT 0 CHECK(other_cents>=0), notes TEXT NOT NULL DEFAULT '',
 active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)));
CREATE TABLE IF NOT EXISTS colors(
 product_id INTEGER NOT NULL REFERENCES products(id),name TEXT NOT NULL,grams REAL NOT NULL CHECK(grams>=0),
 PRIMARY KEY(product_id,name));
CREATE TABLE IF NOT EXISTS aliases(
 id INTEGER PRIMARY KEY,external_key TEXT NOT NULL UNIQUE,product_id INTEGER NOT NULL REFERENCES products(id),
 sku TEXT NOT NULL DEFAULT '',listing TEXT NOT NULL DEFAULT '',variation TEXT NOT NULL DEFAULT '');
CREATE INDEX IF NOT EXISTS alias_sku ON aliases(sku COLLATE NOCASE);
CREATE TABLE IF NOT EXISTS sku_codes(
 code TEXT PRIMARY KEY COLLATE NOCASE,product_id INTEGER REFERENCES products(id),
 label TEXT NOT NULL DEFAULT '',retired INTEGER NOT NULL DEFAULT 0 CHECK(retired IN (0,1)));
CREATE TABLE IF NOT EXISTS orders(
 id TEXT PRIMARY KEY,day TEXT NOT NULL,status TEXT NOT NULL,total_cents INTEGER NOT NULL,
 fees_cents INTEGER NOT NULL,fees_known INTEGER NOT NULL DEFAULT 1 CHECK(fees_known IN (0,1)),
 source TEXT NOT NULL DEFAULT '');
CREATE TABLE IF NOT EXISTS lines(
 order_id TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,line_no INTEGER NOT NULL,
 alias_id INTEGER NOT NULL REFERENCES aliases(id),qty INTEGER NOT NULL CHECK(qty>=0),
 returned INTEGER NOT NULL DEFAULT 0 CHECK(returned>=0),subtotal_cents INTEGER NOT NULL,
 PRIMARY KEY(order_id,line_no));
CREATE TABLE IF NOT EXISTS summaries(
 month TEXT PRIMARY KEY,start_day TEXT NOT NULL,end_day TEXT NOT NULL,orders INTEGER NOT NULL,
 units INTEGER NOT NULL,sales_cents INTEGER NOT NULL,source TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS summary_products(
 month TEXT NOT NULL REFERENCES summaries(month) ON DELETE CASCADE,item_id TEXT NOT NULL,
 name TEXT NOT NULL,units INTEGER NOT NULL,sales_cents INTEGER NOT NULL,PRIMARY KEY(month,item_id));
CREATE TABLE IF NOT EXISTS expenses(
 id INTEGER PRIMARY KEY,day TEXT NOT NULL,category TEXT NOT NULL,description TEXT NOT NULL,
 amount_cents INTEGER NOT NULL CHECK(amount_cents>=0));
CREATE TABLE IF NOT EXISTS purchases(
 id INTEGER PRIMARY KEY,day TEXT NOT NULL,color TEXT NOT NULL,grams REAL NOT NULL CHECK(grams>0),
 amount_cents INTEGER NOT NULL CHECK(amount_cents>=0),notes TEXT NOT NULL DEFAULT '');
CREATE TABLE IF NOT EXISTS import_log(
 id INTEGER PRIMARY KEY,digest TEXT NOT NULL,kind TEXT NOT NULL,name TEXT NOT NULL,
 occurred TEXT NOT NULL,details TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS review(
 id INTEGER PRIMARY KEY,kind TEXT NOT NULL,detail TEXT NOT NULL,resolved INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,occurred TEXT NOT NULL,action TEXT NOT NULL,detail TEXT NOT NULL);
PRAGMA application_id=1179799090;
PRAGMA user_version=1;
'''


def default_home():
    if os.environ.get('FORGEON2_HOME'):
        return Path(os.environ['FORGEON2_HOME']).expanduser().resolve()
    base = Path(os.environ.get('LOCALAPPDATA', Path.home() / '.local' / 'share'))
    return base / 'Forgeon2'


class Store:
    def __init__(self, home=None):
        self.home = Path(home) if home else default_home()
        self.home.mkdir(parents=True, exist_ok=True)
        self.path = self.home / 'forgeon2.sqlite3'
        with self.connect() as con:
            v = con.execute('PRAGMA user_version').fetchone()[0]
            populated = con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").fetchone()
            app_id = con.execute('PRAGMA application_id').fetchone()[0]
            if (v == 0 and populated) or (v == 1 and app_id != 1179799090):
                raise ValueError('Este banco não pertence ao Forgeon 2.0. Nenhum dado foi importado.')
            if v not in (0, 1):
                raise ValueError('Banco de versão mais recente. Não será modificado.')
            con.executescript(SCHEMA)
            con.executemany('INSERT OR IGNORE INTO settings VALUES(?,?)', DEFAULTS.items())

    @contextmanager
    def connect(self):
        con = sqlite3.connect(self.path, timeout=15)
        con.row_factory = sqlite3.Row
        con.execute('PRAGMA foreign_keys=ON')
        con.execute('PRAGMA trusted_schema=OFF')
        try:
            yield con
            con.commit()
        except BaseException:
            con.rollback()
            raise
        finally:
            con.close()

    def rows(self, sql, args=()):
        with self.connect() as con:
            return [dict(r) for r in con.execute(sql, args)]

    def settings(self):
        return {r['key']: r['value'] for r in self.rows('SELECT * FROM settings')}

    def backup(self, destination=None):
        if destination is None:
            folder = self.home / 'backups'
            folder.mkdir(exist_ok=True)
            destination = folder / ('forgeon2_' + datetime.now().strftime('%Y%m%d_%H%M%S_%f') + '.sqlite3')
        destination = Path(destination)
        if destination.resolve() == self.path.resolve() or destination.exists():
            raise ValueError('Escolha um novo arquivo para o backup.')
        target = sqlite3.connect(destination)
        try:
            with self.connect() as source:
                source.backup(target)
            if target.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
                raise ValueError('Backup não passou na verificação de integridade.')
        finally:
            target.close()
        return destination


def audit(con, action, detail):
    con.execute('INSERT INTO audit(occurred,action,detail) VALUES(?,?,?)',
                (datetime.now().isoformat(timespec='seconds'), action, json.dumps(detail, ensure_ascii=False)))


def restore_backup(store, source):
    """Only reads a backup of this schema; never copies program files."""
    source=Path(source).resolve()
    if source==store.path.resolve():
        raise ValueError('Selecione um backup, não o banco aberto.')
    check=sqlite3.connect(source.as_uri()+'?mode=ro',uri=True)
    try:
        check.execute('PRAGMA trusted_schema=OFF')
        if check.execute('PRAGMA user_version').fetchone()[0]!=1 or check.execute('PRAGMA application_id').fetchone()[0]!=1179799090:
            raise ValueError('Use um backup do Forgeon 2.0. Bancos antigos não são importados.')
        if check.execute('PRAGMA integrity_check').fetchone()[0]!='ok' or check.execute('PRAGMA foreign_key_check').fetchone():
            raise ValueError('Backup corrompido ou com vínculos inválidos.')
        required={'products','aliases','colors','orders','lines','settings','sku_codes','summaries','summary_products','expenses','purchases','audit','import_log','review'}
        actual={r[0] for r in check.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if not required<=actual or check.execute("SELECT 1 FROM sqlite_master WHERE type IN ('trigger','view')").fetchone():
            raise ValueError('Estrutura do backup não reconhecida.')
        with store.connect() as reference:
            for name in required:
                columns = [(r[1],r[2]) for r in check.execute('PRAGMA table_info('+name+')')]
                expected = [(r[1],r[2]) for r in reference.execute('PRAGMA table_info('+name+')')]
                if columns != expected:
                    raise ValueError('Colunas do backup incompatíveis com o Forgeon 2.0.')
        previous=store.backup()
        import tempfile
        with tempfile.NamedTemporaryFile(dir=store.home,suffix='.restore',delete=False) as handle:
            temp=Path(handle.name)
        try:
            target=sqlite3.connect(temp)
            try:check.backup(target)
            finally:target.close()
            temp.replace(store.path)
        finally:temp.unlink(missing_ok=True)
        return previous
    finally:
        check.close()
