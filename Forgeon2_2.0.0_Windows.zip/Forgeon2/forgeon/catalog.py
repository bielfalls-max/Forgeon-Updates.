"""Canonical products, independent listing origins and non-reusable SKU reservations."""
import sqlite3
from .store import audit
from .values import number, cents, product_key, quote


def save_product(store, data, colors, product_id=None):
    name = str(data['name']).strip()
    if not product_key(name):
        raise ValueError('Informe o nome do produto.')
    converted = (name, product_key(name), float(number(data.get('weight_g', 0))),
                 float(number(data.get('hours', 0))), cents(data.get('manual', 0)),
                 cents(data.get('packaging', 0)), cents(data.get('other', 0)), str(data.get('notes', '')))
    usage = []
    seen = set()
    for color, grams in colors:
        color = str(color).strip()
        if not color or color.casefold() in seen:
            raise ValueError('Cores precisam de nomes únicos e não vazios.')
        seen.add(color.casefold())
        usage.append((color, float(number(grams))))
    with store.connect() as con:
        con.execute('BEGIN IMMEDIATE')
        try:
            if product_id:
                if not con.execute('SELECT 1 FROM products WHERE id=?', (product_id,)).fetchone():
                    raise ValueError('Produto não encontrado.')
                con.execute('UPDATE products SET name=?,name_key=?,weight_g=?,hours=?,manual_cents=?,packaging_cents=?,other_cents=?,notes=? WHERE id=?', converted + (product_id,))
            else:
                product_id = con.execute('INSERT INTO products(name,name_key,weight_g,hours,manual_cents,packaging_cents,other_cents,notes) VALUES(?,?,?,?,?,?,?,?)', converted).lastrowid
        except sqlite3.IntegrityError as exc:
            raise ValueError('Já existe esse boneco. Edite o cadastro e vincule seus outros anúncios a ele.') from exc
        con.execute('DELETE FROM colors WHERE product_id=?', (product_id,))
        con.executemany('INSERT INTO colors VALUES(?,?,?)', [(product_id, *c) for c in usage])
        audit(con, 'save_product', {'id': product_id})
    return product_id


def ensure_product(con, name):
    key = product_key(name)
    if not key:
        raise ValueError('Produto sem nome.')
    row = con.execute('SELECT id FROM products WHERE name_key=?', (key,)).fetchone()
    return row[0] if row else con.execute('INSERT INTO products(name,name_key) VALUES(?,?)', (name.strip(), key)).lastrowid


def ensure_alias(con, external, name, sku='', listing='', variation=''):
    existing = con.execute('SELECT id FROM aliases WHERE external_key=?', (external,)).fetchone()
    if existing:
        return existing[0]
    pid = ensure_product(con, name)
    alias = con.execute('INSERT INTO aliases(external_key,product_id,sku,listing,variation) VALUES(?,?,?,?,?)',
                        (external, pid, str(sku).strip(), listing, variation)).lastrowid
    if sku:
        con.execute('INSERT OR IGNORE INTO sku_codes(code,product_id,label) VALUES(?,?,?)', (str(sku).strip(), pid, name))
    return alias


def reserve_sku(store, code='', label=''):
    with store.connect() as con:
        con.execute('BEGIN IMMEDIATE')
        if not code.strip():
            codes = [r[0] for r in con.execute('SELECT code FROM sku_codes') if r[0].isdigit()]
            codes += [r[0] for r in con.execute('SELECT sku FROM aliases') if r[0].isdigit()]
            code = str(max([int(c) for c in codes] + [0]) + 1).zfill(6)
        code = code.strip()
        if any(ch.isspace() for ch in code) or len(code) > 64:
            raise ValueError('SKU deve ter até 64 caracteres e não conter espaços.')
        if con.execute('SELECT 1 FROM aliases WHERE sku=? COLLATE NOCASE', (code,)).fetchone():
            raise ValueError('SKU já utilizado.')
        try:
            con.execute('INSERT INTO sku_codes(code,label) VALUES(?,?)', (code, label))
        except sqlite3.IntegrityError as exc:
            raise ValueError('SKU já utilizado ou reservado.') from exc
        audit(con, 'reserve_sku', {'code': code})
    return code


def link_alias(store, product_id, sku, listing='', variation='', alias_id=None):
    sku = str(sku).strip()
    if not sku or len(sku) > 64 or any(c.isspace() for c in sku):
        raise ValueError('Informe um SKU válido, sem espaços.')
    with store.connect() as con:
        con.execute('BEGIN IMMEDIATE')
        owner = con.execute('SELECT product_id,retired FROM sku_codes WHERE code=?', (sku,)).fetchone()
        conflicts = con.execute('SELECT 1 FROM aliases WHERE sku=? COLLATE NOCASE AND product_id<>? AND id<>?',
                                (sku, product_id, alias_id or -1)).fetchone()
        if conflicts or (owner and (owner['retired'] or owner['product_id'] not in (None, product_id))):
            raise ValueError('SKU pertence a outro produto ou foi aposentado. Escolha um código livre.')
        con.execute('INSERT INTO sku_codes(code,product_id,label) VALUES(?,?,?) ON CONFLICT(code) DO UPDATE SET product_id=excluded.product_id', (sku, product_id, ''))
        if alias_id:
            old = con.execute('SELECT sku FROM aliases WHERE id=?', (alias_id,)).fetchone()
            if not old:
                raise ValueError('Vínculo não encontrado.')
            con.execute('UPDATE aliases SET product_id=?,sku=?,listing=?,variation=? WHERE id=?',
                        (product_id, sku, listing, variation, alias_id))
            # Old SKU remains in registry. It is never reused automatically.
        else:
            import uuid
            con.execute('INSERT INTO aliases(external_key,product_id,sku,listing,variation) VALUES(?,?,?,?,?)',
                        ('manual:' + uuid.uuid4().hex, product_id, sku, listing, variation))
        audit(con, 'link_alias', {'product': product_id, 'sku': sku, 'alias': alias_id, 'previous_sku': old['sku'] if alias_id else None})


def product_rows(store, include_inactive=False):
    products = store.rows('SELECT * FROM products '+('' if include_inactive else 'WHERE active=1 ')+'ORDER BY name COLLATE NOCASE')
    settings = store.settings()
    colors = store.rows('SELECT * FROM colors ORDER BY name')
    aliases = store.rows('SELECT * FROM aliases')
    for p in products:
        p['colors'] = [c for c in colors if c['product_id'] == p['id']]
        p['aliases'] = [a for a in aliases if a['product_id'] == p['id']]
        p.update(quote(p, p['colors'], settings))
        p['complete'] = sum(c['grams'] for c in p['colors']) > 0 and (p['manual_cents'] > 0 or (p['weight'] > 0 and p['hours'] > 0))
    return products


def sku_rows(store):
    rows = store.rows('SELECT a.*,p.name FROM aliases a JOIN products p ON p.id=a.product_id ORDER BY a.sku,p.name')
    codes = {}
    for r in rows:
        if r['sku']:
            codes.setdefault(r['sku'].casefold(), set()).add(r['product_id'])
    for r in rows:
        r['conflict'] = len(codes.get(r['sku'].casefold(), ())) > 1
    return rows
