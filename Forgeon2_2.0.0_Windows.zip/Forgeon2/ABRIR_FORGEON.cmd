@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" goto not_installed
".venv\Scripts\python.exe" main.py
if errorlevel 1 goto failed
exit /b 0
:not_installed
echo Execute INSTALAR_DEPENDENCIAS.cmd primeiro.
pause
exit /b 1
:failed
echo O Forgeon nao conseguiu iniciar ou encerrou com erro. Copie a mensagem acima.
pause
exit /b 1
