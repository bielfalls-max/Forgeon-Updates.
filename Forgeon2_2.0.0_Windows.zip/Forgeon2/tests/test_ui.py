import os
os.environ['QT_QPA_PLATFORM']='offscreen'
import sys,tempfile,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from PySide6.QtWidgets import QApplication,QMessageBox
from PySide6.QtCore import Qt
from unittest.mock import patch
from forgeon.store import Store
from forgeon.ui import Window,ProductEditor,STYLE
from forgeon.catalog import save_product,link_alias
from forgeon import sheets

class Ui(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.app=QApplication.instance() or QApplication([]);cls.app.setStyleSheet(STYLE)
    def tearDown(self):
        from PySide6.QtCore import QCoreApplication,QEvent
        for widget in self.app.topLevelWidgets():
            widget.close();widget.deleteLater()
        self.app.processEvents();QCoreApplication.sendPostedEvents(None,QEvent.DeferredDelete)
        import gc;gc.collect()
    @classmethod
    def tearDownClass(cls):
        from PySide6.QtCore import QCoreApplication,QEvent
        cls.app.processEvents();QCoreApplication.sendPostedEvents(None,QEvent.DeferredDelete)
    def test_all_pages_empty_and_filled(self):
        with tempfile.TemporaryDirectory() as td:
            store=Store(td);w=Window(store);w.show()
            for i in range(w.stack.count()):w.nav.setCurrentRow(i);self.app.processEvents()
            self.assertEqual(w.stack.count(),10)
            pid=save_product(store,dict(name='Boneco Exemplo',hours=2,packaging=.3),[('Azul',50)])
            link_alias(store,pid,'000010','Origem 1','Boneco Exemplo');link_alias(store,pid,'000011','Origem 2','Boneco Exemplo')
            w.nav.setCurrentRow(1);w.refresh_products();self.assertEqual(w.products.rowCount(),1)
            self.assertIn('000011',w.products.item(0,1).text())
            w.product_search.setText('origem 2');self.assertEqual(w.products.rowCount(),1)
            w.product_search.clear()
            for i in range(w.stack.count()):w.nav.setCurrentRow(i);self.app.processEvents()
            w.close();self.app.processEvents()
    def test_product_dialog_saves_shared_colors(self):
        with tempfile.TemporaryDirectory() as td:
            store=Store(td);d=ProductEditor(store);d.name.setText('Robô');d.fields['hours'].setValue(1)
            d.add_color('Vermelho',25);d.save()
            self.assertEqual(len(store.rows('SELECT * FROM products')),1)
            self.assertEqual(store.rows('SELECT grams FROM colors')[0]['grams'],25)
    def test_background_reader_and_disabled_ui(self):
        import time
        with tempfile.TemporaryDirectory() as td:
            w=Window(Store(td));result=[];w.run_task(lambda:42,result.append)
            self.assertFalse(w.centralWidget().isEnabled())
            deadline=time.monotonic()+5
            while w.task is not None and time.monotonic()<deadline:self.app.processEvents();time.sleep(.01)
            self.assertEqual(result,[42]);self.assertTrue(w.centralWidget().isEnabled());w.close()
    def test_worker_error_is_reported(self):
        import time
        with tempfile.TemporaryDirectory() as td,patch.object(QMessageBox,'warning') as warning:
            w=Window(Store(td))
            def failure():raise ValueError('Arquivo inválido')
            w.run_task(failure,lambda _:None);deadline=time.monotonic()+5
            while w.task is not None and time.monotonic()<deadline:self.app.processEvents();time.sleep(.01)
            self.assertEqual(warning.call_count,1);self.assertTrue(w.centralWidget().isEnabled());w.close()

if __name__=='__main__':unittest.main()
