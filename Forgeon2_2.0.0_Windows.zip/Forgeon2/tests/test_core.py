import os
import sys
import json
import math
import tempfile
import unittest
import zipfile
import sqlite3
from pathlib import Path
from decimal import Decimal
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from forgeon.store import Store, restore_backup
from forgeon import catalog, sheets, reports, printing
from forgeon.values import cents, number, product_key, quote
from openpyxl import Workbook, load_workbook

HEADERS=['ID do pedido','Status do pedido','Data de criação do pedido','Hora do pagamento do pedido',
         'Nome do Produto','Número de referência SKU','Nome da variação','Quantidade','Returned quantity',
         'Subtotal do produto','Valor Total','Taxa de transação','Taxa de comissão líquida','Taxa de serviço líquida']

class Core(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.store=Store(self.root/'data')
    def tearDown(self):self.tmp.cleanup()
    def product(self,name='Sonic',colors=None):
        return catalog.save_product(self.store,dict(name=name,weight_g=100,hours=2,packaging='.30',manual=0,other=0),colors if colors is not None else [('Azul',60),('Branco',40)])
    def xlsx(self,rows,filename='Orders.xlsx'):
        path=self.root/filename;wb=Workbook();s=wb.active;s.title='orders';s.append(HEADERS)
        for r in rows:s.append(r)
        wb.save(path);wb.close();return path
    def row(self,oid='ORDER1',sku='000010',name='Sonic',qty=1,status='Pago',day='2026-10-03',price=50):
        return [oid,status,day,day,'Anúncio A',sku,name,qty,0,price,price,0,5,2]
    def test_empty_start(self):
        self.assertEqual(self.store.rows('SELECT * FROM products'),[])
        self.assertEqual(self.store.rows('SELECT * FROM orders'),[])
    def test_identity_conservative(self):
        self.assertEqual(product_key('Silver - Hedgehog'),product_key('silver'))
        self.assertEqual(product_key('super sonic,super sonic'),product_key('Super Sonic'))
        self.assertNotEqual(product_key('Sonic'),product_key('Super Sonic'))
        self.assertNotEqual(product_key('Sonic 12 cm'),product_key('Sonic 20 cm'))
    def test_product_validation_and_grouping(self):
        pid=self.product()
        with self.assertRaises(ValueError):self.product('Sonic - Hedgehog')
        with self.assertRaises(ValueError):catalog.save_product(self.store,dict(name='Tails',hours=-1),[])
        with self.assertRaises(ValueError):self.product('Tails',[('Azul',1),('azul',2)])
        self.assertEqual(len(catalog.product_rows(self.store)),1)
    def test_quote_exact(self):
        pid=self.product();p=catalog.product_rows(self.store)[0]
        # 100g at R$100/kg = R$10; 2h*150W at R$1/kWh = .30; 2 machine hours = R$2; packaging .30
        self.assertEqual(p['cost_cents'],1260)
        self.assertEqual(p['price_cents'],3150)
        catalog.save_product(self.store,dict(name='Sonic',manual=20,packaging=1,hours=1),[('Azul',10)],pid)
        self.assertEqual(catalog.product_rows(self.store)[0]['cost_cents'],2100)
    def test_decimal_rejects_nan(self):
        self.assertEqual(cents('1.234,56'),123456)
        self.assertEqual(cents('0.005'),1)
        for bad in ['NaN','Infinity','-5','x']:
            with self.assertRaises(ValueError):number(bad)
    def test_reservations_and_aliases(self):
        pid=self.product();other=self.product('Super Sonic')
        self.assertEqual(catalog.reserve_sku(self.store),'000001')
        catalog.link_alias(self.store,pid,'000001','A','Sonic')
        catalog.link_alias(self.store,pid,'000001','B','Sonic')
        self.assertEqual(len(catalog.product_rows(self.store)),2)
        self.assertFalse(any(r['conflict'] for r in catalog.sku_rows(self.store)))
        with self.assertRaises(ValueError):catalog.link_alias(self.store,other,'000001')
        with self.assertRaises(ValueError):catalog.reserve_sku(self.store,'000001')
        catalog.reserve_sku(self.store,'000010')
        self.assertEqual(catalog.reserve_sku(self.store),'000011')
    def test_reimport_preserves_other_orders_and_costs(self):
        pid=self.product();before=catalog.product_rows(self.store)[0]['cost_cents']
        data=sheets.preview(self.xlsx([self.row(),self.row('ORDER2',day='2026-10-04')]))
        sheets.apply_import(self.store,data);sheets.apply_import(self.store,data)
        smaller=sheets.preview(self.xlsx([self.row(qty=2,price=100)],'subset.xlsx'));sheets.apply_import(self.store,smaller)
        self.assertEqual(len(self.store.rows('SELECT * FROM orders')),2)
        self.assertEqual(len(self.store.rows('SELECT * FROM lines')),2)
        self.assertEqual(catalog.product_rows(self.store)[0]['cost_cents'],before)
        self.assertEqual(len(catalog.product_rows(self.store)),1)
        self.assertTrue(list((self.store.home/'backups').glob('*.sqlite3')))
    def test_import_atomic(self):
        data=sheets.preview(self.xlsx([self.row(),self.row('ORDER2')]))
        data['orders'][1]['lines'][0]['qty']=-1
        with self.assertRaises(sqlite3.IntegrityError):sheets.apply_import(self.store,data)
        self.assertEqual(self.store.rows('SELECT * FROM orders'),[])
        self.assertEqual(self.store.rows('SELECT * FROM products'),[])
    def test_sku_collision_visible_not_merged(self):
        data=sheets.preview(self.xlsx([self.row(),self.row('ORDER2',name='Super Sonic')]))
        sheets.apply_import(self.store,data)
        self.assertEqual(len(catalog.product_rows(self.store)),2)
        self.assertTrue(all(r['conflict'] for r in catalog.sku_rows(self.store)))
    def test_alias_correction_stable_reimport(self):
        data=sheets.preview(self.xlsx([self.row()]));sheets.apply_import(self.store,data)
        alias=catalog.sku_rows(self.store)[0];catalog.link_alias(self.store,alias['product_id'],'000099','A','Sonic',alias['id'])
        sheets.apply_import(self.store,data)
        self.assertEqual(catalog.sku_rows(self.store)[0]['sku'],'000099')
        self.assertEqual(len(catalog.sku_rows(self.store)),1)
        with self.assertRaises(ValueError):catalog.reserve_sku(self.store,'000010')
    def test_report_cancelled_and_consumption(self):
        self.product();data=sheets.preview(self.xlsx([self.row(qty=2,price=100),self.row('CANCEL',status='Cancelado'),self.row('UNPAID',status='Não pago')]))
        sheets.apply_import(self.store,data);reports.add_expense(self.store,'2026-10-03','Geral','Aluguel',5)
        reports.add_purchase(self.store,'2026-10-03','Azul',1000,100)
        r=reports.month_report(self.store,'2026-10');self.assertEqual(r['orders'],1);self.assertEqual(r['units'],2)
        self.assertEqual(r['colors']['Azul'],120);self.assertEqual(r['costs'],2520)
        self.assertEqual(r['result'],10000-700-2520-500)
        self.assertEqual(r['cash'],10000-700-500-10000)
    def test_export_no_formula_execution(self):
        path=self.root/'export.xlsx';sheets.export_table(path,'Produtos',['SKU','Nome'],[['000010','=HYPERLINK("bad")'],['+cmd','@test']])
        wb=load_workbook(path,data_only=False);s=wb.active
        self.assertEqual(s['A2'].value,'000010');self.assertEqual(s['B2'].data_type,'s');wb.close()
    def test_backup_restore_only_new_data(self):
        self.product();backup=self.store.backup();self.product('Tails');previous=restore_backup(self.store,backup)
        self.assertTrue(previous.exists());self.assertEqual(len(catalog.product_rows(self.store)),1)
        bad=self.root/'bad.db';sqlite3.connect(bad).close()
        with self.assertRaises(ValueError):restore_backup(self.store,bad)
    def test_3mf_and_gcode(self):
        p=self.root/'test.3mf'
        xml='''<root><plate><metadata key="prediction" value="7200"/><metadata key="weight" value="30"/><filament id="1" color="#FFFFFF" used_g="30"/></plate></root>'''
        with zipfile.ZipFile(p,'w') as z:z.writestr('Metadata/slice_info.config',xml)
        r=printing.parse_print(p)[0];self.assertEqual(r['hours'],2);self.assertEqual(r['weight_g'],30)
        with zipfile.ZipFile(p,'w') as z:z.writestr('Metadata/slice_info.config','<!DOCTYPE x [<!ENTITY a "X">]><root/>')
        with self.assertRaises(ValueError):printing.parse_print(p)
        code=self.root/'test.gcode';code.write_text('; estimated printing time (normal mode) = 1h 30m\n; filament used [g] = 10, 20\n; filament_colour = #FFFFFF;#000000\nG28\n')
        r=printing.parse_print(code)[0];self.assertEqual(r['hours'],1.5);self.assertEqual(r['weight_g'],30)
    def test_settings_validation(self):
        settings=self.store.settings();settings['fee_percent']='100'
        with self.assertRaises(ValueError):reports.save_settings(self.store,settings)
        self.assertEqual(self.store.settings()['fee_percent'],'20')
    def test_bad_row_no_import(self):
        with self.assertRaises(ValueError):sheets.preview(self.xlsx([self.row(qty=-1)]))
        self.assertEqual(self.store.rows('SELECT * FROM orders'),[])
    def test_no_duplicate_sku_concurrency(self):
        from concurrent.futures import ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=4) as executor:codes=list(executor.map(lambda _:catalog.reserve_sku(self.store),range(12)))
        self.assertEqual(len(set(codes)),12)


class MoreChecks(unittest.TestCase):
    setUp=Core.setUp
    tearDown=Core.tearDown
    product=Core.product
    xlsx=Core.xlsx
    row=Core.row
    def test_summary_kept_separate_from_orders(self):
        self.product();data=sheets.preview(self.xlsx([self.row()]))
        sheets.apply_import(self.store,data)
        summary=dict(kind='summary',month='2026-10',start='2026-10-01',end='2026-10-31',orders=3,units=5,
                     sales=22500,products=[dict(item_id='123',name='Anúncio exemplo',units=5,sales=22500)],
                     source='summary.xlsx',digest='synthetic',count=1)
        sheets.apply_import(self.store,summary)
        r=reports.month_report(self.store,'2026-10')
        self.assertEqual(r['detailed_sales'],5000);self.assertEqual(r['summary']['sales_cents'],22500)
        self.assertEqual(r['units'],1);self.assertFalse(r['complete'])
        self.assertEqual(len(catalog.product_rows(self.store)),1)
    def test_exact_full_month_coverage(self):
        self.product();sheets.apply_import(self.store,sheets.preview(self.xlsx([self.row()])))
        summary=dict(kind='summary',month='2026-10',start='2026-10-01',end='2026-10-31',orders=1,units=1,sales=5000,products=[],source='summary',digest='synthetic',count=0)
        sheets.apply_import(self.store,summary)
        self.assertTrue(reports.month_report(self.store,'2026-10')['complete'])
        summary['end']='2026-10-05';sheets.apply_import(self.store,summary)
        self.assertFalse(reports.month_report(self.store,'2026-10')['complete'])
    def test_archived_costs_preserved(self):
        pid=self.product();sheets.apply_import(self.store,sheets.preview(self.xlsx([self.row()])))
        with self.store.connect() as con:con.execute('UPDATE products SET active=0 WHERE id=?',(pid,))
        self.assertEqual(catalog.product_rows(self.store),[])
        self.assertEqual(reports.month_report(self.store,'2026-10')['costs'],1260)
    def test_refunds_reduce_consumption_but_not_claim_full_result(self):
        self.product();r=self.row(qty=2,price=100);r[8]=1
        sheets.apply_import(self.store,sheets.preview(self.xlsx([r])))
        report=reports.month_report(self.store,'2026-10')
        self.assertEqual(report['units'],1);self.assertEqual(report['colors']['Azul'],60)
        self.assertFalse(report['complete']);self.assertTrue(any('reembolso' in w for w in report['warnings']))
    def test_non_forgeon_database_refused(self):
        folder=self.root/'other';folder.mkdir();con=sqlite3.connect(folder/'forgeon2.sqlite3');con.execute('CREATE TABLE old(value)');con.close()
        with self.assertRaises(ValueError):Store(folder)
    def test_backup_with_triggers_refused(self):
        self.product();backup=self.store.backup()
        con=sqlite3.connect(backup);con.execute("CREATE TRIGGER unknown AFTER INSERT ON products BEGIN SELECT 1; END");con.close()
        with self.assertRaises(ValueError):restore_backup(self.store,backup)

if __name__=='__main__':unittest.main(verbosity=2)
