"""Checks the offline boundary and independence of the runtime package."""
import ast
from pathlib import Path
import unittest

ROOT=Path(__file__).resolve().parents[1]
class Boundaries(unittest.TestCase):
    def test_no_network_browser_shell_or_old_application_imports(self):
        banned={'requests','urllib','http','socket','webbrowser','subprocess','ctypes','chromium','playwright','selenium','rembg','onnxruntime','mcp','main','database','config'}
        for p in (ROOT/'forgeon').glob('*.py'):
            tree=ast.parse(p.read_text())
            for node in ast.walk(tree):
                if isinstance(node,ast.Import):
                    names={a.name.split('.')[0] for a in node.names}
                    self.assertFalse(names&banned,(p,names))
                if isinstance(node,ast.ImportFrom) and not node.level:
                    self.assertNotIn((node.module or '').split('.')[0],banned,p)
                if isinstance(node,ast.Call) and isinstance(node.func,ast.Name):
                    self.assertNotIn(node.func.id,{'eval','exec','compile','__import__'},p)
    def test_installation_does_not_modify_protection_or_use_old_environment(self):
        text=(ROOT/'INSTALAR_DEPENDENCIAS.cmd').read_text().casefold()
        self.assertIn('--require-hashes',text);self.assertIn('https://pypi.org/simple',text)
        for term in ('powershell','executionpolicy','set-mppreference','add-mppreference','disable','reg add','schtasks','forgeon_erp_home'):
            self.assertNotIn(term,text)
    def test_only_data_backups_no_legacy_importer(self):
        self.assertFalse((ROOT/'forgeon'/'migration.py').exists())
        self.assertFalse(list((ROOT/'forgeon').glob('*.db')))
        self.assertFalse(list((ROOT/'forgeon').glob('*.sqlite3')))

if __name__=='__main__':unittest.main()
