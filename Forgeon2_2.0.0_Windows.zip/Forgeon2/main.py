"""Entry point for Forgeon 2.0, independently implemented."""
if __name__=='__main__':
    import sys
    from forgeon.ui import launch
    sys.exit(launch())
